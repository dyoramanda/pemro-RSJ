package com.rsj.ui.common;

import com.rsj.model.User;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class TopBarPanel extends JPanel {

    private final JLabel lblPageTitle;
    private final JLabel lblUserInfo;
    private final JLabel lblRoleBadge;
    private final Runnable onLogout;
    private final Frame parentFrame;

    public TopBarPanel(Frame parentFrame, Runnable onLogout) {
        this.parentFrame = parentFrame;
        this.onLogout = onLogout;

        setLayout(new BorderLayout());
        setBackground(UiUtils.COLOR_SURFACE);
        setPreferredSize(new Dimension(1000, 60));
        setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UiUtils.COLOR_BORDER));

        // Left: Current Page Title & Date
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 14));
        left.setOpaque(false);

        lblPageTitle = new JLabel("Dashboard");
        lblPageTitle.setFont(UiUtils.FONT_TITLE);
        lblPageTitle.setForeground(UiUtils.COLOR_PRIMARY);

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", new Locale("id", "ID")));
        JLabel lblDate = new JLabel("• " + today);
        lblDate.setFont(UiUtils.FONT_REGULAR);
        lblDate.setForeground(UiUtils.COLOR_TEXT_MUTED);

        left.add(lblPageTitle);
        left.add(lblDate);

        // Right: User Profile, Role Badge, Logout Button
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        right.setOpaque(false);

        lblUserInfo = new JLabel("Pengguna");
        lblUserInfo.setFont(UiUtils.FONT_BOLD);
        lblUserInfo.setForeground(UiUtils.COLOR_TEXT_MAIN);

        lblRoleBadge = UiUtils.createBadge("ROLE", new Color(0xE0, 0xF2, 0xFE), UiUtils.COLOR_PRIMARY);

        JButton btnProfil = UiUtils.createSecondaryButton("Profil");
        btnProfil.addActionListener(e -> {
            ProfilDialog dlg = new ProfilDialog(parentFrame, this::updateUserData);
            dlg.setVisible(true);
        });

        JButton btnLogout = new JButton("Keluar");
        btnLogout.setFont(UiUtils.FONT_BOLD);
        btnLogout.setForeground(UiUtils.COLOR_DANGER);
        btnLogout.setBackground(new Color(0xFE, 0xF2, 0xF2));
        btnLogout.setFocusPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xFE, 0xCD, 0xCD), 1),
                BorderFactory.createEmptyBorder(6, 14, 6, 14)
        ));
        btnLogout.addActionListener(e -> {
            if (UiUtils.confirm(this, "Apakah Anda yakin ingin keluar dari sistem?")) {
                SessionManager.logout();
                if (onLogout != null) onLogout.run();
            }
        });

        right.add(lblUserInfo);
        right.add(lblRoleBadge);
        right.add(btnProfil);
        right.add(btnLogout);

        add(left, BorderLayout.WEST);
        add(right, BorderLayout.EAST);

        updateUserData();
    }

    public void setPageTitle(String title) {
        lblPageTitle.setText(title);
    }

    public void updateUserData() {
        User u = SessionManager.getCurrentUser();
        if (u != null) {
            lblUserInfo.setText(u.getNamaLengkap());
            lblRoleBadge.setText(u.getRole().replace("_", " "));
        }
    }
}
