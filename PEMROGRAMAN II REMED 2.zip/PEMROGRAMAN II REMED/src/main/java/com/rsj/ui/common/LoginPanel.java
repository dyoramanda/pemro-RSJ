package com.rsj.ui.common;

import com.rsj.model.User;
import com.rsj.service.AuthService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class LoginPanel extends JPanel {

    private final AuthService authService = new AuthService();
    private final Consumer<User> onLoginSuccess;
    private final Runnable onBackToWelcome;
    private final Frame parentFrame;

    private final JTextField txtUsername;
    private final JPasswordField txtPassword;
    private final JLabel lblError;

    public LoginPanel(Frame parentFrame, Consumer<User> onLoginSuccess, Runnable onBackToWelcome) {
        this.parentFrame = parentFrame;
        this.onLoginSuccess = onLoginSuccess;
        this.onBackToWelcome = onBackToWelcome;

        setLayout(new GridBagLayout());
        setBackground(UiUtils.COLOR_BG);

        // Card Container
        JPanel card = UiUtils.createCardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(420, 480));
        card.setBorder(BorderFactory.createEmptyBorder(28, 32, 28, 32));

        // Header inside Card
        JLabel lblLogo = new JLabel("RSJ SEHAT JIWA", SwingConstants.CENTER);
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblLogo.setForeground(UiUtils.COLOR_PRIMARY);
        lblLogo.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblSub = new JLabel("Sistem Informasi Manajemen Rumah Sakit Jiwa", SwingConstants.CENTER);
        lblSub.setFont(UiUtils.FONT_SMALL);
        lblSub.setForeground(UiUtils.COLOR_TEXT_MUTED);
        lblSub.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblLoginTitle = new JLabel("Silakan Masuk ke Akun Anda", SwingConstants.CENTER);
        lblLoginTitle.setFont(UiUtils.FONT_HEADER);
        lblLoginTitle.setForeground(UiUtils.COLOR_TEXT_MAIN);
        lblLoginTitle.setAlignmentX(CENTER_ALIGNMENT);

        // Inputs
        JPanel form = new JPanel(new GridLayout(4, 1, 4, 6));
        form.setOpaque(false);
        form.setMaximumSize(new Dimension(380, 160));

        JLabel lblUser = new JLabel("Nama Pengguna (Username):");
        lblUser.setFont(UiUtils.FONT_BOLD);
        txtUsername = new JTextField();
        txtUsername.setFont(UiUtils.FONT_REGULAR);
        txtUsername.setPreferredSize(new Dimension(360, 36));

        JLabel lblPass = new JLabel("Kata Sandi (Password):");
        lblPass.setFont(UiUtils.FONT_BOLD);
        txtPassword = new JPasswordField();
        txtPassword.setFont(UiUtils.FONT_REGULAR);
        txtPassword.setPreferredSize(new Dimension(360, 36));

        form.add(lblUser);
        form.add(txtUsername);
        form.add(lblPass);
        form.add(txtPassword);

        // Error message label
        lblError = new JLabel("", SwingConstants.CENTER);
        lblError.setFont(UiUtils.FONT_SMALL);
        lblError.setForeground(UiUtils.COLOR_DANGER);
        lblError.setAlignmentX(CENTER_ALIGNMENT);

        // Login Button
        JButton btnLogin = UiUtils.createPrimaryButton("Masuk Sistem");
        btnLogin.setMaximumSize(new Dimension(380, 42));
        btnLogin.setAlignmentX(CENTER_ALIGNMENT);
        btnLogin.addActionListener(e -> doLogin());

        // Enter key triggers login
        txtPassword.addActionListener(e -> doLogin());
        txtUsername.addActionListener(e -> doLogin());

        // Register family link
        JButton btnRegister = new JButton("<html>Belum punya akun keluarga? <b style='color:#0F9D9A;'>Daftar di sini</b></html>");
        btnRegister.setFont(UiUtils.FONT_SMALL);
        btnRegister.setContentAreaFilled(false);
        btnRegister.setBorderPainted(false);
        btnRegister.setFocusPainted(false);
        btnRegister.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRegister.setAlignmentX(CENTER_ALIGNMENT);
        btnRegister.addActionListener(e -> {
            RegisterKeluargaDialog dlg = new RegisterKeluargaDialog(parentFrame);
            dlg.setVisible(true);
        });

        // Back to welcome
        JButton btnBack = new JButton("← Kembali ke Halaman Depan");
        btnBack.setFont(UiUtils.FONT_SMALL);
        btnBack.setForeground(UiUtils.COLOR_TEXT_MUTED);
        btnBack.setContentAreaFilled(false);
        btnBack.setBorderPainted(false);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setAlignmentX(CENTER_ALIGNMENT);
        btnBack.addActionListener(e -> {
            if (onBackToWelcome != null) onBackToWelcome.run();
        });

        card.add(lblLogo);
        card.add(Box.createRigidArea(new Dimension(0, 4)));
        card.add(lblSub);
        card.add(Box.createRigidArea(new Dimension(0, 16)));
        card.add(lblLoginTitle);
        card.add(Box.createRigidArea(new Dimension(0, 14)));
        card.add(form);
        card.add(Box.createRigidArea(new Dimension(0, 8)));
        card.add(lblError);
        card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(btnLogin);
        card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(btnRegister);
        card.add(Box.createRigidArea(new Dimension(0, 14)));
        card.add(btnBack);

        add(card);
    }

    private void doLogin() {
        lblError.setText("");
        String u = txtUsername.getText().trim();
        String p = new String(txtPassword.getPassword());

        try {
            User user = authService.login(u, p);
            if (onLoginSuccess != null) {
                onLoginSuccess.accept(user);
            }
        } catch (Exception ex) {
            lblError.setText("<html><center>" + ex.getMessage() + "</center></html>");
        }
    }
}
