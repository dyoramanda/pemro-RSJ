package com.rsj.ui.keluarga;

import com.rsj.model.JadwalKunjungan;
import com.rsj.model.Pasien;
import com.rsj.service.KeluargaService;
import com.rsj.ui.common.StatCard;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class KeluargaDashboardPanel extends JPanel {

    private final KeluargaService keluargaService = new KeluargaService();

    private StatCard cardPasienDiasuh;
    private StatCard cardStatusRawat;
    private StatCard cardRuangBed;
    private StatCard cardJadwalBezuk;

    private final JTable tblKunjungan;
    private final DefaultTableModel modelKunjungan;

    public KeluargaDashboardPanel() {
        setLayout(new BorderLayout(0, 16));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);

        // Stats Row
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 14));
        statsRow.setOpaque(false);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        cardPasienDiasuh = new StatCard("Pasien Keluarga", "-", "Nama Pasien", UiUtils.COLOR_PRIMARY);
        cardStatusRawat = new StatCard("Status Perawatan", "-", "Kondisi Rawat", UiUtils.COLOR_ACCENT);
        cardRuangBed = new StatCard("Ruangan & Bed", "-", "Lokasi Perawatan", UiUtils.COLOR_INFO);
        cardJadwalBezuk = new StatCard("Pengajuan Kunjungan", "0", "Jadwal Bezuk", UiUtils.COLOR_SUCCESS);

        statsRow.add(cardPasienDiasuh);
        statsRow.add(cardStatusRawat);
        statsRow.add(cardRuangBed);
        statsRow.add(cardJadwalBezuk);

        // Pengumuman & Jadwal Kunjungan Terkini
        JPanel cardInfo = UiUtils.createCardPanel();
        cardInfo.setLayout(new BorderLayout(0, 10));

        JLabel lblTitle = new JLabel("Status Pengajuan Jadwal Kunjungan / Bezuk Pasien");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        modelKunjungan = new DefaultTableModel(new String[]{
                "No. Kunjungan", "Tanggal Kunjungan", "Sesi Bezuk", "Jumlah Pengunjung", "Status Persetujuan", "Catatan Petugas"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblKunjungan = new JTable(modelKunjungan);
        UiUtils.styleTable(tblKunjungan);
        JScrollPane sp = new JScrollPane(tblKunjungan);
        sp.setPreferredSize(new Dimension(900, 360));
        sp.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        cardInfo.add(lblTitle, BorderLayout.NORTH);
        cardInfo.add(sp, BorderLayout.CENTER);

        main.add(statsRow);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(cardInfo);

        JScrollPane scroll = new JScrollPane(main);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        refreshData();
    }

    public void refreshData() {
        List<Pasien> pasienList = keluargaService.getPasienKeluarga();
        if (!pasienList.isEmpty()) {
            Pasien p = pasienList.get(0);
            cardPasienDiasuh.setValue(p.getNamaLengkap());
            cardStatusRawat.setValue(p.getStatusRawat());
            String bed = p.getNamaRuangan() != null ? (p.getNamaRuangan() + " (" + p.getNomorBed() + ")") : "Rawat Jalan";
            cardRuangBed.setValue(bed);
        } else {
            cardPasienDiasuh.setValue("Belum Terhubung");
            cardStatusRawat.setValue("Hubungi Petugas");
            cardRuangBed.setValue("-");
        }

        List<JadwalKunjungan> kjList = keluargaService.getRiwayatKunjungan();
        cardJadwalBezuk.setValue(kjList.size() + " Jadwal");

        modelKunjungan.setRowCount(0);
        for (JadwalKunjungan jk : kjList) {
            modelKunjungan.addRow(new Object[]{
                    jk.getNoKunjungan(),
                    UiUtils.formatDate(jk.getTanggalKunjungan()),
                    jk.getSesiKunjungan(),
                    jk.getJumlahPengunjung() + " Orang",
                    jk.getStatusKunjungan(),
                    jk.getCatatanPetugas() != null ? jk.getCatatanPetugas() : "Menunggu verifikasi perawat bangsal"
            });
        }
    }
}
