package com.rsj.ui.perawat;

import com.rsj.model.Ruangan;
import com.rsj.model.TempatTidur;
import com.rsj.service.KeperawatanService;
import com.rsj.service.MasterDataService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class BedManagementPanel extends JPanel {

    private final KeperawatanService keperawatanService = new KeperawatanService();
    private final MasterDataService masterService = new MasterDataService();

    private final JPanel bedMatrixContainer;

    public BedManagementPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        // Top Legend Bar
        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 0));
        legend.setOpaque(false);
        legend.add(new JLabel("Status Indikator Bed:"));
        legend.add(createLegendPill("TERSEDIA (Kosong)", UiUtils.COLOR_SUCCESS));
        legend.add(createLegendPill("TERISI (Pasien Aktif)", UiUtils.COLOR_DANGER));
        legend.add(createLegendPill("DIBERSIHKAN / STERIL", UiUtils.COLOR_WARNING));
        legend.add(createLegendPill("PERBAIKAN", UiUtils.COLOR_TEXT_MUTED));

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan Status Bed");
        btnRefresh.addActionListener(e -> reloadData());

        topBar.add(legend, BorderLayout.WEST);
        topBar.add(btnRefresh, BorderLayout.EAST);

        bedMatrixContainer = new JPanel();
        bedMatrixContainer.setLayout(new BoxLayout(bedMatrixContainer, BoxLayout.Y_AXIS));
        bedMatrixContainer.setOpaque(false);

        JScrollPane sp = new JScrollPane(bedMatrixContainer);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(16);

        add(topBar, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

        reloadData();
    }

    private JLabel createLegendPill(String text, Color c) {
        JLabel l = UiUtils.createBadge(text, new Color(c.getRed(), c.getGreen(), c.getBlue(), 35), c);
        l.setFont(UiUtils.FONT_BOLD);
        return l;
    }

    public void reloadData() {
        bedMatrixContainer.removeAll();

        List<Ruangan> ruanganList = masterService.getAllRuangan();
        for (Ruangan r : ruanganList) {
            JPanel roomCard = UiUtils.createCardPanel();
            roomCard.setLayout(new BorderLayout(0, 12));
            roomCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));

            JPanel rHeader = new JPanel(new BorderLayout());
            rHeader.setOpaque(false);
            JLabel lblRName = new JLabel(r.getNamaRuangan() + " (" + r.getKodeRuangan() + ")");
            lblRName.setFont(UiUtils.FONT_HEADER);
            lblRName.setForeground(UiUtils.COLOR_PRIMARY);

            JLabel lblRInfo = new JLabel("Kategori: " + r.getKategori() + " • Tarif: " + UiUtils.formatRupiah(r.getTarifPerHari()) + "/hari");
            lblRInfo.setFont(UiUtils.FONT_SMALL);
            lblRInfo.setForeground(UiUtils.COLOR_TEXT_MUTED);

            rHeader.add(lblRName, BorderLayout.WEST);
            rHeader.add(lblRInfo, BorderLayout.EAST);

            // Beds Grid
            List<TempatTidur> beds = masterService.getTempatTidurByRuangan(r.getId());
            JPanel bedGrid = new JPanel(new GridLayout(1, Math.max(4, beds.size()), 12, 12));
            bedGrid.setOpaque(false);

            for (TempatTidur b : beds) {
                bedGrid.add(createBedTile(b));
            }

            roomCard.add(rHeader, BorderLayout.NORTH);
            roomCard.add(bedGrid, BorderLayout.CENTER);

            bedMatrixContainer.add(roomCard);
            bedMatrixContainer.add(Box.createRigidArea(new Dimension(0, 14)));
        }

        bedMatrixContainer.revalidate();
        bedMatrixContainer.repaint();
    }

    private JPanel createBedTile(TempatTidur b) {
        Color statusColor;
        switch (b.getStatus()) {
            case "TERISI": statusColor = UiUtils.COLOR_DANGER; break;
            case "DIBERSIHKAN": statusColor = UiUtils.COLOR_WARNING; break;
            case "DALAM_PERBAIKAN": statusColor = UiUtils.COLOR_TEXT_MUTED; break;
            default: statusColor = UiUtils.COLOR_SUCCESS; break;
        }

        JPanel tile = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0xF8, 0xFA, 0xFC));
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                g2.setColor(statusColor);
                g2.setStroke(new java.awt.BasicStroke(2.0f));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 12, 12);
                g2.dispose();
            }
        };
        tile.setLayout(new BoxLayout(tile, BoxLayout.Y_AXIS));
        tile.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        tile.setPreferredSize(new Dimension(180, 120));

        JLabel lblBedNo = new JLabel("BED: " + b.getNomorBed());
        lblBedNo.setFont(UiUtils.FONT_HEADER);
        lblBedNo.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblStatus = UiUtils.createBadge(b.getStatus(), new Color(statusColor.getRed(), statusColor.getGreen(), statusColor.getBlue(), 35), statusColor);

        JLabel lblPasien = new JLabel("<html><p style='font-size:10px;'>Pasien: <b>" + (b.getNamaPasien() != null ? b.getNamaPasien() : "KOSONG") + "</b></p></html>");

        JPanel actRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        actRow.setOpaque(false);

        if ("TERISI".equalsIgnoreCase(b.getStatus())) {
            JButton btnPulang = new JButton("Pulangkan");
            btnPulang.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnPulang.setForeground(UiUtils.COLOR_DANGER);
            btnPulang.setFocusPainted(false);
            btnPulang.addActionListener(e -> {
                if (UiUtils.confirm(this, "Pulangkan pasien dari " + b.getNomorBed() + " dan ubah status bed menjadi DIBERSIHKAN?")) {
                    try {
                        keperawatanService.updateBedStatus(b.getId(), "DIBERSIHKAN");
                        UiUtils.showSuccess(this, "Pasien berhasil dipulangkan.");
                        reloadData();
                    } catch (Exception ex) {
                        UiUtils.showError(this, ex.getMessage());
                    }
                }
            });
            actRow.add(btnPulang);
        } else if ("DIBERSIHKAN".equalsIgnoreCase(b.getStatus()) || "DALAM_PERBAIKAN".equalsIgnoreCase(b.getStatus())) {
            JButton btnSiap = new JButton("Siap Pakai");
            btnSiap.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnSiap.setForeground(UiUtils.COLOR_SUCCESS);
            btnSiap.setFocusPainted(false);
            btnSiap.addActionListener(e -> {
                try {
                    keperawatanService.updateBedStatus(b.getId(), "TERSEDIA");
                    UiUtils.showSuccess(this, "Bed " + b.getNomorBed() + " kini siap digunakan!");
                    reloadData();
                } catch (Exception ex) {
                    UiUtils.showError(this, ex.getMessage());
                }
            });
            actRow.add(btnSiap);
        }

        tile.add(lblBedNo);
        tile.add(Box.createRigidArea(new Dimension(0, 4)));
        tile.add(lblStatus);
        tile.add(Box.createRigidArea(new Dimension(0, 6)));
        tile.add(lblPasien);
        tile.add(Box.createRigidArea(new Dimension(0, 6)));
        tile.add(actRow);

        return tile;
    }
}
