package com.rsj.ui.keluarga;

import com.rsj.model.JadwalKunjungan;
import com.rsj.model.Pasien;
import com.rsj.service.KeluargaService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class BookingKunjunganPanel extends JPanel {

    private final KeluargaService keluargaService = new KeluargaService();

    private final JTable tblKunjungan;
    private final DefaultTableModel model;
    private List<JadwalKunjungan> kunjunganList;

    public BookingKunjunganPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Pengajuan Jadwal Bezuk / Kunjungan Pasien Jiwa");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Ajukan Jadwal Bezuk Baru");
        btnAdd.addActionListener(e -> showBookingForm());

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan");
        btnRefresh.addActionListener(e -> reloadData());

        right.add(btnAdd);
        right.add(btnRefresh);

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. Kunjungan", "Tanggal Bezuk", "Sesi Kunjungan", "Jumlah Keluarga", "Status Persetujuan", "Catatan Keluarga", "Keterangan Petugas Bangsal"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblKunjungan = new JTable(model);
        UiUtils.styleTable(tblKunjungan);
        cardTable.add(new JScrollPane(tblKunjungan), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        kunjunganList = keluargaService.getRiwayatKunjungan();
        model.setRowCount(0);
        for (JadwalKunjungan jk : kunjunganList) {
            model.addRow(new Object[]{
                    jk.getId(),
                    jk.getNoKunjungan(),
                    UiUtils.formatDate(jk.getTanggalKunjungan()),
                    jk.getSesiKunjungan(),
                    jk.getJumlahPengunjung() + " Orang",
                    jk.getStatusKunjungan(),
                    jk.getCatatan() != null ? jk.getCatatan() : "-",
                    jk.getCatatanPetugas() != null ? jk.getCatatanPetugas() : "Dalam proses telaah"
            });
        }
    }

    private void showBookingForm() {
        List<Pasien> pasiens = keluargaService.getPasienKeluarga();
        if (pasiens.isEmpty()) {
            UiUtils.showError(this, "Akun Anda belum terhubung dengan data pasien rawat inap. Silakan hubungi Petugas Pendaftaran.");
            return;
        }

        JDialog dlg = new JDialog((Frame) null, "Ajukan Jadwal Bezuk / Kunjungan Pasien", true);
        dlg.setSize(480, 420);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JComboBox<Pasien> cmbPasien = new JComboBox<>(pasiens.toArray(new Pasien[0]));
        JTextField txtTgl = new JTextField(LocalDate.now().plusDays(1).toString());
        JComboBox<String> cmbSesi = new JComboBox<>(new String[]{"PAGI (09:00 - 11:00)", "SIANG (13:00 - 15:00)", "SORE (16:00 - 17:30)"});
        JTextField txtJml = new JTextField("2");
        JTextField txtCatatan = new JTextField("Membawa pakaian ganti dan makanan kesukaan");

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pasien yang Dituju:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbPasien, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Tanggal Kunjungan (YYYY-MM-DD):"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtTgl, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Pilihan Sesi Jam:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(cmbSesi, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Jumlah Anggota Keluarga:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtJml, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Keperluan / Barang Bawaan:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtCatatan, g);

        JButton btnKirim = UiUtils.createPrimaryButton("Kirim Pengajuan Kunjungan");
        btnKirim.addActionListener(e -> {
            try {
                Pasien selP = (Pasien) cmbPasien.getSelectedItem();
                if (selP == null) throw new Exception("Pilih pasien terlebih dahulu!");

                JadwalKunjungan jk = new JadwalKunjungan();
                jk.setIdPasien(selP.getId());
                jk.setTanggalKunjungan(Date.valueOf(txtTgl.getText().trim()));
                String sesi = (String) cmbSesi.getSelectedItem();
                jk.setSesiKunjungan(sesi.contains("PAGI") ? "PAGI" : (sesi.contains("SIANG") ? "SIANG" : "SORE"));
                jk.setJumlahPengunjung(Integer.parseInt(txtJml.getText().trim()));
                jk.setCatatan(txtCatatan.getText().trim());

                keluargaService.ajukanKunjungan(jk);
                UiUtils.showSuccess(this, "Pengajuan kunjungan " + jk.getNoKunjungan() + " berhasil dikirim ke perawat bangsal!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 5; g.gridwidth = 2;
        g.insets = new Insets(16, 5, 5, 5);
        pan.add(btnKirim, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }
}
