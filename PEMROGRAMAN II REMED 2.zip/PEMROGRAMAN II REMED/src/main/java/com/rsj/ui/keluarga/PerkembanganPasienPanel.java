package com.rsj.ui.keluarga;

import com.rsj.model.ObservasiHarian;
import com.rsj.model.Pasien;
import com.rsj.service.KeluargaService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class PerkembanganPasienPanel extends JPanel {

    private final KeluargaService keluargaService = new KeluargaService();

    private final JComboBox<Pasien> cmbPasien;
    private final JTable tblPerkembangan;
    private final DefaultTableModel model;
    private final JLabel lblInfo;

    public PerkembanganPasienPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        List<Pasien> pasiens = keluargaService.getPasienKeluarga();
        cmbPasien = new JComboBox<>(pasiens.toArray(new Pasien[0]));
        cmbPasien.addActionListener(e -> reloadData());

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan");
        btnRefresh.addActionListener(e -> reloadData());

        left.add(new JLabel("Pilih Pasien Keluarga:"));
        left.add(cmbPasien);
        left.add(btnRefresh);

        topBar.add(left, BorderLayout.WEST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 10));

        lblInfo = new JLabel("Laporan Pemantauan Pemulihan & Aktivitas Harian Pasien (Transparan & Humanis)");
        lblInfo.setFont(UiUtils.FONT_HEADER);
        lblInfo.setForeground(UiUtils.COLOR_PRIMARY);

        model = new DefaultTableModel(new String[]{
                "Tanggal", "Waktu", "Kondisi Perilaku", "Suasana Hati (Mood)", "Kualitas Tidur", "Kepatuhan Obat", "Nafsu Makan", "Catatan Interaksi & Pemulihan"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPerkembangan = new JTable(model);
        UiUtils.styleTable(tblPerkembangan);

        cardTable.add(lblInfo, BorderLayout.NORTH);
        cardTable.add(new JScrollPane(tblPerkembangan), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        Pasien selP = (Pasien) cmbPasien.getSelectedItem();
        model.setRowCount(0);
        if (selP == null) return;

        List<ObservasiHarian> list = keluargaService.getPerkembanganPasien(selP.getId());
        for (ObservasiHarian o : list) {
            model.addRow(new Object[]{
                    UiUtils.formatDate(o.getTanggalObservasi()),
                    UiUtils.formatTime(o.getWaktuObservasi()),
                    o.getStatusKondisi(),
                    o.getStatusMood(),
                    o.getKualitasTidur(),
                    o.getKepatuhanObat(),
                    o.getNafsuMakan() != null ? o.getNafsuMakan() : "Baik",
                    o.getCatatanPerilaku()
            });
        }
    }
}
