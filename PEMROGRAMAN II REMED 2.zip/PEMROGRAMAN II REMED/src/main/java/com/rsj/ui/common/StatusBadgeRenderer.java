package com.rsj.ui.common;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class StatusBadgeRenderer extends DefaultTableCellRenderer {

    public static class BadgeStyle {
        public final String displayText;
        public final Color bgColor;
        public final Color fgColor;

        public BadgeStyle(String displayText, Color bgColor, Color fgColor) {
            this.displayText = displayText;
            this.bgColor = bgColor;
            this.fgColor = fgColor;
        }
    }

    private final Map<String, BadgeStyle> styleMap = new HashMap<>();
    private BadgeStyle currentStyle = null;

    public StatusBadgeRenderer() {
        setHorizontalAlignment(CENTER);
        setOpaque(false);
    }

    public StatusBadgeRenderer addMapping(String key, String displayText, Color bgColor, Color fgColor) {
        styleMap.put(key.toUpperCase(), new BadgeStyle(displayText, bgColor, fgColor));
        return this;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        String valStr = value != null ? value.toString().trim() : "";
        currentStyle = styleMap.get(valStr.toUpperCase());
        if (currentStyle != null) {
            setText(currentStyle.displayText);
            setForeground(currentStyle.fgColor);
        } else {
            setText(valStr);
            setForeground(new Color(0x33, 0x41, 0x55));
        }
        setFont(new Font("Segoe UI", Font.BOLD, 12));
        setOpaque(false);
        return this;
    }

    @Override
    protected void paintComponent(Graphics g) {
        if (currentStyle != null && getText() != null && !getText().isEmpty()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            FontMetrics fm = g2.getFontMetrics(getFont());
            int textWidth = fm.stringWidth(getText());
            int badgeWidth = Math.max(textWidth + 20, 68);
            int badgeHeight = 22;
            int x = (getWidth() - badgeWidth) / 2;
            int y = (getHeight() - badgeHeight) / 2;

            g2.setColor(currentStyle.bgColor);
            g2.fillRoundRect(x, y, badgeWidth, badgeHeight, 10, 10);
            g2.dispose();
        }
        super.paintComponent(g);
    }
}
