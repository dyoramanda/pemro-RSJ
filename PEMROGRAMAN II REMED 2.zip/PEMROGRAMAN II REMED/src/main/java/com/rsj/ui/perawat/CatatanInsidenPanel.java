package com.rsj.ui.perawat;

import com.rsj.model.CatatanInsiden;
import com.rsj.model.Pasien;
import com.rsj.service.KeperawatanService;
import com.rsj.service.PelayananService;
import com.rsj.ui.common.StatusBadgeRenderer;
import com.rsj.ui.common.TableUtil;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class CatatanInsidenPanel extends JPanel {

    private final KeperawatanService keperawatanService = new KeperawatanService();
    private final PelayananService pelayananService = new PelayananService();

    private final TableUtil.CustomTable tblInsiden;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<ItemOption> cmbJenisFilter;
    private final JComboBox<ItemOption> cmbRisikoFilter;
    private final JLabel lblCountInfo;
    private List<CatatanInsiden> insidenList;

    public static class ItemOption {
        public final String rawValue;
        public final String displayLabel;

        public ItemOption(String rawValue, String displayLabel) {
            this.rawValue = rawValue;
            this.displayLabel = displayLabel;
        }

        @Override
        public String toString() {
            return displayLabel;
        }
    }

    public CatatanInsidenPanel() {
        setLayout(new BorderLayout(0, 12));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));

        // ==========================================
        // 1. NORTH: HEADER CARD & TOOLBAR CARD
        // ==========================================
        JPanel topSection = new JPanel();
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));
        topSection.setOpaque(false);

        // Header Title Card
        JPanel headerCard = UiUtils.createCardPanel();
        headerCard.setLayout(new BorderLayout(14, 0));
        headerCard.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Catatan & Evaluasi Insiden Pasien");
        lblTitle.setFont(UiUtils.FONT_TITLE);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblSub = new JLabel("Pencatatan kejadian kritis, agresi verbal/fisik, pencegahan cedera, dan evaluasi asuhan keperawatan");
        lblSub.setFont(UiUtils.FONT_SMALL);
        lblSub.setForeground(UiUtils.COLOR_TEXT_MUTED);

        textPanel.add(lblTitle);
        textPanel.add(Box.createRigidArea(new Dimension(0, 3)));
        textPanel.add(lblSub);

        headerCard.add(textPanel, BorderLayout.WEST);

        // Toolbar Card (2 Baris: Filter & Aksi)
        JPanel toolbarCard = UiUtils.createCardPanel();
        toolbarCard.setLayout(new BorderLayout(0, 8));
        toolbarCard.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        // Baris 1: Filter & Pencarian
        JPanel rowFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        rowFilter.setOpaque(false);

        txtSearch = new JTextField(15);
        txtSearch.setPreferredSize(new Dimension(210, 34));
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari pasien / no RM...");
        txtSearch.addActionListener(e -> reloadData());

        cmbJenisFilter = new JComboBox<>(new ItemOption[]{
                new ItemOption("SEMUA", "Semua Jenis Insiden"),
                new ItemOption("AGRESI_VERBAL", "Agresi Verbal"),
                new ItemOption("AGRESI_FISIK", "Agresi Fisik"),
                new ItemOption("PERCOBAAN_KABUR", "Percobaan Kabur"),
                new ItemOption("JATUH", "Pasien Jatuh"),
                new ItemOption("PENOLAKAN_MEDIKASI", "Penolakan Obat"),
                new ItemOption("SELF_HARM", "Mencederai Diri"),
                new ItemOption("LAINNYA", "Insiden Lainnya")
        });
        cmbJenisFilter.setPreferredSize(new Dimension(175, 34));
        cmbJenisFilter.addActionListener(e -> reloadData());

        cmbRisikoFilter = new JComboBox<>(new ItemOption[]{
                new ItemOption("SEMUA", "Semua Tingkat Risiko"),
                new ItemOption("RENDAH", "Rendah"),
                new ItemOption("SEDANG", "Sedang"),
                new ItemOption("TINGGI", "Tinggi"),
                new ItemOption("KRITIS", "Kritis")
        });
        cmbRisikoFilter.setPreferredSize(new Dimension(160, 34));
        cmbRisikoFilter.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.setPreferredSize(new Dimension(85, 34));
        btnSearch.addActionListener(e -> reloadData());

        rowFilter.add(new JLabel("Pencarian:"));
        rowFilter.add(txtSearch);
        rowFilter.add(new JLabel("Jenis:"));
        rowFilter.add(cmbJenisFilter);
        rowFilter.add(new JLabel("Risiko:"));
        rowFilter.add(cmbRisikoFilter);
        rowFilter.add(btnSearch);

        // Baris 2: Info Data & Tombol-tombol Aksi
        JPanel rowActions = new JPanel(new BorderLayout(10, 0));
        rowActions.setOpaque(false);

        lblCountInfo = new JLabel("Menampilkan 0 data insiden");
        lblCountInfo.setFont(UiUtils.FONT_SMALL);
        lblCountInfo.setForeground(UiUtils.COLOR_TEXT_MUTED);

        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightButtons.setOpaque(false);

        JButton btnAdd = UiUtils.createPrimaryButton("+ Laporkan Insiden");
        btnAdd.setFont(UiUtils.FONT_BOLD);
        btnAdd.setPreferredSize(new Dimension(165, 36));
        btnAdd.addActionListener(e -> showInsidenForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah / Evaluasi");
        btnEdit.setPreferredSize(new Dimension(135, 36));
        btnEdit.addActionListener(e -> {
            CatatanInsiden ci = getSelectedInsiden();
            if (ci != null) showInsidenForm(ci);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.setPreferredSize(new Dimension(90, 36));
        btnDel.addActionListener(e -> deleteInsiden());

        rightButtons.add(btnAdd);
        rightButtons.add(btnEdit);
        rightButtons.add(btnDel);

        rowActions.add(lblCountInfo, BorderLayout.WEST);
        rowActions.add(rightButtons, BorderLayout.EAST);

        toolbarCard.add(rowFilter, BorderLayout.NORTH);
        toolbarCard.add(rowActions, BorderLayout.SOUTH);

        topSection.add(headerCard);
        topSection.add(Box.createRigidArea(new Dimension(0, 10)));
        topSection.add(toolbarCard);

        add(topSection, BorderLayout.NORTH);

        // ==========================================
        // 2. CENTER: TABEL DATA INSIDEN
        // ==========================================
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 8));

        model = new DefaultTableModel(new String[]{
                "ID_HIDDEN", "Waktu Insiden", "No. RM", "Nama Pasien", "Jenis Insiden", "Tingkat Risiko", "Deskripsi Kejadian", "Tindakan De-eskalasi", "Status", "Pelapor"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tblInsiden = TableUtil.createTable(model, "Belum ada catatan insiden");
        tblInsiden.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Sembunyikan kolom ID
        TableUtil.hideColumn(tblInsiden, 0);

        // Atur proporsi lebar kolom
        int[] preferredWidths = {130, 95, 140, 155, 100, 190, 180, 115, 130};
        int[] minWidths = {115, 85, 110, 120, 90, 130, 120, 95, 100};
        TableUtil.setColumnWidths(tblInsiden, preferredWidths, minWidths);

        // Format Perataan Tengah
        tblInsiden.getColumnModel().getColumn(0).setCellRenderer(TableUtil.createCenterRenderer()); // Waktu
        tblInsiden.getColumnModel().getColumn(1).setCellRenderer(TableUtil.createCenterRenderer()); // No RM

        // Badge Tingkat Risiko
        StatusBadgeRenderer badgeRisiko = new StatusBadgeRenderer()
                .addMapping("RENDAH", "Rendah", new Color(0xDC, 0xFC, 0xE7), new Color(0x15, 0x80, 0x3D))   // Hijau
                .addMapping("SEDANG", "Sedang", new Color(0xFE, 0xF3, 0xC7), new Color(0xB4, 0x53, 0x09))   // Oranye
                .addMapping("TINGGI", "Tinggi", new Color(0xFE, 0xE2, 0xE2), new Color(0xB9, 0x1C, 0x1C))   // Merah
                .addMapping("KRITIS", "Kritis", new Color(0x7F, 0x1D, 0x1D), new Color(0xFF, 0xFF, 0xFF));  // Crimson

        tblInsiden.getColumnModel().getColumn(4).setCellRenderer(badgeRisiko);

        // Badge Status Penanganan
        StatusBadgeRenderer badgeStatus = new StatusBadgeRenderer()
                .addMapping("DILAPORKAN", "Dilaporkan", new Color(0xFE, 0xF3, 0xC7), new Color(0xB4, 0x53, 0x09))       // Oranye
                .addMapping("DALAM_PENANGANAN", "Ditangani", new Color(0xDB, 0xEA, 0xFE), new Color(0x1D, 0x4E, 0xD8))  // Biru
                .addMapping("SELESAI", "Selesai", new Color(0xDC, 0xFC, 0xE7), new Color(0x15, 0x80, 0x3D))             // Hijau
                .addMapping("DIEVALUASI", "Dievaluasi", new Color(0xCC, 0xFB, 0xF1), new Color(0x0F, 0x76, 0x6E));      // Teal

        tblInsiden.getColumnModel().getColumn(7).setCellRenderer(badgeStatus);

        // Double click shortcut: Buka form evaluasi insiden
        tblInsiden.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblInsiden.getSelectedRow() >= 0) {
                    CatatanInsiden ci = getSelectedInsiden();
                    if (ci != null) showInsidenForm(ci);
                }
            }
        });

        JScrollPane scrollTable = new JScrollPane(tblInsiden);
        scrollTable.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));
        cardTable.add(scrollTable, BorderLayout.CENTER);

        // Status Bar Bawah: Legend & Petunjuk
        JPanel footerBar = new JPanel(new BorderLayout(10, 0));
        footerBar.setOpaque(false);
        footerBar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        JLabel lblLegend = new JLabel("Risiko:  🟢 Rendah   🟡 Sedang   🔴 Tinggi   🟣 Kritis");
        lblLegend.setFont(UiUtils.FONT_SMALL);
        lblLegend.setForeground(UiUtils.COLOR_TEXT_MUTED);

        JLabel lblHint = new JLabel("Klik ganda baris untuk mengubah atau mengevaluasi insiden");
        lblHint.setFont(UiUtils.FONT_SMALL);
        lblHint.setForeground(UiUtils.COLOR_TEXT_MUTED);

        footerBar.add(lblLegend, BorderLayout.WEST);
        footerBar.add(lblHint, BorderLayout.EAST);
        cardTable.add(footerBar, BorderLayout.SOUTH);

        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public static String toJenisDisplay(String raw) {
        if (raw == null) return "-";
        switch (raw.toUpperCase()) {
            case "AGRESI_VERBAL": return "Agresi Verbal";
            case "AGRESI_FISIK": return "Agresi Fisik";
            case "PERCOBAAN_KABUR": return "Percobaan Kabur";
            case "JATUH": return "Pasien Jatuh";
            case "PENOLAKAN_MEDIKASI": return "Penolakan Obat";
            case "SELF_HARM": return "Mencederai Diri";
            case "LAINNYA": return "Insiden Lainnya";
            default: return raw.replace("_", " ");
        }
    }

    public static String toJenisRaw(String display) {
        if (display == null) return "LAINNYA";
        switch (display) {
            case "Agresi Verbal": return "AGRESI_VERBAL";
            case "Agresi Fisik": return "AGRESI_FISIK";
            case "Percobaan Kabur": return "PERCOBAAN_KABUR";
            case "Pasien Jatuh": return "JATUH";
            case "Penolakan Obat": return "PENOLAKAN_MEDIKASI";
            case "Mencederai Diri": return "SELF_HARM";
            default: return "LAINNYA";
        }
    }

    public static String toRisikoDisplay(String raw) {
        if (raw == null) return "Rendah";
        switch (raw.toUpperCase()) {
            case "SEDANG": return "Sedang";
            case "TINGGI": return "Tinggi";
            case "KRITIS": return "Kritis";
            default: return "Rendah";
        }
    }

    public static String toRisikoRaw(String display) {
        if (display == null) return "RENDAH";
        switch (display) {
            case "Sedang": return "SEDANG";
            case "Tinggi": return "TINGGI";
            case "Kritis": return "KRITIS";
            default: return "RENDAH";
        }
    }

    public static String toStatusDisplay(String raw) {
        if (raw == null) return "Dilaporkan";
        switch (raw.toUpperCase()) {
            case "DALAM_PENANGANAN": return "Dalam Penanganan";
            case "SELESAI": return "Selesai";
            case "DIEVALUASI": return "Dievaluasi";
            default: return "Dilaporkan";
        }
    }

    public static String toStatusRaw(String display) {
        if (display == null) return "DILAPORKAN";
        switch (display) {
            case "Dalam Penanganan": return "DALAM_PENANGANAN";
            case "Selesai": return "SELESAI";
            case "Dievaluasi": return "DIEVALUASI";
            default: return "DILAPORKAN";
        }
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        ItemOption optJenis = (ItemOption) cmbJenisFilter.getSelectedItem();
        ItemOption optRisiko = (ItemOption) cmbRisikoFilter.getSelectedItem();

        String jns = optJenis != null ? optJenis.rawValue : "SEMUA";
        String rsk = optRisiko != null ? optRisiko.rawValue : "SEMUA";

        insidenList = keperawatanService.searchInsiden(kw, jns, rsk);
        model.setRowCount(0);
        for (CatatanInsiden ci : insidenList) {
            model.addRow(new Object[]{
                    ci.getId(),
                    TableUtil.formatShortDateTime(ci.getTanggalInsiden(), ci.getWaktuInsiden()),
                    ci.getNoRekamMedis(),
                    ci.getNamaPasien(),
                    toJenisDisplay(ci.getJenisInsiden()),
                    ci.getTingkatRisiko(),
                    ci.getDeskripsiKejadian() != null ? ci.getDeskripsiKejadian() : "-",
                    ci.getTindakanPenanganan() != null ? ci.getTindakanPenanganan() : "-",
                    ci.getStatusPenyelesaian(),
                    ci.getNamaPelapor() != null ? ci.getNamaPelapor() : "-"
            });
        }
        lblCountInfo.setText("Menampilkan " + insidenList.size() + " data insiden");
    }

    private CatatanInsiden getSelectedInsiden() {
        int r = tblInsiden.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris insiden terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return insidenList.stream().filter(ci -> ci.getId() == id).findFirst().orElse(null);
    }

    private void showInsidenForm(CatatanInsiden ci) {
        boolean isEdit = ci != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Evaluasi & Tindak Lanjut Insiden" : "Laporan Insiden Keselamatan Pasien Jiwa", true);
        dlg.setLayout(new BorderLayout());

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(UiUtils.COLOR_SURFACE);
        root.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        // Header Dialog
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setOpaque(false);

        JLabel lblDlgTitle = new JLabel(isEdit ? "Evaluasi & Tindak Lanjut Insiden" : "Pelaporan Insiden Keselamatan Pasien");
        lblDlgTitle.setFont(UiUtils.FONT_TITLE);
        lblDlgTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblDlgSub = new JLabel("Pencatatan kejadian kritis, agresi verbal/fisik, dan tindakan de-eskalasi asuhan keperawatan jiwa");
        lblDlgSub.setFont(UiUtils.FONT_SMALL);
        lblDlgSub.setForeground(UiUtils.COLOR_TEXT_MUTED);

        headerPanel.add(lblDlgTitle);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        headerPanel.add(lblDlgSub);

        // Body Form with GridBagLayout
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(6, 4, 6, 4);

        // 1. Pasien Terkait
        List<Pasien> pasiens = pelayananService.getAllPasien();
        JComboBox<Pasien> cmbPasien = new JComboBox<>(pasiens.toArray(new Pasien[0]));
        cmbPasien.setPreferredSize(new Dimension(380, 34));
        if (isEdit) {
            for (Pasien p : pasiens) {
                if (p.getId() == ci.getIdPasien()) {
                    cmbPasien.setSelectedItem(p);
                    break;
                }
            }
        }

        g.gridx = 0; g.gridy = 0; g.weightx = 0.28; form.add(new JLabel("Pasien Terkait:*"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.72; form.add(cmbPasien, g);

        // 2. Jenis Insiden (Display Manusiawi)
        String[] jenisDisplays = new String[]{"Agresi Verbal", "Agresi Fisik", "Percobaan Kabur", "Pasien Jatuh", "Penolakan Obat", "Mencederai Diri", "Insiden Lainnya"};
        JComboBox<String> cmbJenis = new JComboBox<>(jenisDisplays);
        cmbJenis.setPreferredSize(new Dimension(380, 34));
        if (isEdit) {
            cmbJenis.setSelectedItem(toJenisDisplay(ci.getJenisInsiden()));
        }

        g.gridx = 0; g.gridy = 1; form.add(new JLabel("Jenis Insiden:*"), g);
        g.gridx = 1; g.gridy = 1; form.add(cmbJenis, g);

        // 3. Tingkat Risiko
        String[] risikoDisplays = new String[]{"Rendah", "Sedang", "Tinggi", "Kritis"};
        JComboBox<String> cmbRisiko = new JComboBox<>(risikoDisplays);
        cmbRisiko.setPreferredSize(new Dimension(380, 34));
        if (isEdit) {
            cmbRisiko.setSelectedItem(toRisikoDisplay(ci.getTingkatRisiko()));
        }

        g.gridx = 0; g.gridy = 2; form.add(new JLabel("Tingkat Risiko:*"), g);
        g.gridx = 1; g.gridy = 2; form.add(cmbRisiko, g);

        // 4. Status Penanganan
        String[] statusDisplays = new String[]{"Dilaporkan", "Dalam Penanganan", "Selesai", "Dievaluasi"};
        JComboBox<String> cmbStatus = new JComboBox<>(statusDisplays);
        cmbStatus.setPreferredSize(new Dimension(380, 34));
        if (isEdit) {
            cmbStatus.setSelectedItem(toStatusDisplay(ci.getStatusPenyelesaian()));
        }

        g.gridx = 0; g.gridy = 3; form.add(new JLabel("Status Penanganan:*"), g);
        g.gridx = 1; g.gridy = 3; form.add(cmbStatus, g);

        // 5. Deskripsi Kejadian
        JTextArea txtDeskripsi = new JTextArea(isEdit && ci.getDeskripsiKejadian() != null ? ci.getDeskripsiKejadian() : "", 4, 25);
        txtDeskripsi.setLineWrap(true);
        txtDeskripsi.setWrapStyleWord(true);
        JScrollPane spDeskripsi = new JScrollPane(txtDeskripsi);
        spDeskripsi.setPreferredSize(new Dimension(380, 85));

        g.gridx = 0; g.gridy = 4; form.add(new JLabel("Deskripsi Kejadian:*"), g);
        g.gridx = 1; g.gridy = 4; form.add(spDeskripsi, g);

        // 6. Tindakan De-eskalasi
        String defaultTindakan = isEdit && ci.getTindakanPenanganan() != null ? ci.getTindakanPenanganan() : "De-eskalasi verbal, pemisahan lingkungan, medikasi darurat jika diinstruksikan dokter.";
        JTextArea txtTindakan = new JTextArea(defaultTindakan, 4, 25);
        txtTindakan.setLineWrap(true);
        txtTindakan.setWrapStyleWord(true);
        JScrollPane spTindakan = new JScrollPane(txtTindakan);
        spTindakan.setPreferredSize(new Dimension(380, 85));

        g.gridx = 0; g.gridy = 5; form.add(new JLabel("Tindakan De-eskalasi:*"), g);
        g.gridx = 1; g.gridy = 5; form.add(spTindakan, g);

        root.add(headerPanel, BorderLayout.NORTH);
        root.add(form, BorderLayout.CENTER);

        // Bottom Action Buttons
        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnBar.setOpaque(false);
        btnBar.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JButton btnBatal = UiUtils.createSecondaryButton("Batal");
        btnBatal.setPreferredSize(new Dimension(100, 36));
        btnBatal.addActionListener(e -> dlg.dispose());

        JButton btnSimpan = UiUtils.createPrimaryButton(isEdit ? "Simpan Perubahan Evaluasi" : "Simpan Laporan Insiden");
        btnSimpan.setPreferredSize(new Dimension(215, 36));
        btnSimpan.addActionListener(e -> {
            try {
                Pasien selP = (Pasien) cmbPasien.getSelectedItem();
                if (selP == null) throw new Exception("Pasien belum dipilih!");

                String desk = txtDeskripsi.getText().trim();
                if (desk.isEmpty()) throw new Exception("Deskripsi kronologi kejadian tidak boleh kosong!");

                CatatanInsiden nci = isEdit ? ci : new CatatanInsiden();
                nci.setIdPasien(selP.getId());
                if (!isEdit) {
                    nci.setTanggalInsiden(Date.valueOf(LocalDate.now()));
                    nci.setWaktuInsiden(Time.valueOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
                }
                nci.setJenisInsiden(toJenisRaw((String) cmbJenis.getSelectedItem()));
                nci.setTingkatRisiko(toRisikoRaw((String) cmbRisiko.getSelectedItem()));
                nci.setStatusPenyelesaian(toStatusRaw((String) cmbStatus.getSelectedItem()));
                nci.setDeskripsiKejadian(desk);
                nci.setTindakanPenanganan(txtTindakan.getText().trim());

                keperawatanService.saveInsiden(nci);
                UiUtils.showSuccess(this, isEdit ? "Evaluasi insiden berhasil diperbarui!" : "Laporan insiden berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        btnBar.add(btnBatal);
        btnBar.add(btnSimpan);
        root.add(btnBar, BorderLayout.SOUTH);

        dlg.add(root);
        dlg.pack();
        dlg.setMinimumSize(new Dimension(580, 560));
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    private void deleteInsiden() {
        CatatanInsiden ci = getSelectedInsiden();
        if (ci == null) return;
        if (UiUtils.confirm(this, "Hapus laporan insiden untuk pasien " + ci.getNamaPasien() + " ini?")) {
            try {
                keperawatanService.deleteInsiden(ci.getId());
                UiUtils.showSuccess(this, "Laporan insiden berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
