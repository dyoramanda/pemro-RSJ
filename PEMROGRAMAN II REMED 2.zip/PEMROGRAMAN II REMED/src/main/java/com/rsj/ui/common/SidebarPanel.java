package com.rsj.ui.common;

import com.rsj.model.User;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class SidebarPanel extends JPanel {

    public static class MenuItem {
        public final String id;
        public final String label;

        public MenuItem(String id, String label) {
            this.id = id;
            this.label = label;
        }
    }

    private final Consumer<String> onSelectMenu;
    private final JPanel menuContainer;
    private final List<JButton> menuButtons = new ArrayList<>();
    private String activeMenuId = "";

    public SidebarPanel(Consumer<String> onSelectMenu) {
        this.onSelectMenu = onSelectMenu;

        setLayout(new BorderLayout());
        setBackground(UiUtils.COLOR_PRIMARY);
        setPreferredSize(new Dimension(240, 700));

        // Brand Header
        JPanel brandPanel = new JPanel();
        brandPanel.setLayout(new BoxLayout(brandPanel, BoxLayout.Y_AXIS));
        brandPanel.setOpaque(false);
        brandPanel.setBorder(BorderFactory.createEmptyBorder(24, 20, 24, 20));

        JLabel lblLogo = new JLabel("RSJ SEHAT JIWA");
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblLogo.setForeground(Color.WHITE);

        JLabel lblTag = new JLabel("Pusat Layanan Kesehatan Mental");
        lblTag.setFont(UiUtils.FONT_SMALL);
        lblTag.setForeground(new Color(0x94, 0xA3, 0xB8));

        brandPanel.add(lblLogo);
        brandPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        brandPanel.add(lblTag);

        menuContainer = new JPanel();
        menuContainer.setLayout(new BoxLayout(menuContainer, BoxLayout.Y_AXIS));
        menuContainer.setOpaque(false);
        menuContainer.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));

        // Footer info in sidebar
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setOpaque(false);
        footerPanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel lblVer = new JLabel("v1.0.0 • Java Swing 17", SwingConstants.CENTER);
        lblVer.setFont(UiUtils.FONT_SMALL);
        lblVer.setForeground(new Color(0x64, 0x74, 0x8B));
        footerPanel.add(lblVer, BorderLayout.CENTER);

        add(brandPanel, BorderLayout.NORTH);
        add(menuContainer, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);
    }

    public void rebuildMenuForCurrentUser() {
        menuContainer.removeAll();
        menuButtons.clear();

        User u = SessionManager.getCurrentUser();
        if (u == null) {
            menuContainer.revalidate();
            menuContainer.repaint();
            return;
        }

        List<MenuItem> items = getMenuItemsForRole(u.getRole());
        for (MenuItem item : items) {
            JButton btn = createMenuButton(item);
            menuButtons.add(btn);
            menuContainer.add(btn);
            menuContainer.add(Box.createRigidArea(new Dimension(0, 6)));
        }

        if (!items.isEmpty()) {
            setActiveMenu(items.get(0).id);
        }

        menuContainer.revalidate();
        menuContainer.repaint();
    }

    private List<MenuItem> getMenuItemsForRole(String role) {
        List<MenuItem> list = new ArrayList<>();
        switch (role) {
            case "ADMIN":
                list.add(new MenuItem("ADMIN_DASHBOARD", "Dashboard Utama"));
                list.add(new MenuItem("ADMIN_USER", "Manajemen User"));
                list.add(new MenuItem("ADMIN_DOKTER_PERAWAT", "Dokter & Perawat"));
                list.add(new MenuItem("ADMIN_RUANGAN_BED", "Ruangan & Bed"));
                list.add(new MenuItem("ADMIN_LAPORAN", "Laporan & Cetak"));
                break;
            case "PETUGAS_PENDAFTARAN":
                list.add(new MenuItem("PENDAFTARAN_DASHBOARD", "Dashboard Petugas"));
                list.add(new MenuItem("PENDAFTARAN_PASIEN", "Data Pasien"));
                list.add(new MenuItem("PENDAFTARAN_PJ", "Penanggung Jawab"));
                list.add(new MenuItem("PENDAFTARAN_KUNJUNGAN", "Pendaftaran Kunjungan"));
                break;
            case "DOKTER":
                list.add(new MenuItem("DOKTER_DASHBOARD", "Pasien Hari Ini"));
                list.add(new MenuItem("DOKTER_JADWAL", "Jadwal Praktik"));
                list.add(new MenuItem("DOKTER_REKAM_MEDIS", "Pemeriksaan Rekam Medis"));
                list.add(new MenuItem("DOKTER_DIAGNOSIS_RESEP", "Diagnosis & Resep"));
                break;
            case "PERAWAT":
                list.add(new MenuItem("PERAWAT_DASHBOARD", "Dashboard Perawat"));
                list.add(new MenuItem("PERAWAT_OBSERVASI", "Observasi Harian"));
                list.add(new MenuItem("PERAWAT_BED", "Manajemen Bed Inap"));
                list.add(new MenuItem("PERAWAT_INSIDEN", "Catatan Insiden"));
                break;
            case "APOTEKER":
                list.add(new MenuItem("APOTEKER_DASHBOARD", "Dashboard Farmasi"));
                list.add(new MenuItem("APOTEKER_OBAT", "Stok Obat Jiwa"));
                list.add(new MenuItem("APOTEKER_RESEP", "Resep Masuk & Serah"));
                break;
            case "KASIR":
                list.add(new MenuItem("KASIR_TAGIHAN", "Data Tagihan"));
                list.add(new MenuItem("KASIR_PEMBAYARAN", "Pembayaran & Struk"));
                break;
            case "KELUARGA_PASIEN":
                list.add(new MenuItem("KELUARGA_DASHBOARD", "Dashboard Keluarga"));
                list.add(new MenuItem("KELUARGA_PERKEMBANGAN", "Perkembangan Pasien"));
                list.add(new MenuItem("KELUARGA_BOOKING", "Jadwal Kunjungan"));
                list.add(new MenuItem("KELUARGA_TAGIHAN", "Tagihan Saya"));
                break;
        }
        return list;
    }

    private JButton createMenuButton(MenuItem item) {
        JButton btn = new JButton(item.label) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean isActive = item.id.equals(activeMenuId);
                if (isActive) {
                    g2.setColor(UiUtils.COLOR_ACCENT);
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                } else if (getModel().isRollover()) {
                    g2.setColor(new Color(0x13, 0x62, 0x85));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };

        btn.setFont(UiUtils.FONT_BOLD);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        btn.addActionListener(e -> {
            setActiveMenu(item.id);
            if (onSelectMenu != null) onSelectMenu.accept(item.id);
        });

        return btn;
    }

    public void setActiveMenu(String id) {
        this.activeMenuId = id;
        for (JButton b : menuButtons) {
            b.repaint();
        }
    }
}
