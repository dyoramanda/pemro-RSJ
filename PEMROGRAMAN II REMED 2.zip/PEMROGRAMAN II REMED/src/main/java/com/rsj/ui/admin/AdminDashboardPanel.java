package com.rsj.ui.admin;

import com.rsj.dao.AuditLogDao;
import com.rsj.dao.LaporanDao;
import com.rsj.model.AuditLog;
import com.rsj.ui.common.SimpleChartPanel;
import com.rsj.ui.common.StatCard;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class AdminDashboardPanel extends JPanel {

    private final LaporanDao laporanDao = new LaporanDao();
    private final AuditLogDao auditLogDao = new AuditLogDao();

    private StatCard cardPasienTotal;
    private StatCard cardPasienInap;
    private StatCard cardBedOccupancy;
    private StatCard cardPendapatan;
    private JPanel chartArea;
    private JTable tblAudit;
    private DefaultTableModel auditModel;

    public AdminDashboardPanel() {
        setLayout(new BorderLayout(0, 16));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);

        // 1. Stat Cards Row
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 14));
        statsRow.setOpaque(false);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        cardPasienTotal = new StatCard("Total Pasien Jiwa", "0", "Terdaftar di SIMRS", UiUtils.COLOR_PRIMARY);
        cardPasienInap = new StatCard("Rawat Inap Aktif", "0", "Dalam Pengawasan", UiUtils.COLOR_WARNING);
        cardBedOccupancy = new StatCard("Hunian Tempat Tidur", "0%", "Kapasitas Terisi", UiUtils.COLOR_ACCENT);
        cardPendapatan = new StatCard("Pendapatan Bulan Ini", "Rp 0", "Penerimaan Kasir", UiUtils.COLOR_SUCCESS);

        statsRow.add(cardPasienTotal);
        statsRow.add(cardPasienInap);
        statsRow.add(cardBedOccupancy);
        statsRow.add(cardPendapatan);

        // 2. Charts Row
        chartArea = new JPanel(new GridLayout(1, 2, 14, 14));
        chartArea.setOpaque(false);
        chartArea.setMaximumSize(new Dimension(Integer.MAX_VALUE, 240));
        chartArea.setPreferredSize(new Dimension(900, 240));

        // 3. Recent Audit Log Activity Table
        JPanel auditCard = UiUtils.createCardPanel();
        auditCard.setLayout(new BorderLayout(0, 10));

        JLabel lblAuditTitle = new JLabel("Aktivitas & Audit Log Sistem Terkini");
        lblAuditTitle.setFont(UiUtils.FONT_HEADER);
        lblAuditTitle.setForeground(UiUtils.COLOR_PRIMARY);

        auditModel = new DefaultTableModel(new String[]{"Waktu", "User", "Aksi", "Modul", "Keterangan Aktivitas"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblAudit = new JTable(auditModel);
        UiUtils.styleTable(tblAudit);
        JScrollPane spAudit = new JScrollPane(tblAudit);
        spAudit.setPreferredSize(new Dimension(900, 180));
        spAudit.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        auditCard.add(lblAuditTitle, BorderLayout.NORTH);
        auditCard.add(spAudit, BorderLayout.CENTER);

        main.add(statsRow);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(chartArea);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(auditCard);

        JScrollPane scrollPane = new JScrollPane(main);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);

        refreshData();
    }

    public void refreshData() {
        // Load stats
        Map<String, Object> stats = laporanDao.getAdminDashboardStats();
        int totalPasien = (int) stats.getOrDefault("totalPasien", 0);
        int pasienInap = (int) stats.getOrDefault("pasienRawatInap", 0);
        int occPercent = (int) stats.getOrDefault("occupancyPercent", 0);
        BigDecimal income = (BigDecimal) stats.getOrDefault("pendapatanBulanIni", BigDecimal.ZERO);

        cardPasienTotal.setValue(String.valueOf(totalPasien));
        cardPasienInap.setValue(String.valueOf(pasienInap) + " Orang");
        cardBedOccupancy.setValue(occPercent + "%");
        cardPendapatan.setValue(UiUtils.formatRupiah(income));

        // Load charts
        chartArea.removeAll();
        Map<String, Integer> trendData = laporanDao.getMonthlyVisitTrend();
        SimpleChartPanel barChart = new SimpleChartPanel("Tren Kunjungan Pasien (6 Bulan)", trendData, SimpleChartPanel.ChartType.BAR);

        Map<String, Integer> bedData = laporanDao.getBedDistribution();
        SimpleChartPanel distChart = new SimpleChartPanel("Distribusi Pasien Rawat Inap per Ruangan", bedData, SimpleChartPanel.ChartType.HORIZONTAL_BAR);

        chartArea.add(barChart);
        chartArea.add(distChart);
        chartArea.revalidate();
        chartArea.repaint();

        // Load audit logs
        auditModel.setRowCount(0);
        List<AuditLog> logs = auditLogDao.getAll(15);
        for (AuditLog l : logs) {
            auditModel.addRow(new Object[]{
                    UiUtils.formatDateTime(l.getCreatedAt()),
                    l.getUsername(),
                    l.getAksi(),
                    l.getModul(),
                    l.getDeskripsi()
            });
        }
    }
}
