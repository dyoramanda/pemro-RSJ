package com.rsj.ui.kasir;

import com.rsj.model.Pendaftaran;
import com.rsj.model.Tagihan;
import com.rsj.service.KasirService;
import com.rsj.service.PelayananService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class TagihanPanel extends JPanel {

    private final KasirService kasirService = new KasirService();
    private final PelayananService pelayananService = new PelayananService();

    private final JTable tblTagihan;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbStatus;
    private List<Tagihan> tagihanList;

    public TagihanPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(14);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari no tagihan / pasien...");
        txtSearch.addActionListener(e -> reloadData());

        cmbStatus = new JComboBox<>(new String[]{"SEMUA", "BELUM_LUNAS", "LUNAS", "DICICIL"});
        cmbStatus.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(new JLabel("Status:"));
        left.add(cmbStatus);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnGenerate = UiUtils.createPrimaryButton("+ Terbitkan Tagihan Baru");
        btnGenerate.addActionListener(e -> showGenerateTagihanForm());

        right.add(btnGenerate);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. Tagihan", "Tanggal", "No. RM", "Nama Pasien", "Layanan", "Biaya Kamar", "Biaya Dokter", "Biaya Obat", "Biaya Tindakan", "Total Tagihan", "Terbayar", "Sisa", "Status"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblTagihan = new JTable(model);
        UiUtils.styleTable(tblTagihan);
        cardTable.add(new JScrollPane(tblTagihan), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String st = (String) cmbStatus.getSelectedItem();

        tagihanList = kasirService.searchTagihan(kw, st);
        model.setRowCount(0);
        for (Tagihan t : tagihanList) {
            model.addRow(new Object[]{
                    t.getId(),
                    t.getNoTagihan(),
                    UiUtils.formatDate(t.getTanggalTagihan()),
                    t.getNoRekamMedis(),
                    t.getNamaPasien(),
                    t.getJenisKunjungan(),
                    UiUtils.formatRupiah(t.getTotalBiayaKamar()),
                    UiUtils.formatRupiah(t.getTotalBiayaDokter()),
                    UiUtils.formatRupiah(t.getTotalBiayaObat()),
                    UiUtils.formatRupiah(t.getTotalBiayaTindakan()),
                    UiUtils.formatRupiah(t.getTotalAkhir()),
                    UiUtils.formatRupiah(t.getJumlahTerbayar()),
                    UiUtils.formatRupiah(t.getSisaTagihan()),
                    t.getStatusPembayaran()
            });
        }
    }

    private void showGenerateTagihanForm() {
        JDialog dlg = new JDialog((Frame) null, "Penerbitan Tagihan Perawatan Pasien", true);
        dlg.setSize(520, 520);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<Pendaftaran> pendaftaranList = pelayananService.getAllPendaftaran();
        JComboBox<Pendaftaran> cmbPendaftaran = new JComboBox<>(pendaftaranList.toArray(new Pendaftaran[0]));

        JTextField txtKamar = new JTextField("0");
        JTextField txtDokter = new JTextField("200000");
        JTextField txtObat = new JTextField("170000");
        JTextField txtTindakan = new JTextField("100000");
        JTextField txtTotal = new JTextField("470000");
        txtTotal.setEditable(false);

        Runnable hitungTotal = () -> {
            try {
                BigDecimal k = new BigDecimal(txtKamar.getText().trim());
                BigDecimal d = new BigDecimal(txtDokter.getText().trim());
                BigDecimal o = new BigDecimal(txtObat.getText().trim());
                BigDecimal t = new BigDecimal(txtTindakan.getText().trim());
                txtTotal.setText(k.add(d).add(o).add(t).toString());
            } catch (Exception ignored) {}
        };

        cmbPendaftaran.addActionListener(e -> {
            Pendaftaran pd = (Pendaftaran) cmbPendaftaran.getSelectedItem();
            if (pd != null) {
                try {
                    Tagihan kalk = kasirService.hitungTagihanOtomatis(pd.getId());
                    txtKamar.setText(kalk.getTotalBiayaKamar().toString());
                    txtDokter.setText(kalk.getTotalBiayaDokter().toString());
                    txtObat.setText(kalk.getTotalBiayaObat().toString());
                    txtTindakan.setText(kalk.getTotalBiayaTindakan().toString());
                    txtTotal.setText(kalk.getTotalAkhir().toString());
                } catch (Exception ignored) {}
            }
        });

        txtKamar.addActionListener(e -> hitungTotal.run());
        txtDokter.addActionListener(e -> hitungTotal.run());
        txtObat.addActionListener(e -> hitungTotal.run());
        txtTindakan.addActionListener(e -> hitungTotal.run());

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pilih Pendaftaran Pasien:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbPendaftaran, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Biaya Kamar Inap (Rp):"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtKamar, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Biaya Konsultasi Dokter:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(txtDokter, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Biaya Farmasi / Obat:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtObat, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Biaya Tindakan / Askep:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtTindakan, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Total Tagihan Akhir:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(txtTotal, g);

        JButton btnSimpan = UiUtils.createPrimaryButton("Terbitkan Tagihan Resmi");
        btnSimpan.addActionListener(e -> {
            try {
                hitungTotal.run();
                Pendaftaran selPd = (Pendaftaran) cmbPendaftaran.getSelectedItem();
                if (selPd == null) throw new Exception("Pendaftaran pasien belum dipilih!");

                Tagihan tag = new Tagihan();
                tag.setIdPendaftaran(selPd.getId());
                tag.setIdPasien(selPd.getIdPasien());
                tag.setTanggalTagihan(Date.valueOf(LocalDate.now()));
                tag.setTotalBiayaKamar(new BigDecimal(txtKamar.getText().trim()));
                tag.setTotalBiayaDokter(new BigDecimal(txtDokter.getText().trim()));
                tag.setTotalBiayaObat(new BigDecimal(txtObat.getText().trim()));
                tag.setTotalBiayaTindakan(new BigDecimal(txtTindakan.getText().trim()));
                tag.setTotalAkhir(new BigDecimal(txtTotal.getText().trim()));
                tag.setStatusPembayaran("BELUM_LUNAS");
                tag.setBatasWaktu(Date.valueOf(LocalDate.now().plusDays(7)));

                kasirService.simpanTagihan(tag);
                UiUtils.showSuccess(this, "Tagihan " + tag.getNoTagihan() + " berhasil diterbitkan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(16, 5, 5, 5);
        pan.add(btnSimpan, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }
}
