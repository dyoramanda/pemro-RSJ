package com.rsj.ui.dokter;

import com.rsj.dao.DokterDao;
import com.rsj.dao.PendaftaranDao;
import com.rsj.model.Dokter;
import com.rsj.model.Pendaftaran;
import com.rsj.ui.common.StatCard;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DokterDashboardPanel extends JPanel {

    private final PendaftaranDao pendaftaranDao = new PendaftaranDao();
    private final DokterDao dokterDao = new DokterDao();

    private StatCard cardMenunggu;
    private StatCard cardSelesai;
    private StatCard cardTotalHariIni;
    private final JTable tblPasienHariIni;
    private final DefaultTableModel model;
    private List<Pendaftaran> currentList;

    public DokterDashboardPanel() {
        setLayout(new BorderLayout(0, 16));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);

        // Stats Row
        JPanel statsRow = new JPanel(new GridLayout(1, 3, 14, 14));
        statsRow.setOpaque(false);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        cardMenunggu = new StatCard("Pasien Menunggu", "0", "Siap Diperiksa", UiUtils.COLOR_WARNING);
        cardSelesai = new StatCard("Sudah Diperiksa", "0", "Rekam Medis Terisi", UiUtils.COLOR_SUCCESS);
        cardTotalHariIni = new StatCard("Total Kuota Hari Ini", "0", "Jadwal Praktik", UiUtils.COLOR_PRIMARY);

        statsRow.add(cardMenunggu);
        statsRow.add(cardSelesai);
        statsRow.add(cardTotalHariIni);

        // Pasien Hari ini Card
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 10));

        JPanel topT = new JPanel(new BorderLayout());
        topT.setOpaque(false);
        JLabel lblT = new JLabel("Daftar Antrean Pasien Psikiatri Hari Ini");
        lblT.setFont(UiUtils.FONT_HEADER);
        lblT.setForeground(UiUtils.COLOR_PRIMARY);

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan");
        btnRefresh.addActionListener(e -> refreshData());

        topT.add(lblT, BorderLayout.WEST);
        topT.add(btnRefresh, BorderLayout.EAST);

        model = new DefaultTableModel(new String[]{
                "No. Pendaftaran", "No. RM", "Nama Pasien", "Layanan", "Bed / Poli", "Status", "Keluhan Pasien"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPasienHariIni = new JTable(model);
        UiUtils.styleTable(tblPasienHariIni);
        JScrollPane sp = new JScrollPane(tblPasienHariIni);
        sp.setPreferredSize(new Dimension(900, 360));
        sp.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        cardTable.add(topT, BorderLayout.NORTH);
        cardTable.add(sp, BorderLayout.CENTER);

        main.add(statsRow);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(cardTable);

        JScrollPane scroll = new JScrollPane(main);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        refreshData();
    }

    public void refreshData() {
        int dokterId = 1; // Default
        if (SessionManager.getCurrentUser() != null) {
            Dokter d = dokterDao.findByUserId(SessionManager.getCurrentUser().getId());
            if (d != null) dokterId = d.getId();
        }

        currentList = pendaftaranDao.findByDokterId(dokterId, null, null);
        long menunggu = currentList.stream().filter(p -> "MENUNGGU".equalsIgnoreCase(p.getStatusPendaftaran())).count();
        long selesai = currentList.stream().filter(p -> "SELESAI".equalsIgnoreCase(p.getStatusPendaftaran())).count();

        cardMenunggu.setValue(String.valueOf(menunggu));
        cardSelesai.setValue(String.valueOf(selesai));
        cardTotalHariIni.setValue(String.valueOf(currentList.size()));

        model.setRowCount(0);
        for (Pendaftaran p : currentList) {
            String bed = p.getNomorBed() != null ? (p.getNamaRuangan() + " - " + p.getNomorBed()) : "Rawat Jalan";
            model.addRow(new Object[]{
                    p.getNoPendaftaran(),
                    p.getNoRekamMedis(),
                    p.getNamaPasien(),
                    p.getJenisKunjungan(),
                    bed,
                    p.getStatusPendaftaran(),
                    p.getKeluhanUtama()
            });
        }
    }
}
