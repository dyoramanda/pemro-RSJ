package com.rsj.ui.perawat;

import com.rsj.dao.LaporanDao;
import com.rsj.dao.ObservasiHarianDao;
import com.rsj.model.ObservasiHarian;
import com.rsj.ui.common.StatCard;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class PerawatDashboardPanel extends JPanel {

    private final LaporanDao laporanDao = new LaporanDao();
    private final ObservasiHarianDao observasiDao = new ObservasiHarianDao();

    private StatCard cardInap;
    private StatCard cardObsHariIni;
    private StatCard cardBedTerisi;
    private StatCard cardInsiden;

    private final JTable tblObservasi;
    private final DefaultTableModel model;

    public PerawatDashboardPanel() {
        setLayout(new BorderLayout(0, 16));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);

        // Stats Row
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 14));
        statsRow.setOpaque(false);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        cardInap = new StatCard("Pasien Rawat Inap", "0", "Bangsal Jiwa", UiUtils.COLOR_PRIMARY);
        cardBedTerisi = new StatCard("Tempat Tidur Terisi", "0", "Dalam Pemantauan", UiUtils.COLOR_WARNING);
        cardObsHariIni = new StatCard("Observasi Terinput", "0", "Pencatatan Keperawatan", UiUtils.COLOR_ACCENT);
        cardInsiden = new StatCard("Status Keamanan", "Aman", "Zero Incident Shift", UiUtils.COLOR_SUCCESS);

        statsRow.add(cardInap);
        statsRow.add(cardBedTerisi);
        statsRow.add(cardObsHariIni);
        statsRow.add(cardInsiden);

        // Recent Observations Table Card
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 10));

        JPanel topT = new JPanel(new BorderLayout());
        topT.setOpaque(false);
        JLabel lblT = new JLabel("Pemantauan Observasi Harian Pasien Rawat Inap Terkini");
        lblT.setFont(UiUtils.FONT_HEADER);
        lblT.setForeground(UiUtils.COLOR_PRIMARY);

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan");
        btnRefresh.addActionListener(e -> refreshData());

        topT.add(lblT, BorderLayout.WEST);
        topT.add(btnRefresh, BorderLayout.EAST);

        model = new DefaultTableModel(new String[]{
                "Tanggal", "Jam", "No. RM", "Nama Pasien", "Bed", "Kondisi", "Mood", "Tidur", "Obat", "Catatan Perilaku"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblObservasi = new JTable(model);
        UiUtils.styleTable(tblObservasi);
        JScrollPane sp = new JScrollPane(tblObservasi);
        sp.setPreferredSize(new Dimension(900, 360));
        sp.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        cardTable.add(topT, BorderLayout.NORTH);
        cardTable.add(sp, BorderLayout.CENTER);

        main.add(statsRow);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(cardTable);

        JScrollPane scroll = new JScrollPane(main);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        refreshData();
    }

    public void refreshData() {
        Map<String, Object> stats = laporanDao.getAdminDashboardStats();
        int inap = (int) stats.getOrDefault("pasienRawatInap", 0);
        int terisi = (int) stats.getOrDefault("bedTerisi", 0);

        cardInap.setValue(inap + " Orang");
        cardBedTerisi.setValue(terisi + " Bed");

        List<ObservasiHarian> obsList = observasiDao.findAll();
        cardObsHariIni.setValue(String.valueOf(obsList.size()));

        model.setRowCount(0);
        for (ObservasiHarian o : obsList) {
            model.addRow(new Object[]{
                    UiUtils.formatDate(o.getTanggalObservasi()),
                    UiUtils.formatTime(o.getWaktuObservasi()),
                    o.getNoRekamMedis(),
                    o.getNamaPasien(),
                    o.getNomorBed() != null ? o.getNomorBed() : "-",
                    o.getStatusKondisi(),
                    o.getStatusMood(),
                    o.getKualitasTidur(),
                    o.getKepatuhanObat(),
                    o.getCatatanPerilaku()
            });
        }
    }
}
