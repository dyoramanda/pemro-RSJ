package com.rsj.ui.admin;

import com.rsj.model.User;
import com.rsj.service.MasterDataService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class UserManagementPanel extends JPanel {

    private final MasterDataService masterService = new MasterDataService();
    private final JTable tblUsers;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbRoleFilter;
    private List<User> currentUsers;

    public UserManagementPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        // Top Bar: Search, Filter, Action Buttons
        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout(10, 10));

        JPanel leftFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftFilter.setOpaque(false);

        txtSearch = new JTextField(15);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari nama / username...");
        txtSearch.addActionListener(e -> reloadData());

        cmbRoleFilter = new JComboBox<>(new String[]{"SEMUA", "ADMIN", "PETUGAS_PENDAFTARAN", "DOKTER", "PERAWAT", "APOTEKER", "KASIR", "KELUARGA_PASIEN"});
        cmbRoleFilter.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        leftFilter.add(new JLabel("Pencarian:"));
        leftFilter.add(txtSearch);
        leftFilter.add(new JLabel("Role:"));
        leftFilter.add(cmbRoleFilter);
        leftFilter.add(btnSearch);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightActions.setOpaque(false);

        JButton btnTambah = UiUtils.createPrimaryButton("+ Tambah Pengguna");
        btnTambah.addActionListener(e -> showUserForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah");
        btnEdit.addActionListener(e -> {
            User u = getSelectedUser();
            if (u != null) showUserForm(u);
        });

        JButton btnResetPass = UiUtils.createSecondaryButton("Reset Sandi");
        btnResetPass.addActionListener(e -> resetPassword());

        JButton btnHapus = UiUtils.createDangerButton("Hapus");
        btnHapus.addActionListener(e -> deleteUser());

        rightActions.add(btnTambah);
        rightActions.add(btnEdit);
        rightActions.add(btnResetPass);
        rightActions.add(btnHapus);

        topBar.add(leftFilter, BorderLayout.WEST);
        topBar.add(rightActions, BorderLayout.EAST);

        // Table in Card
        JPanel tableCard = UiUtils.createCardPanel();
        tableCard.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"ID", "Username", "Nama Lengkap", "Role (Hak Akses)", "No. Telepon", "Email", "Status", "Tanggal Dibuat"}, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblUsers = new JTable(model);
        UiUtils.styleTable(tblUsers);
        JScrollPane sp = new JScrollPane(tblUsers);
        sp.setBorder(BorderFactory.createEmptyBorder());

        tableCard.add(sp, BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(tableCard, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String role = (String) cmbRoleFilter.getSelectedItem();
        currentUsers = masterService.searchUsers(kw, role);

        model.setRowCount(0);
        for (User u : currentUsers) {
            model.addRow(new Object[]{
                    u.getId(),
                    u.getUsername(),
                    u.getNamaLengkap(),
                    u.getRole(),
                    u.getNoTelp() != null ? u.getNoTelp() : "-",
                    u.getEmail() != null ? u.getEmail() : "-",
                    u.isStatusAktif() ? "Aktif" : "Nonaktif",
                    UiUtils.formatDateTime(u.getCreatedAt())
            });
        }
    }

    private User getSelectedUser() {
        int row = tblUsers.getSelectedRow();
        if (row < 0) {
            UiUtils.showError(this, "Silakan pilih baris pengguna terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(row, 0);
        return currentUsers.stream().filter(u -> u.getId() == id).findFirst().orElse(null);
    }

    private void showUserForm(User user) {
        boolean isEdit = user != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Data Pengguna" : "Tambah Pengguna Baru", true);
        dlg.setSize(440, 430);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);
        dlg.setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtUName = new JTextField(isEdit ? user.getUsername() : "");
        if (isEdit) txtUName.setEditable(false);
        JPasswordField txtPass = new JPasswordField(isEdit ? "******" : "123456");
        if (isEdit) txtPass.setEnabled(false);

        JTextField txtNama = new JTextField(isEdit ? user.getNamaLengkap() : "");
        JComboBox<String> cmbRole = new JComboBox<>(new String[]{"ADMIN", "PETUGAS_PENDAFTARAN", "DOKTER", "PERAWAT", "APOTEKER", "KASIR", "KELUARGA_PASIEN"});
        if (isEdit) cmbRole.setSelectedItem(user.getRole());

        JTextField txtTelp = new JTextField(isEdit && user.getNoTelp() != null ? user.getNoTelp() : "");
        JTextField txtEmail = new JTextField(isEdit && user.getEmail() != null ? user.getEmail() : "");
        JCheckBox chkAktif = new JCheckBox("Akun Aktif", isEdit ? user.isStatusAktif() : true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; p.add(new JLabel("Username:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; p.add(txtUName, g);

        g.gridx = 0; g.gridy = 1; p.add(new JLabel("Kata Sandi Awal:"), g);
        g.gridx = 1; g.gridy = 1; p.add(txtPass, g);

        g.gridx = 0; g.gridy = 2; p.add(new JLabel("Nama Lengkap:"), g);
        g.gridx = 1; g.gridy = 2; p.add(txtNama, g);

        g.gridx = 0; g.gridy = 3; p.add(new JLabel("Role / Hak Akses:"), g);
        g.gridx = 1; g.gridy = 3; p.add(cmbRole, g);

        g.gridx = 0; g.gridy = 4; p.add(new JLabel("No. Telepon:"), g);
        g.gridx = 1; g.gridy = 4; p.add(txtTelp, g);

        g.gridx = 0; g.gridy = 5; p.add(new JLabel("Email:"), g);
        g.gridx = 1; g.gridy = 5; p.add(txtEmail, g);

        g.gridx = 1; g.gridy = 6; p.add(chkAktif, g);

        JButton btnSimpan = UiUtils.createPrimaryButton("Simpan Data");
        btnSimpan.addActionListener(e -> {
            String uname = txtUName.getText().trim();
            String nama = txtNama.getText().trim();
            if (uname.isEmpty() || nama.isEmpty()) {
                UiUtils.showError(dlg, "Username dan Nama Lengkap wajib diisi!");
                return;
            }

            try {
                if (!isEdit) {
                    User nu = new User();
                    nu.setUsername(uname);
                    nu.setNamaLengkap(nama);
                    nu.setRole((String) cmbRole.getSelectedItem());
                    nu.setNoTelp(txtTelp.getText().trim());
                    nu.setEmail(txtEmail.getText().trim());
                    nu.setStatusAktif(chkAktif.isSelected());
                    masterService.createUser(nu, new String(txtPass.getPassword()));
                } else {
                    user.setNamaLengkap(nama);
                    user.setRole((String) cmbRole.getSelectedItem());
                    user.setNoTelp(txtTelp.getText().trim());
                    user.setEmail(txtEmail.getText().trim());
                    user.setStatusAktif(chkAktif.isSelected());
                    masterService.updateUser(user);
                }
                UiUtils.showSuccess(this, "Data pengguna berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 7; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        p.add(btnSimpan, g);

        dlg.add(p, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void resetPassword() {
        User u = getSelectedUser();
        if (u == null) return;

        String newP = JOptionPane.showInputDialog(this, "Masukkan Kata Sandi Baru untuk " + u.getUsername() + ":", "Reset Kata Sandi", JOptionPane.PLAIN_MESSAGE);
        if (newP != null && !newP.trim().isEmpty()) {
            try {
                masterService.resetUserPassword(u.getId(), newP.trim());
                UiUtils.showSuccess(this, "Kata sandi user " + u.getUsername() + " berhasil di-reset!");
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }

    private void deleteUser() {
        User u = getSelectedUser();
        if (u == null) return;

        if (UiUtils.confirm(this, "Apakah Anda yakin ingin menghapus user '" + u.getUsername() + "'?")) {
            try {
                masterService.deleteUser(u.getId());
                UiUtils.showSuccess(this, "User berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
