package com.rsj.ui.keluarga;

import com.rsj.model.Pasien;
import com.rsj.model.Tagihan;
import com.rsj.service.KasirService;
import com.rsj.service.KeluargaService;
import com.rsj.util.PrintHelper;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TagihanKeluargaPanel extends JPanel {

    private final KeluargaService keluargaService = new KeluargaService();
    private final KasirService kasirService = new KasirService();

    private final JComboBox<Pasien> cmbPasien;
    private final JTable tblTagihan;
    private final DefaultTableModel model;
    private List<Tagihan> tagihanList;

    public TagihanKeluargaPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        List<Pasien> pasiens = keluargaService.getPasienKeluarga();
        cmbPasien = new JComboBox<>(pasiens.toArray(new Pasien[0]));
        cmbPasien.addActionListener(e -> reloadData());

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan");
        btnRefresh.addActionListener(e -> reloadData());

        left.add(new JLabel("Pilih Pasien Keluarga:"));
        left.add(cmbPasien);
        left.add(btnRefresh);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnCetak = UiUtils.createSecondaryButton("Cetak Salinan Tagihan");
        btnCetak.addActionListener(e -> printInvoice());
        right.add(btnCetak);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 10));

        JLabel lblTitle = new JLabel("Rincian Transparansi Tagihan & Biaya Perawatan Pasien");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        model = new DefaultTableModel(new String[]{
                "ID", "No. Tagihan", "Tanggal Terbit", "Layanan", "Biaya Kamar", "Biaya Dokter", "Biaya Obat", "Biaya Tindakan", "Total Tagihan", "Sisa Pembayaran", "Status"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblTagihan = new JTable(model);
        UiUtils.styleTable(tblTagihan);

        cardTable.add(lblTitle, BorderLayout.NORTH);
        cardTable.add(new JScrollPane(tblTagihan), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        Pasien selP = (Pasien) cmbPasien.getSelectedItem();
        model.setRowCount(0);
        if (selP == null) return;

        tagihanList = keluargaService.getTagihanPasienKeluarga(selP.getId());
        for (Tagihan t : tagihanList) {
            model.addRow(new Object[]{
                    t.getId(),
                    t.getNoTagihan(),
                    UiUtils.formatDate(t.getTanggalTagihan()),
                    t.getJenisKunjungan(),
                    UiUtils.formatRupiah(t.getTotalBiayaKamar()),
                    UiUtils.formatRupiah(t.getTotalBiayaDokter()),
                    UiUtils.formatRupiah(t.getTotalBiayaObat()),
                    UiUtils.formatRupiah(t.getTotalBiayaTindakan()),
                    UiUtils.formatRupiah(t.getTotalAkhir()),
                    UiUtils.formatRupiah(t.getSisaTagihan()),
                    t.getStatusPembayaran()
            });
        }
    }

    private Tagihan getSelectedTagihan() {
        int r = tblTagihan.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris tagihan terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return tagihanList.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
    }

    private void printInvoice() {
        Tagihan t = getSelectedTagihan();
        if (t == null) return;

        JPanel invoice = new JPanel(new GridLayout(9, 1, 4, 4));
        invoice.setBackground(java.awt.Color.WHITE);
        invoice.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel l1 = new JLabel("RS JIWA SEHAT JIWA - RINCIAN TAGIHAN PERAWATAN");
        l1.setFont(UiUtils.FONT_TITLE);
        l1.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel l2 = new JLabel("No. Tagihan : " + t.getNoTagihan() + " • Status: " + t.getStatusPembayaran());
        l2.setFont(UiUtils.FONT_HEADER);
        l2.setForeground(UiUtils.COLOR_ACCENT);

        JLabel l3 = new JLabel("Nama Pasien : " + t.getNamaPasien() + " (No. RM: " + t.getNoRekamMedis() + ")");
        JLabel l4 = new JLabel("Biaya Kamar Inap  : " + UiUtils.formatRupiah(t.getTotalBiayaKamar()));
        JLabel l5 = new JLabel("Biaya Dokter      : " + UiUtils.formatRupiah(t.getTotalBiayaDokter()));
        JLabel l6 = new JLabel("Biaya Obat Farmasi: " + UiUtils.formatRupiah(t.getTotalBiayaObat()));
        JLabel l7 = new JLabel("Biaya Tindakan    : " + UiUtils.formatRupiah(t.getTotalBiayaTindakan()));
        JLabel l8 = new JLabel("TOTAL TAGIHAN AKHIR: " + UiUtils.formatRupiah(t.getTotalAkhir()));
        l8.setFont(UiUtils.FONT_BOLD);
        JLabel l9 = new JLabel("Pembayaran dapat dilakukan melalui loket Kasir RSJ atau transfer rekening resmi RSJ.");
        l9.setFont(UiUtils.FONT_SMALL);
        l9.setForeground(UiUtils.COLOR_TEXT_MUTED);

        invoice.add(l1);
        invoice.add(l2);
        invoice.add(l3);
        invoice.add(l4);
        invoice.add(l5);
        invoice.add(l6);
        invoice.add(l7);
        invoice.add(l8);
        invoice.add(l9);

        PrintHelper.printComponent(invoice);
    }
}
