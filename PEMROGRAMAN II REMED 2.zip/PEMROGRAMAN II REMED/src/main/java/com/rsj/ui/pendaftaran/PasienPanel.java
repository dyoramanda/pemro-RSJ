package com.rsj.ui.pendaftaran;

import com.rsj.model.Pasien;
import com.rsj.model.PenanggungJawab;
import com.rsj.service.PelayananService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PasienPanel extends JPanel {

    private final PelayananService pelayananService = new PelayananService();
    private final JTable tblPasien;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbStatusFilter;
    private List<Pasien> pasienList;

    public PasienPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        // Top Filter & Actions
        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(15);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari No RM / Nama / NIK...");
        txtSearch.addActionListener(e -> reloadData());

        cmbStatusFilter = new JComboBox<>(new String[]{"SEMUA", "RAWAT_JALAN", "RAWAT_INAP", "SUDAH_PULANG", "RUJUKAN"});
        cmbStatusFilter.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(new JLabel("Status:"));
        left.add(cmbStatusFilter);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Registrasi Pasien Baru");
        btnAdd.addActionListener(e -> showPasienForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah Data");
        btnEdit.addActionListener(e -> {
            Pasien p = getSelectedPasien();
            if (p != null) showPasienForm(p);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.addActionListener(e -> deletePasien());

        right.add(btnAdd);
        right.add(btnEdit);
        right.add(btnDel);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        // Table Card
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. Rekam Medis", "NIK", "Nama Pasien", "L/P", "Tgl Lahir", "Status Rawat", "Penanggung Jawab", "Ruang & Bed Inap", "Telepon"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPasien = new JTable(model);
        UiUtils.styleTable(tblPasien);
        cardTable.add(new JScrollPane(tblPasien), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String st = (String) cmbStatusFilter.getSelectedItem();
        pasienList = pelayananService.searchPasien(kw, st);

        model.setRowCount(0);
        for (Pasien p : pasienList) {
            String bedInfo = "-";
            if (p.getNamaRuangan() != null) {
                bedInfo = p.getNamaRuangan() + (p.getNomorBed() != null ? " (" + p.getNomorBed() + ")" : "");
            }

            model.addRow(new Object[]{
                    p.getId(),
                    p.getNoRekamMedis(),
                    p.getNik(),
                    p.getNamaLengkap(),
                    p.getJenisKelamin(),
                    UiUtils.formatDate(p.getTanggalLahir()),
                    p.getStatusRawat(),
                    p.getNamaPenanggungJawab() != null ? p.getNamaPenanggungJawab() : "-",
                    bedInfo,
                    p.getNoTelepon() != null ? p.getNoTelepon() : "-"
            });
        }
    }

    private Pasien getSelectedPasien() {
        int r = tblPasien.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris pasien terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return pasienList.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    private void showPasienForm(Pasien p) {
        boolean isEdit = p != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Data Pasien" : "Registrasi Pasien Baru", true);
        dlg.setSize(520, 560);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtNama = new JTextField(isEdit ? p.getNamaLengkap() : "");
        JTextField txtNik = new JTextField(isEdit ? p.getNik() : "");
        JComboBox<String> cmbGender = new JComboBox<>(new String[]{"L", "P"});
        if (isEdit) cmbGender.setSelectedItem(p.getJenisKelamin());

        JTextField txtTglLahir = new JTextField(isEdit && p.getTanggalLahir() != null ? p.getTanggalLahir().toString() : "1995-01-01");
        JTextField txtAlamat = new JTextField(isEdit && p.getAlamat() != null ? p.getAlamat() : "");
        JTextField txtTelp = new JTextField(isEdit && p.getNoTelepon() != null ? p.getNoTelepon() : "");
        JComboBox<String> cmbNikah = new JComboBox<>(new String[]{"Belum Menikah", "Menikah", "Duda/Janda"});
        if (isEdit && p.getStatusPernikahan() != null) cmbNikah.setSelectedItem(p.getStatusPernikahan());

        JComboBox<String> cmbAgama = new JComboBox<>(new String[]{"Islam", "Kristen", "Katolik", "Hindu", "Budha", "Konghucu"});
        if (isEdit && p.getAgama() != null) cmbAgama.setSelectedItem(p.getAgama());

        JComboBox<String> cmbGoldar = new JComboBox<>(new String[]{"A", "B", "AB", "O"});
        if (isEdit && p.getGolonganDarah() != null) cmbGoldar.setSelectedItem(p.getGolonganDarah());

        List<PenanggungJawab> pjList = pelayananService.getAllPenanggungJawab();
        JComboBox<PenanggungJawab> cmbPJ = new JComboBox<>(pjList.toArray(new PenanggungJawab[0]));
        if (isEdit && p.getIdPenanggungJawab() != null) {
            for (PenanggungJawab pj : pjList) {
                if (pj.getId() == p.getIdPenanggungJawab()) {
                    cmbPJ.setSelectedItem(pj);
                    break;
                }
            }
        }

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Nama Lengkap Pasien:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(txtNama, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("NIK (KTP Pasien):"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtNik, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Jenis Kelamin:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(cmbGender, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Tanggal Lahir (YYYY-MM-DD):"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtTglLahir, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Alamat Lengkap:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtAlamat, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("No. Telepon:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(txtTelp, g);

        g.gridx = 0; g.gridy = 6; pan.add(new JLabel("Status Pernikahan:"), g);
        g.gridx = 1; g.gridy = 6; pan.add(cmbNikah, g);

        g.gridx = 0; g.gridy = 7; pan.add(new JLabel("Agama:"), g);
        g.gridx = 1; g.gridy = 7; pan.add(cmbAgama, g);

        g.gridx = 0; g.gridy = 8; pan.add(new JLabel("Golongan Darah:"), g);
        g.gridx = 1; g.gridy = 8; pan.add(cmbGoldar, g);

        g.gridx = 0; g.gridy = 9; pan.add(new JLabel("Penanggung Jawab:"), g);
        g.gridx = 1; g.gridy = 9; pan.add(cmbPJ, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Data Pasien");
        btnSave.addActionListener(e -> {
            try {
                Pasien np = isEdit ? p : new Pasien();
                np.setNamaLengkap(txtNama.getText().trim());
                np.setNik(txtNik.getText().trim());
                np.setJenisKelamin((String) cmbGender.getSelectedItem());
                np.setTanggalLahir(Date.valueOf(txtTglLahir.getText().trim()));
                np.setAlamat(txtAlamat.getText().trim());
                np.setNoTelepon(txtTelp.getText().trim());
                np.setStatusPernikahan((String) cmbNikah.getSelectedItem());
                np.setAgama((String) cmbAgama.getSelectedItem());
                np.setGolonganDarah((String) cmbGoldar.getSelectedItem());

                PenanggungJawab selPj = (PenanggungJawab) cmbPJ.getSelectedItem();
                if (selPj != null) np.setIdPenanggungJawab(selPj.getId());

                if (!isEdit) {
                    np.setStatusRawat("RAWAT_JALAN");
                }

                pelayananService.savePasien(np);
                UiUtils.showSuccess(this, "Data pasien berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 10; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deletePasien() {
        Pasien p = getSelectedPasien();
        if (p == null) return;
        if (UiUtils.confirm(this, "Hapus data pasien " + p.getNamaLengkap() + " (" + p.getNoRekamMedis() + ")?")) {
            try {
                pelayananService.deletePasien(p.getId());
                UiUtils.showSuccess(this, "Data pasien berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
