package com.rsj.ui.dokter;

import com.rsj.dao.DokterDao;
import com.rsj.model.DetailResep;
import com.rsj.model.Dokter;
import com.rsj.model.Obat;
import com.rsj.model.RekamMedis;
import com.rsj.model.Resep;
import com.rsj.service.ApotekService;
import com.rsj.service.PelayananService;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DiagnosisResepPanel extends JPanel {

    private final ApotekService apotekService = new ApotekService();
    private final PelayananService pelayananService = new PelayananService();
    private final DokterDao dokterDao = new DokterDao();

    private final JTable tblResep;
    private final DefaultTableModel model;
    private List<Resep> resepList;

    public DiagnosisResepPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Daftar Resep & Terapi Farmakologi Psikiatri");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnBuat = UiUtils.createPrimaryButton("+ Tulis Resep Baru");
        btnBuat.addActionListener(e -> showResepForm());

        JButton btnDetail = UiUtils.createSecondaryButton("Lihat Rincian Resep");
        btnDetail.addActionListener(e -> showDetailResepDialog());

        right.add(btnBuat);
        right.add(btnDetail);

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. Resep", "Tanggal Resep", "No. RM", "Nama Pasien", "Dokter Pembuat", "Jumlah Obat", "Total Biaya Resep", "Status Farmasi"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblResep = new JTable(model);
        UiUtils.styleTable(tblResep);
        cardTable.add(new JScrollPane(tblResep), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        resepList = apotekService.getAllResep();
        model.setRowCount(0);
        for (Resep r : resepList) {
            model.addRow(new Object[]{
                    r.getId(),
                    r.getNoResep(),
                    UiUtils.formatDate(r.getTanggalResep()),
                    r.getNoRekamMedis(),
                    r.getNamaPasien(),
                    r.getNamaDokter(),
                    r.getDetailList().size() + " Item",
                    UiUtils.formatRupiah(r.getTotalBiaya()),
                    r.getStatus()
            });
        }
    }

    private Resep getSelectedResep() {
        int r = tblResep.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris resep terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return resepList.stream().filter(res -> res.getId() == id).findFirst().orElse(null);
    }

    private void showDetailResepDialog() {
        Resep r = getSelectedResep();
        if (r == null) return;

        JDialog dlg = new JDialog((Frame) null, "Rincian Resep: " + r.getNoResep(), true);
        dlg.setSize(520, 380);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBackground(UiUtils.COLOR_SURFACE);
        content.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));

        JLabel lblInfo = new JLabel("<html><b>Pasien:</b> " + r.getNamaPasien() + " (RM: " + r.getNoRekamMedis() + ")<br>"
                + "<b>Dokter:</b> " + r.getNamaDokter() + " | <b>Status:</b> " + r.getStatus() + "</html>");
        lblInfo.setFont(UiUtils.FONT_REGULAR);

        DefaultTableModel itemModel = new DefaultTableModel(new String[]{"Nama Obat", "Dosis", "Jumlah", "Aturan Pakai", "Subtotal"}, 0);
        for (DetailResep d : r.getDetailList()) {
            itemModel.addRow(new Object[]{
                    d.getNamaObat(),
                    d.getDosis(),
                    d.getJumlah() + " " + d.getBentuk(),
                    d.getAturanPakai() + " (" + (d.getPetunjukKhusus() != null ? d.getPetunjukKhusus() : "-") + ")",
                    UiUtils.formatRupiah(d.getSubtotal())
            });
        }
        JTable tblItems = new JTable(itemModel);
        UiUtils.styleTable(tblItems);

        JLabel lblTotal = new JLabel("Total Biaya Obat: " + UiUtils.formatRupiah(r.getTotalBiaya()));
        lblTotal.setFont(UiUtils.FONT_HEADER);
        lblTotal.setForeground(UiUtils.COLOR_ACCENT);

        content.add(lblInfo, BorderLayout.NORTH);
        content.add(new JScrollPane(tblItems), BorderLayout.CENTER);
        content.add(lblTotal, BorderLayout.SOUTH);

        dlg.add(content);
        dlg.setVisible(true);
    }

    private void showResepForm() {
        JDialog dlg = new JDialog((Frame) null, "Buat Resep Obat Pasien", true);
        dlg.setSize(580, 520);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<RekamMedis> rmList = pelayananService.getAllRekamMedis();
        JComboBox<RekamMedis> cmbRM = new JComboBox<>(rmList.toArray(new RekamMedis[0]));

        List<Obat> obatList = apotekService.getAllObat();
        JComboBox<Obat> cmbObat = new JComboBox<>(obatList.toArray(new Obat[0]));

        JTextField txtJumlah = new JTextField("30");
        JTextField txtAturan = new JTextField("2 x 1 tablet sehari (pagi & malam)");
        JTextField txtKhusus = new JTextField("Sesudah makan");
        JTextField txtCatatanResep = new JTextField("Pantau respons mood dan kepatuhan minum");

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pilih Rekam Medis Pasien:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbRM, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Pilih Obat:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(cmbObat, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Jumlah Obat:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(txtJumlah, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Aturan Pakai:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtAturan, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Petunjuk Khusus:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtKhusus, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Catatan Dokter untuk Apotek:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(txtCatatanResep, g);

        JButton btnKirim = UiUtils.createPrimaryButton("Kirim Resep ke Farmasi / Apotek");
        btnKirim.addActionListener(e -> {
            try {
                RekamMedis selRM = (RekamMedis) cmbRM.getSelectedItem();
                Obat selObat = (Obat) cmbObat.getSelectedItem();
                if (selRM == null || selObat == null) throw new Exception("Rekam medis dan obat wajib dipilih!");

                int qty = Integer.parseInt(txtJumlah.getText().trim());
                if (qty <= 0) throw new Exception("Jumlah obat harus lebih dari 0!");

                int dokterId = selRM.getIdDokter();
                if (SessionManager.getCurrentUser() != null) {
                    Dokter d = dokterDao.findByUserId(SessionManager.getCurrentUser().getId());
                    if (d != null) dokterId = d.getId();
                }

                Resep r = new Resep();
                r.setIdRekamMedis(selRM.getId());
                r.setIdPasien(selRM.getIdPasien());
                r.setIdDokter(dokterId);
                r.setTanggalResep(Date.valueOf(LocalDate.now()));
                r.setCatatan(txtCatatanResep.getText().trim());

                DetailResep det = new DetailResep();
                det.setIdObat(selObat.getId());
                det.setJumlah(qty);
                det.setAturanPakai(txtAturan.getText().trim());
                det.setPetunjukKhusus(txtKhusus.getText().trim());
                det.setSubtotal(selObat.getHargaSatuan().multiply(new BigDecimal(qty)));

                List<DetailResep> details = new ArrayList<>();
                details.add(det);

                apotekService.buatResep(r, details);
                UiUtils.showSuccess(this, "Resep " + r.getNoResep() + " berhasil dikirim ke Apotek!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(16, 5, 5, 5);
        pan.add(btnKirim, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }
}
