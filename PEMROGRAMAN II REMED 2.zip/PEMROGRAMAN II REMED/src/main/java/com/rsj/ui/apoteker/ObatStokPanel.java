package com.rsj.ui.apoteker;

import com.rsj.model.Obat;
import com.rsj.service.ApotekService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ObatStokPanel extends JPanel {

    private final ApotekService apotekService = new ApotekService();

    private final JTable tblObat;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbKategori;
    private List<Obat> obatList;

    public ObatStokPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(14);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari nama / kode obat...");
        txtSearch.addActionListener(e -> reloadData());

        cmbKategori = new JComboBox<>(new String[]{"SEMUA", "ANTIPSIKOTIK", "ANTIDEPRESAN", "ANKSIOLITIK", "MOOD_STABILIZER", "SEDATIF"});
        cmbKategori.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(new JLabel("Kategori:"));
        left.add(cmbKategori);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Tambah Obat");
        btnAdd.addActionListener(e -> showObatForm(null));

        JButton btnStock = UiUtils.createSecondaryButton("+ Tambah Stok");
        btnStock.addActionListener(e -> tambahStokDialog());

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah");
        btnEdit.addActionListener(e -> {
            Obat o = getSelectedObat();
            if (o != null) showObatForm(o);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.addActionListener(e -> deleteObat());

        right.add(btnAdd);
        right.add(btnStock);
        right.add(btnEdit);
        right.add(btnDel);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "Kode Obat", "Nama Obat Jiwa", "Kategori", "Bentuk", "Dosis", "Sisa Stok", "Satuan", "Harga Satuan", "Deskripsi Farmakologi"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblObat = new JTable(model);
        UiUtils.styleTable(tblObat);
        cardTable.add(new JScrollPane(tblObat), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String kat = (String) cmbKategori.getSelectedItem();

        obatList = apotekService.searchObat(kw, kat);
        model.setRowCount(0);
        for (Obat o : obatList) {
            model.addRow(new Object[]{
                    o.getId(),
                    o.getKodeObat(),
                    o.getNamaObat(),
                    o.getKategori(),
                    o.getBentuk(),
                    o.getDosis(),
                    o.getStok(),
                    o.getSatuan(),
                    UiUtils.formatRupiah(o.getHargaSatuan()),
                    o.getDeskripsi()
            });
        }
    }

    private Obat getSelectedObat() {
        int r = tblObat.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris obat terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return obatList.stream().filter(o -> o.getId() == id).findFirst().orElse(null);
    }

    private void showObatForm(Obat o) {
        boolean isEdit = o != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Data Obat" : "Tambah Obat Jiwa Baru", true);
        dlg.setSize(480, 480);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtKode = new JTextField(isEdit ? o.getKodeObat() : "OBAT-");
        JTextField txtNama = new JTextField(isEdit ? o.getNamaObat() : "");
        JComboBox<String> cmbKat = new JComboBox<>(new String[]{"ANTIPSIKOTIK", "ANTIDEPRESAN", "ANKSIOLITIK", "MOOD_STABILIZER", "SEDATIF"});
        if (isEdit) cmbKat.setSelectedItem(o.getKategori());

        JComboBox<String> cmbBentuk = new JComboBox<>(new String[]{"TABLET", "KAPSUL", "SIRUP", "INJEKSI", "DROPS"});
        if (isEdit) cmbBentuk.setSelectedItem(o.getBentuk());

        JTextField txtDosis = new JTextField(isEdit && o.getDosis() != null ? o.getDosis() : "2 mg");
        JTextField txtStok = new JTextField(isEdit ? String.valueOf(o.getStok()) : "100");
        JTextField txtSatuan = new JTextField(isEdit ? o.getSatuan() : "Tablet");
        JTextField txtHarga = new JTextField(isEdit && o.getHargaSatuan() != null ? o.getHargaSatuan().toString() : "5000");
        JTextField txtDesk = new JTextField(isEdit && o.getDeskripsi() != null ? o.getDeskripsi() : "");

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Kode Obat:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(txtKode, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Nama Obat Jiwa:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtNama, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Kategori Obat:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(cmbKat, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Bentuk Sediaan:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(cmbBentuk, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Dosis:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtDosis, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Stok Awal:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(txtStok, g);

        g.gridx = 0; g.gridy = 6; pan.add(new JLabel("Satuan & Harga (Rp):"), g);
        JPanel pSat = new JPanel(new java.awt.GridLayout(1, 2, 6, 0));
        pSat.setOpaque(false);
        pSat.add(txtSatuan);
        pSat.add(txtHarga);
        g.gridx = 1; g.gridy = 6; pan.add(pSat, g);

        g.gridx = 0; g.gridy = 7; pan.add(new JLabel("Deskripsi / Khasiat:"), g);
        g.gridx = 1; g.gridy = 7; pan.add(txtDesk, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Obat");
        btnSave.addActionListener(e -> {
            try {
                Obat no = isEdit ? o : new Obat();
                no.setKodeObat(txtKode.getText().trim());
                no.setNamaObat(txtNama.getText().trim());
                no.setKategori((String) cmbKat.getSelectedItem());
                no.setBentuk((String) cmbBentuk.getSelectedItem());
                no.setDosis(txtDosis.getText().trim());
                no.setStok(Integer.parseInt(txtStok.getText().trim()));
                no.setSatuan(txtSatuan.getText().trim());
                no.setHargaSatuan(new BigDecimal(txtHarga.getText().trim()));
                no.setDeskripsi(txtDesk.getText().trim());

                apotekService.saveObat(no);
                UiUtils.showSuccess(this, "Data obat berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 8; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void tambahStokDialog() {
        Obat o = getSelectedObat();
        if (o == null) return;

        String input = JOptionPane.showInputDialog(this, "Masukkan jumlah stok yang ditambahkan untuk " + o.getNamaObat() + " (" + o.getSatuan() + "):", "Tambah Stok Obat", JOptionPane.QUESTION_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            try {
                int qty = Integer.parseInt(input.trim());
                apotekService.tambahStok(o.getId(), qty);
                UiUtils.showSuccess(this, "Stok berhasil ditambahkan!");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }

    private void deleteObat() {
        Obat o = getSelectedObat();
        if (o == null) return;
        if (UiUtils.confirm(this, "Hapus data obat " + o.getNamaObat() + "?")) {
            try {
                apotekService.deleteObat(o.getId());
                UiUtils.showSuccess(this, "Obat berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
