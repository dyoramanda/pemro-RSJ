package com.rsj.ui.common;

import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StatCard extends JPanel {

    private final JLabel lblTitle;
    private final JLabel lblValue;
    private final JLabel lblSubtitle;

    public StatCard(String title, String value, String subtitle, Color accentColor) {
        setLayout(new BorderLayout(12, 8));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        setPreferredSize(new Dimension(220, 110));

        JPanel leftPanel = new JPanel(new GridLayout(3, 1, 2, 2));
        leftPanel.setOpaque(false);

        lblTitle = new JLabel(title);
        lblTitle.setFont(UiUtils.FONT_SMALL);
        lblTitle.setForeground(UiUtils.COLOR_TEXT_MUTED);

        lblValue = new JLabel(value);
        lblValue.setFont(UiUtils.FONT_BIG_STAT);
        lblValue.setForeground(UiUtils.COLOR_TEXT_MAIN);

        lblSubtitle = new JLabel(subtitle);
        lblSubtitle.setFont(UiUtils.FONT_SMALL);
        lblSubtitle.setForeground(accentColor);

        leftPanel.add(lblTitle);
        leftPanel.add(lblValue);
        leftPanel.add(lblSubtitle);

        // Right color bar indicator
        JPanel rightBar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(accentColor);
                g2.fillRoundRect(0, 4, 6, getHeight() - 8, 4, 4);
                g2.dispose();
            }
        };
        rightBar.setOpaque(false);
        rightBar.setPreferredSize(new Dimension(8, 60));

        add(leftPanel, BorderLayout.CENTER);
        add(rightBar, BorderLayout.EAST);
    }

    public void setValue(String value) {
        lblValue.setText(value);
    }

    public void setSubtitle(String subtitle) {
        lblSubtitle.setText(subtitle);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(UiUtils.COLOR_SURFACE);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
        g2.setColor(UiUtils.COLOR_BORDER);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
        g2.dispose();
    }
}
