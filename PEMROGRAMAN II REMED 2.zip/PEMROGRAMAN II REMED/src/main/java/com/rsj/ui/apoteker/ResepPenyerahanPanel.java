package com.rsj.ui.apoteker;

import com.rsj.model.DetailResep;
import com.rsj.model.Resep;
import com.rsj.service.ApotekService;
import com.rsj.ui.common.StatusBadgeRenderer;
import com.rsj.ui.common.TableUtil;
import com.rsj.util.PrintHelper;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class ResepPenyerahanPanel extends JPanel {

    private final ApotekService apotekService = new ApotekService();

    private final TableUtil.CustomTable tblResep;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbStatus;
    private final JLabel lblCountInfo;
    private List<Resep> resepList;

    public ResepPenyerahanPanel() {
        setLayout(new BorderLayout(0, 12));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));

        // ==========================================
        // 1. NORTH: HEADER CARD & TOOLBAR CARD
        // ==========================================
        JPanel topSection = new JPanel();
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));
        topSection.setOpaque(false);

        // Header Title Card
        JPanel headerCard = UiUtils.createCardPanel();
        headerCard.setLayout(new BorderLayout(14, 0));
        headerCard.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Telaah & Penyerahan Resep Obat");
        lblTitle.setFont(UiUtils.FONT_TITLE);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblSub = new JLabel("Verifikasi klinis resep dokter spesialis jiwa, penyiapan obat farmasi, dan penyerahan");
        lblSub.setFont(UiUtils.FONT_SMALL);
        lblSub.setForeground(UiUtils.COLOR_TEXT_MUTED);

        textPanel.add(lblTitle);
        textPanel.add(Box.createRigidArea(new Dimension(0, 3)));
        textPanel.add(lblSub);

        headerCard.add(textPanel, BorderLayout.WEST);

        // Toolbar Card (2 Baris: Filter & Aksi)
        JPanel toolbarCard = UiUtils.createCardPanel();
        toolbarCard.setLayout(new BorderLayout(0, 8));
        toolbarCard.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        // Baris 1: Filter & Pencarian
        JPanel rowFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        rowFilter.setOpaque(false);

        txtSearch = new JTextField(18);
        txtSearch.setPreferredSize(new Dimension(240, 34));
        txtSearch.putClientProperty("JTextField.placeholderText", "No resep / pasien / no RM...");
        txtSearch.addActionListener(e -> reloadData());

        cmbStatus = new JComboBox<>(new String[]{"Semua Status", "MENUNGGU", "DIPROSES", "SELESAI", "DIAMBIL"});
        cmbStatus.setPreferredSize(new Dimension(150, 34));
        cmbStatus.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.setPreferredSize(new Dimension(85, 34));
        btnSearch.addActionListener(e -> reloadData());

        rowFilter.add(new JLabel("Pencarian:"));
        rowFilter.add(txtSearch);
        rowFilter.add(new JLabel("Status Farmasi:"));
        rowFilter.add(cmbStatus);
        rowFilter.add(btnSearch);

        // Baris 2: Info Data & Tombol-tombol Aksi
        JPanel rowActions = new JPanel(new BorderLayout(10, 0));
        rowActions.setOpaque(false);

        lblCountInfo = new JLabel("Menampilkan 0 data resep");
        lblCountInfo.setFont(UiUtils.FONT_SMALL);
        lblCountInfo.setForeground(UiUtils.COLOR_TEXT_MUTED);

        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightButtons.setOpaque(false);

        JButton btnProses = UiUtils.createPrimaryButton("Siapkan Resep");
        btnProses.setFont(UiUtils.FONT_BOLD);
        btnProses.setPreferredSize(new Dimension(145, 36));
        btnProses.addActionListener(e -> showSiapkanResepDialog());

        JButton btnSerah = UiUtils.createPrimaryButton("Serahkan Obat (Potong Stok)");
        btnSerah.setFont(UiUtils.FONT_BOLD);
        btnSerah.setBackground(new Color(0x02, 0x84, 0xC7)); // Sky Blue
        btnSerah.setPreferredSize(new Dimension(215, 36));
        btnSerah.addActionListener(e -> serahkanObat());

        JButton btnEtiket = UiUtils.createSecondaryButton("Cetak Etiket Obat");
        btnEtiket.setPreferredSize(new Dimension(155, 36));
        btnEtiket.addActionListener(e -> cetakEtiket());

        rightButtons.add(btnProses);
        rightButtons.add(btnSerah);
        rightButtons.add(btnEtiket);

        rowActions.add(lblCountInfo, BorderLayout.WEST);
        rowActions.add(rightButtons, BorderLayout.EAST);

        toolbarCard.add(rowFilter, BorderLayout.NORTH);
        toolbarCard.add(rowActions, BorderLayout.SOUTH);

        topSection.add(headerCard);
        topSection.add(Box.createRigidArea(new Dimension(0, 10)));
        topSection.add(toolbarCard);

        add(topSection, BorderLayout.NORTH);

        // ==========================================
        // 2. CENTER: TABEL DATA RESEP
        // ==========================================
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 8));

        model = new DefaultTableModel(new String[]{
                "ID_HIDDEN", "No. Resep", "Tanggal Resep", "No. RM", "Nama Pasien", "Dokter Pembuat", "Jumlah Obat", "Total Biaya", "Status Farmasi", "Catatan Dokter"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tblResep = TableUtil.createTable(model, "Belum ada data resep masuk");
        tblResep.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Sembunyikan kolom ID
        TableUtil.hideColumn(tblResep, 0);

        // Atur proporsi lebar kolom
        int[] preferredWidths = {130, 100, 95, 150, 150, 100, 110, 115, 200};
        int[] minWidths = {110, 85, 80, 120, 120, 85, 95, 95, 120};
        TableUtil.setColumnWidths(tblResep, preferredWidths, minWidths);

        // Format Perataan Tengah
        tblResep.getColumnModel().getColumn(1).setCellRenderer(TableUtil.createCenterRenderer()); // Tanggal
        tblResep.getColumnModel().getColumn(2).setCellRenderer(TableUtil.createCenterRenderer()); // No RM
        tblResep.getColumnModel().getColumn(5).setCellRenderer(TableUtil.createCenterRenderer()); // Jumlah Obat
        tblResep.getColumnModel().getColumn(6).setCellRenderer(TableUtil.createCenterRenderer()); // Total Biaya

        // Badge Status Farmasi
        StatusBadgeRenderer statusBadge = new StatusBadgeRenderer()
                .addMapping("MENUNGGU", "Menunggu", new Color(0xFE, 0xF3, 0xC7), new Color(0xB4, 0x53, 0x09)) // Amber
                .addMapping("DIPROSES", "Disiapkan", new Color(0xCC, 0xFB, 0xF1), new Color(0x0F, 0x76, 0x6E)) // Teal
                .addMapping("SELESAI", "Selesai", new Color(0xDC, 0xFC, 0xE7), new Color(0x15, 0x80, 0x3D))   // Hijau
                .addMapping("DIAMBIL", "Diambil", new Color(0xDB, 0xEA, 0xFE), new Color(0x1D, 0x4E, 0xD8))   // Biru
                .addMapping("DIBATALKAN", "Batal", new Color(0xFE, 0xE2, 0xE2), new Color(0xB9, 0x1C, 0x1C)); // Merah

        tblResep.getColumnModel().getColumn(7).setCellRenderer(statusBadge);

        // Double click shortcut: Cetak etiket obat
        tblResep.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblResep.getSelectedRow() >= 0) {
                    cetakEtiket();
                }
            }
        });

        JScrollPane scrollTable = new JScrollPane(tblResep);
        scrollTable.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));
        cardTable.add(scrollTable, BorderLayout.CENTER);

        // Status Bar Bawah: Legend & Petunjuk
        JPanel footerBar = new JPanel(new BorderLayout(10, 0));
        footerBar.setOpaque(false);
        footerBar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        JLabel lblLegend = new JLabel("Status:  🟡 Menunggu   🔵 Disiapkan   🟢 Selesai   🟣 Diambil");
        lblLegend.setFont(UiUtils.FONT_SMALL);
        lblLegend.setForeground(UiUtils.COLOR_TEXT_MUTED);

        JLabel lblHint = new JLabel("Klik ganda baris untuk mencetak etiket obat");
        lblHint.setFont(UiUtils.FONT_SMALL);
        lblHint.setForeground(UiUtils.COLOR_TEXT_MUTED);

        footerBar.add(lblLegend, BorderLayout.WEST);
        footerBar.add(lblHint, BorderLayout.EAST);
        cardTable.add(footerBar, BorderLayout.SOUTH);

        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String st = (String) cmbStatus.getSelectedItem();
        if ("Semua Status".equalsIgnoreCase(st)) st = "SEMUA";

        resepList = apotekService.searchResep(kw, st);
        model.setRowCount(0);
        for (Resep r : resepList) {
            model.addRow(new Object[]{
                    r.getId(),
                    r.getNoResep(),
                    TableUtil.formatShortDate(r.getTanggalResep()),
                    r.getNoRekamMedis(),
                    r.getNamaPasien(),
                    r.getNamaDokter(),
                    r.getDetailList().size() + " Item",
                    UiUtils.formatRupiah(r.getTotalBiaya()),
                    r.getStatus(),
                    r.getCatatan() != null ? r.getCatatan() : "-"
            });
        }
        lblCountInfo.setText("Menampilkan " + resepList.size() + " data resep");
    }

    private Resep getSelectedResep() {
        int r = tblResep.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris resep terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return resepList.stream().filter(res -> res.getId() == id).findFirst().orElse(null);
    }

    private void showSiapkanResepDialog() {
        Resep r = getSelectedResep();
        if (r == null) return;

        if ("SELESAI".equalsIgnoreCase(r.getStatus())) {
            UiUtils.showError(this, "Resep " + r.getNoResep() + " sudah selesai dan diserahkan!");
            return;
        }

        JDialog dlg = new JDialog((Frame) null, "Telaah & Penyiapan Resep Farmasi", true);
        dlg.setLayout(new BorderLayout());

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(UiUtils.COLOR_SURFACE);
        root.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        // Header Panel Dialog
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setOpaque(false);

        JLabel lblDlgTitle = new JLabel("Telaah & Penyiapan Resep: " + r.getNoResep());
        lblDlgTitle.setFont(UiUtils.FONT_TITLE);
        lblDlgTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblDlgSub = new JLabel("Pasien: " + r.getNamaPasien() + " (RM: " + r.getNoRekamMedis() + ") • Dokter: " + r.getNamaDokter());
        lblDlgSub.setFont(UiUtils.FONT_BOLD);
        lblDlgSub.setForeground(UiUtils.COLOR_TEXT_MAIN);

        headerPanel.add(lblDlgTitle);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        headerPanel.add(lblDlgSub);

        // Body Content: Tabel Rincian Obat & Catatan
        JPanel bodyPanel = new JPanel(new GridBagLayout());
        bodyPanel.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(6, 4, 6, 4);

        // 1. Tabel Daftar Obat
        DefaultTableModel modelItem = new DefaultTableModel(new String[]{"Nama Obat", "Dosis", "Jumlah", "Aturan Pakai", "Petunjuk Khusus"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        for (DetailResep d : r.getDetailList()) {
            modelItem.addRow(new Object[]{
                    d.getNamaObat(),
                    d.getDosis() != null ? d.getDosis() : "-",
                    d.getJumlah() + " " + (d.getBentuk() != null ? d.getBentuk() : "Unit"),
                    d.getAturanPakai(),
                    d.getPetunjukKhusus() != null ? d.getPetunjukKhusus() : "-"
            });
        }
        JTable tblItem = new JTable(modelItem);
        UiUtils.styleTable(tblItem);
        tblItem.setPreferredScrollableViewportSize(new Dimension(540, 110));
        JScrollPane spTbl = new JScrollPane(tblItem);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.25; bodyPanel.add(new JLabel("Daftar Obat Resep:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.75; bodyPanel.add(spTbl, g);

        // 2. Catatan Dokter
        JTextArea txtCatatanDokter = new JTextArea(r.getCatatan() != null ? r.getCatatan() : "-", 2, 20);
        txtCatatanDokter.setLineWrap(true);
        txtCatatanDokter.setWrapStyleWord(true);
        txtCatatanDokter.setEditable(false);
        txtCatatanDokter.setBackground(new Color(0xF8, 0xFA, 0xFC));
        JScrollPane spCatatanDokter = new JScrollPane(txtCatatanDokter);
        spCatatanDokter.setPreferredSize(new Dimension(540, 50));

        g.gridx = 0; g.gridy = 1; bodyPanel.add(new JLabel("Catatan Dokter:"), g);
        g.gridx = 1; g.gridy = 1; bodyPanel.add(spCatatanDokter, g);

        // 3. Checklist Telaah Farmasi
        JPanel pChecklist = new JPanel(new GridLayout(3, 1, 4, 4));
        pChecklist.setOpaque(false);
        JCheckBox chk1 = new JCheckBox("Ketepatan dosis, aturan pakai, dan rute pemberian telah diperiksa", true);
        JCheckBox chk2 = new JCheckBox("Tidak ada potensi interaksi obat merugikan / kontraindikasi", true);
        JCheckBox chk3 = new JCheckBox("Ketersediaan fisik stok obat di instalasi farmasi siap diracik", true);
        chk1.setFont(UiUtils.FONT_SMALL);
        chk2.setFont(UiUtils.FONT_SMALL);
        chk3.setFont(UiUtils.FONT_SMALL);
        pChecklist.add(chk1);
        pChecklist.add(chk2);
        pChecklist.add(chk3);

        g.gridx = 0; g.gridy = 2; bodyPanel.add(new JLabel("Telaah Farmasi:*"), g);
        g.gridx = 1; g.gridy = 2; bodyPanel.add(pChecklist, g);

        // 4. Catatan Telaah Apoteker
        JTextArea txtCatatanApoteker = new JTextArea("Telaah farmasi selesai. Resep memenuhi syarat dan obat sedang disiapkan.", 2, 20);
        txtCatatanApoteker.setLineWrap(true);
        txtCatatanApoteker.setWrapStyleWord(true);
        JScrollPane spCatatanApoteker = new JScrollPane(txtCatatanApoteker);
        spCatatanApoteker.setPreferredSize(new Dimension(540, 50));

        g.gridx = 0; g.gridy = 3; bodyPanel.add(new JLabel("Catatan Apoteker:"), g);
        g.gridx = 1; g.gridy = 3; bodyPanel.add(spCatatanApoteker, g);

        root.add(headerPanel, BorderLayout.NORTH);
        root.add(bodyPanel, BorderLayout.CENTER);

        // Buttons Bar
        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnBar.setOpaque(false);
        btnBar.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JButton btnBatal = UiUtils.createSecondaryButton("Batal");
        btnBatal.setPreferredSize(new Dimension(100, 36));
        btnBatal.addActionListener(e -> dlg.dispose());

        JButton btnSimpan = UiUtils.createPrimaryButton("Verifikasi & Siapkan Resep");
        btnSimpan.setPreferredSize(new Dimension(210, 36));
        btnSimpan.addActionListener(e -> {
            if (!chk1.isSelected() || !chk2.isSelected() || !chk3.isSelected()) {
                UiUtils.showError(dlg, "Harap lengkapi dan centang seluruh poin telaah farmasi!");
                return;
            }
            try {
                apotekService.prosesResep(r.getId());
                UiUtils.showSuccess(this, "Resep " + r.getNoResep() + " telah diverifikasi dan status diubah menjadi DISIAPKAN!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Gagal memproses resep: " + ex.getMessage());
            }
        });

        btnBar.add(btnBatal);
        btnBar.add(btnSimpan);
        root.add(btnBar, BorderLayout.SOUTH);

        dlg.add(root);
        dlg.pack();
        dlg.setMinimumSize(new Dimension(680, 500));
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    private void serahkanObat() {
        Resep r = getSelectedResep();
        if (r == null) return;

        if ("SELESAI".equalsIgnoreCase(r.getStatus())) {
            UiUtils.showError(this, "Resep " + r.getNoResep() + " sudah pernah diserahkan dan stok telah dipotong!");
            return;
        }

        if (UiUtils.confirm(this, "Konfirmasi penyerahan obat resep " + r.getNoResep() + " kepada pasien " + r.getNamaPasien() + "?\nStok obat pada sistem farmasi akan otomatis dipotong.")) {
            try {
                apotekService.serahkanObat(r.getId());
                UiUtils.showSuccess(this, "Obat berhasil diserahkan dan stok farmasi otomatis berkurang!");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, "Gagal menyerahkan obat: " + ex.getMessage());
            }
        }
    }

    private void cetakEtiket() {
        Resep r = getSelectedResep();
        if (r == null) return;

        JPanel etiketPanel = new JPanel(new GridLayout(6 + r.getDetailList().size(), 1, 4, 4));
        etiketPanel.setBackground(Color.WHITE);
        etiketPanel.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JLabel h1 = new JLabel("INSTALASI FARMASI RS JIWA SEHAT JIWA");
        h1.setFont(UiUtils.FONT_TITLE);
        h1.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel h2 = new JLabel("ETIKET ATURAN PAKAI OBAT PASIEN");
        h2.setFont(UiUtils.FONT_HEADER);
        h2.setForeground(UiUtils.COLOR_ACCENT);

        JLabel h3 = new JLabel("No. Resep: " + r.getNoResep() + " • Tanggal: " + TableUtil.formatShortDate(r.getTanggalResep()));
        JLabel h4 = new JLabel("Nama Pasien: " + r.getNamaPasien() + " (No. RM: " + r.getNoRekamMedis() + ")");
        JLabel h5 = new JLabel("Dokter Penulis Resep: " + r.getNamaDokter());

        etiketPanel.add(h1);
        etiketPanel.add(h2);
        etiketPanel.add(h3);
        etiketPanel.add(h4);
        etiketPanel.add(h5);

        for (DetailResep d : r.getDetailList()) {
            JLabel lItem = new JLabel("• " + d.getNamaObat() + " (" + d.getDosis() + ") : " + d.getJumlah() + " " + (d.getBentuk() != null ? d.getBentuk() : "") + " -> " + d.getAturanPakai() + " [" + (d.getPetunjukKhusus() != null ? d.getPetunjukKhusus() : "-") + "]");
            lItem.setFont(UiUtils.FONT_BOLD);
            etiketPanel.add(lItem);
        }

        JLabel hFooter = new JLabel("Pastikan diminum secara teratur sesuai petunjuk dokter. Jauhkan dari jangkauan anak.");
        hFooter.setFont(UiUtils.FONT_SMALL);
        hFooter.setForeground(UiUtils.COLOR_TEXT_MUTED);
        etiketPanel.add(hFooter);

        PrintHelper.printComponent(etiketPanel);
    }
}
