package com.rsj.ui.common;

import com.rsj.util.UiUtils;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.Map;
import javax.swing.JPanel;

public class SimpleChartPanel extends JPanel {

    public enum ChartType { BAR, HORIZONTAL_BAR }

    private final String title;
    private final Map<String, Integer> data;
    private final ChartType type;

    public SimpleChartPanel(String title, Map<String, Integer> data, ChartType type) {
        this.title = title;
        this.data = data;
        this.type = type;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        // Background card
        g2.setColor(UiUtils.COLOR_SURFACE);
        g2.fillRoundRect(0, 0, w - 1, h - 1, 16, 16);
        g2.setColor(UiUtils.COLOR_BORDER);
        g2.drawRoundRect(0, 0, w - 1, h - 1, 16, 16);

        // Header Title
        g2.setColor(UiUtils.COLOR_TEXT_MAIN);
        g2.setFont(UiUtils.FONT_HEADER);
        g2.drawString(title, 20, 30);

        if (data == null || data.isEmpty()) {
            g2.setColor(UiUtils.COLOR_TEXT_MUTED);
            g2.setFont(UiUtils.FONT_REGULAR);
            g2.drawString("Belum ada data grafik.", 20, 70);
            g2.dispose();
            return;
        }

        int maxVal = data.values().stream().mapToInt(Integer::intValue).max().orElse(1);
        if (maxVal == 0) maxVal = 1;

        if (type == ChartType.BAR) {
            drawVerticalBarChart(g2, w, h, maxVal);
        } else {
            drawHorizontalBarChart(g2, w, h, maxVal);
        }

        g2.dispose();
    }

    private void drawVerticalBarChart(Graphics2D g2, int w, int h, int maxVal) {
        int left = 45;
        int bottom = h - 35;
        int top = 55;
        int plotHeight = bottom - top;
        int plotWidth = w - left - 25;

        // Draw horizontal grid lines
        g2.setColor(new Color(0xF1, 0xF5, 0xF9));
        g2.setStroke(new BasicStroke(1.0f));
        int gridSteps = 4;
        for (int i = 0; i <= gridSteps; i++) {
            int y = bottom - (i * plotHeight / gridSteps);
            g2.drawLine(left, y, w - 25, y);

            // Value label on axis
            int gridVal = (maxVal * i) / gridSteps;
            g2.setColor(UiUtils.COLOR_TEXT_MUTED);
            g2.setFont(UiUtils.FONT_SMALL);
            g2.drawString(String.valueOf(gridVal), 15, y + 4);
            g2.setColor(new Color(0xF1, 0xF5, 0xF9));
        }

        int barCount = data.size();
        int slotWidth = plotWidth / barCount;
        int barWidth = Math.max(16, slotWidth - 22);

        int idx = 0;
        FontMetrics fm = g2.getFontMetrics(UiUtils.FONT_SMALL);

        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            int val = entry.getValue();
            int barHeight = (int) (((double) val / maxVal) * plotHeight);
            int x = left + (idx * slotWidth) + ((slotWidth - barWidth) / 2);
            int y = bottom - barHeight;

            // Bar Gradient
            GradientPaint gp = new GradientPaint(x, y, UiUtils.COLOR_ACCENT, x, bottom, new Color(0x38, 0xBD, 0xF8));
            g2.setPaint(gp);
            g2.fillRoundRect(x, y, barWidth, barHeight, 6, 6);

            // Value text above bar
            g2.setColor(UiUtils.COLOR_PRIMARY);
            g2.setFont(UiUtils.FONT_SMALL);
            String valStr = String.valueOf(val);
            int textW = fm.stringWidth(valStr);
            g2.drawString(valStr, x + (barWidth - textW) / 2, y - 5);

            // Month Label below axis
            g2.setColor(UiUtils.COLOR_TEXT_MUTED);
            String label = entry.getKey();
            int labelW = fm.stringWidth(label);
            g2.drawString(label, x + (barWidth - labelW) / 2, bottom + 18);

            idx++;
        }
    }

    private void drawHorizontalBarChart(Graphics2D g2, int w, int h, int maxVal) {
        int left = 130;
        int top = 55;
        int right = w - 45;
        int availableWidth = right - left;
        int rowHeight = Math.min(38, (h - top - 20) / Math.max(1, data.size()));

        FontMetrics fm = g2.getFontMetrics(UiUtils.FONT_REGULAR);
        int idx = 0;

        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            int y = top + (idx * rowHeight);
            String label = entry.getKey();
            int val = entry.getValue();
            int barLength = (int) (((double) val / maxVal) * availableWidth);

            // Label
            g2.setColor(UiUtils.COLOR_TEXT_MAIN);
            g2.setFont(UiUtils.FONT_REGULAR);
            g2.drawString(label, 20, y + 16);

            // Background Bar
            g2.setColor(new Color(0xF1, 0xF5, 0xF9));
            g2.fillRoundRect(left, y + 4, availableWidth, 14, 8, 8);

            // Active Bar
            Color barColor = (idx % 2 == 0) ? UiUtils.COLOR_ACCENT : UiUtils.COLOR_PRIMARY;
            g2.setColor(barColor);
            g2.fillRoundRect(left, y + 4, Math.max(8, barLength), 14, 8, 8);

            // Value
            g2.setColor(UiUtils.COLOR_TEXT_MUTED);
            g2.setFont(UiUtils.FONT_SMALL);
            g2.drawString(val + " Pasien", right + 6, y + 16);

            idx++;
        }
    }
}
