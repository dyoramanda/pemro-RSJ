package com.rsj.ui.common;

import com.rsj.util.UiUtils;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class TableUtil {

    private static final SimpleDateFormat SHORT_DATE_FORMAT = new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID"));

    public static class CustomTable extends JTable {
        private String emptyMessage = "Tidak ada data";

        public CustomTable(DefaultTableModel model, String emptyMessage) {
            super(model);
            this.emptyMessage = emptyMessage;
            setFillsViewportHeight(true);
        }

        public void setEmptyMessage(String msg) {
            this.emptyMessage = msg;
            repaint();
        }

        @Override
        public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
            Component c = super.prepareRenderer(renderer, row, column);
            if (!isRowSelected(row)) {
                c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(0xF4, 0xFA, 0xFC));
            } else {
                c.setBackground(new Color(0xE0, 0xF2, 0xFE));
                c.setForeground(new Color(0x0F, 0x17, 0x2A));
            }
            if (c instanceof JComponent) {
                Object val = getValueAt(row, column);
                if (val != null && !val.toString().trim().isEmpty()) {
                    ((JComponent) c).setToolTipText(val.toString());
                } else {
                    ((JComponent) c).setToolTipText(null);
                }
            }
            return c;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getRowCount() == 0 && emptyMessage != null && !emptyMessage.isEmpty()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0x64, 0x74, 0x8B)); // Slate gray
                g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
                FontMetrics fm = g2.getFontMetrics();
                int x = Math.max(16, (getWidth() - fm.stringWidth(emptyMessage)) / 2);
                int y = Math.max(60, (getHeight() / 2) + 5);
                g2.drawString(emptyMessage, x, y);
                g2.dispose();
            }
        }
    }

    public static CustomTable createTable(DefaultTableModel model, String emptyMessage) {
        CustomTable table = new CustomTable(model, emptyMessage);
        styleTable(table);
        return table;
    }

    public static void styleTable(JTable table) {
        table.setFont(UiUtils.FONT_REGULAR);
        table.setRowHeight(36);
        table.setShowGrid(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(0xE2, 0xE8, 0xF0));
        table.setSelectionBackground(new Color(0xE0, 0xF2, 0xFE));
        table.setSelectionForeground(new Color(0x0F, 0x17, 0x2A));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(0x0B, 0x4F, 0x6C)); // Navy #0B4F6C
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(header.getWidth(), 38));
        header.setReorderingAllowed(false);

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                l.setBackground(new Color(0x0B, 0x4F, 0x6C));
                l.setForeground(Color.WHITE);
                l.setFont(new Font("Segoe UI", Font.BOLD, 13));
                l.setHorizontalAlignment(SwingConstants.CENTER);
                l.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 1, new Color(0x13, 0x62, 0x85)),
                        BorderFactory.createEmptyBorder(6, 8, 6, 8)
                ));
                l.setOpaque(true);
                return l;
            }
        };
        header.setDefaultRenderer(headerRenderer);
    }

    public static void hideColumn(JTable table, int modelColumnIndex) {
        TableColumn col = table.getColumnModel().getColumn(modelColumnIndex);
        table.removeColumn(col);
    }

    public static void setColumnWidths(JTable table, int[] preferredWidths, int[] minWidths) {
        TableColumnModel cm = table.getColumnModel();
        for (int i = 0; i < cm.getColumnCount() && i < preferredWidths.length; i++) {
            TableColumn col = cm.getColumn(i);
            col.setPreferredWidth(preferredWidths[i]);
            if (minWidths != null && i < minWidths.length && minWidths[i] > 0) {
                col.setMinWidth(minWidths[i]);
            }
        }
    }

    public static DefaultTableCellRenderer createCenterRenderer() {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        return renderer;
    }

    public static String formatShortDate(Date date) {
        if (date == null) return "-";
        return SHORT_DATE_FORMAT.format(date);
    }

    public static String formatShortDateTime(Date date, Time time) {
        if (date == null) return "-";
        String d = SHORT_DATE_FORMAT.format(date);
        if (time == null) return d;
        String t = String.format("%02d:%02d", time.toLocalTime().getHour(), time.toLocalTime().getMinute());
        return d + ", " + t;
    }
}
