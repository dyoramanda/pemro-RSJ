package com.rsj.config;

import com.rsj.util.PasswordUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {

    public static void initialize() throws SQLException {
        // Step 1: Create database if not exists
        try (Connection serverConn = DatabaseConfig.getServerConnection();
             Statement stmt = serverConn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + DatabaseConfig.getDatabaseName() + "` "
                    + "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            System.out.println("[DatabaseInitializer] Database '" + DatabaseConfig.getDatabaseName() + "' siap.");
        }

        // Step 2: Connect to the database and create tables
        try (Connection conn = DatabaseConfig.getConnection()) {
            createTables(conn);
            seedData(conn);
            System.out.println("[DatabaseInitializer] Inisialisasi tabel dan seed data selesai.");
        }
    }

    private static void createTables(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            // 1. users
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "username VARCHAR(50) NOT NULL UNIQUE,"
                    + "password_hash VARCHAR(255) NOT NULL,"
                    + "nama_lengkap VARCHAR(100) NOT NULL,"
                    + "role ENUM('ADMIN', 'PETUGAS_PENDAFTARAN', 'DOKTER', 'PERAWAT', 'APOTEKER', 'KASIR', 'KELUARGA_PASIEN') NOT NULL,"
                    + "no_telp VARCHAR(20),"
                    + "email VARCHAR(100),"
                    + "status_aktif BOOLEAN DEFAULT TRUE,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                    + ") ENGINE=InnoDB;");

            // 2. penanggung_jawab
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS penanggung_jawab ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "nama_lengkap VARCHAR(100) NOT NULL,"
                    + "hubungan VARCHAR(50) NOT NULL,"
                    + "no_identitas VARCHAR(30) NOT NULL,"
                    + "no_telepon VARCHAR(20) NOT NULL,"
                    + "alamat TEXT,"
                    + "pekerjaan VARCHAR(50),"
                    + "id_user INT NULL,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_pj_user FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL"
                    + ") ENGINE=InnoDB;");

            // 3. ruangan
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS ruangan ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "kode_ruangan VARCHAR(20) NOT NULL UNIQUE,"
                    + "nama_ruangan VARCHAR(100) NOT NULL,"
                    + "kategori ENUM('RAWAT_INAP_AKUT', 'RAWAT_INAP_TENANG', 'REHABILITASI', 'ISOLASI', 'VIP') NOT NULL,"
                    + "kapasitas INT NOT NULL DEFAULT 4,"
                    + "tarif_per_hari DECIMAL(12,2) NOT NULL DEFAULT 0.00,"
                    + "fasilitas TEXT,"
                    + "status_aktif BOOLEAN DEFAULT TRUE"
                    + ") ENGINE=InnoDB;");

            // 4. tempat_tidur
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS tempat_tidur ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_ruangan INT NOT NULL,"
                    + "nomor_bed VARCHAR(20) NOT NULL,"
                    + "status ENUM('TERSEDIA', 'TERISI', 'DALAM_PERBAIKAN', 'DIBERSIHKAN') DEFAULT 'TERSEDIA',"
                    + "catatan VARCHAR(255),"
                    + "CONSTRAINT fk_bed_ruangan FOREIGN KEY (id_ruangan) REFERENCES ruangan(id) ON DELETE CASCADE,"
                    + "CONSTRAINT uq_ruangan_bed UNIQUE (id_ruangan, nomor_bed)"
                    + ") ENGINE=InnoDB;");

            // 5. dokter
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS dokter ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_user INT NULL,"
                    + "nip VARCHAR(30) UNIQUE,"
                    + "nama_lengkap VARCHAR(100) NOT NULL,"
                    + "spesialisasi VARCHAR(100) NOT NULL DEFAULT 'Spesialis Kedokteran Jiwa (Sp.KJ)',"
                    + "no_str VARCHAR(50),"
                    + "no_telepon VARCHAR(20),"
                    + "email VARCHAR(100),"
                    + "tarif_konsultasi DECIMAL(12,2) NOT NULL DEFAULT 150000.00,"
                    + "status_aktif BOOLEAN DEFAULT TRUE,"
                    + "CONSTRAINT fk_dokter_user FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL"
                    + ") ENGINE=InnoDB;");

            // 6. perawat
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS perawat ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_user INT NULL,"
                    + "nip VARCHAR(30) UNIQUE,"
                    + "nama_lengkap VARCHAR(100) NOT NULL,"
                    + "no_str VARCHAR(50),"
                    + "no_telepon VARCHAR(20),"
                    + "shift_default ENUM('PAGI', 'SIANG', 'MALAM') DEFAULT 'PAGI',"
                    + "status_aktif BOOLEAN DEFAULT TRUE,"
                    + "CONSTRAINT fk_perawat_user FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL"
                    + ") ENGINE=InnoDB;");

            // 7. jadwal_dokter
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS jadwal_dokter ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_dokter INT NOT NULL,"
                    + "hari ENUM('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu') NOT NULL,"
                    + "jam_mulai TIME NOT NULL,"
                    + "jam_selesai TIME NOT NULL,"
                    + "kuota_pasien INT NOT NULL DEFAULT 20,"
                    + "status_aktif BOOLEAN DEFAULT TRUE,"
                    + "CONSTRAINT fk_jadwal_dokter FOREIGN KEY (id_dokter) REFERENCES dokter(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 8. pasien
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS pasien ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_rekam_medis VARCHAR(20) NOT NULL UNIQUE,"
                    + "nik VARCHAR(20) NOT NULL UNIQUE,"
                    + "nama_lengkap VARCHAR(100) NOT NULL,"
                    + "jenis_kelamin ENUM('L', 'P') NOT NULL,"
                    + "tanggal_lahir DATE NOT NULL,"
                    + "alamat TEXT,"
                    + "no_telepon VARCHAR(20),"
                    + "status_pernikahan VARCHAR(30),"
                    + "agama VARCHAR(30),"
                    + "golongan_darah VARCHAR(5),"
                    + "status_rawat ENUM('RAWAT_JALAN', 'RAWAT_INAP', 'SUDAH_PULANG', 'RUJUKAN') DEFAULT 'RAWAT_JALAN',"
                    + "tanggal_masuk DATE,"
                    + "tanggal_keluar DATE,"
                    + "id_penanggung_jawab INT NULL,"
                    + "id_ruangan INT NULL,"
                    + "id_tempat_tidur INT NULL,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_pasien_pj FOREIGN KEY (id_penanggung_jawab) REFERENCES penanggung_jawab(id) ON DELETE SET NULL,"
                    + "CONSTRAINT fk_pasien_ruangan FOREIGN KEY (id_ruangan) REFERENCES ruangan(id) ON DELETE SET NULL,"
                    + "CONSTRAINT fk_pasien_bed FOREIGN KEY (id_tempat_tidur) REFERENCES tempat_tidur(id) ON DELETE SET NULL"
                    + ") ENGINE=InnoDB;");

            // 9. pendaftaran
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS pendaftaran ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_pendaftaran VARCHAR(30) NOT NULL UNIQUE,"
                    + "id_pasien INT NOT NULL,"
                    + "id_dokter INT NULL,"
                    + "jenis_kunjungan ENUM('RAWAT_JALAN', 'RAWAT_INAP') NOT NULL,"
                    + "tanggal_daftar DATE NOT NULL,"
                    + "keluhan_utama TEXT,"
                    + "status_pendaftaran ENUM('MENUNGGU', 'DIPERIKSA', 'SELESAI', 'DIBATALKAN') DEFAULT 'MENUNGGU',"
                    + "id_tempat_tidur INT NULL,"
                    + "created_by INT NULL,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_daftar_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_daftar_dokter FOREIGN KEY (id_dokter) REFERENCES dokter(id) ON DELETE SET NULL,"
                    + "CONSTRAINT fk_daftar_bed FOREIGN KEY (id_tempat_tidur) REFERENCES tempat_tidur(id) ON DELETE SET NULL,"
                    + "CONSTRAINT fk_daftar_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL"
                    + ") ENGINE=InnoDB;");

            // 10. rekam_medis
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS rekam_medis ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_rekam_medis_visit VARCHAR(30) NOT NULL UNIQUE,"
                    + "id_pendaftaran INT NOT NULL,"
                    + "id_pasien INT NOT NULL,"
                    + "id_dokter INT NOT NULL,"
                    + "tanggal_periksa DATE NOT NULL,"
                    + "anamnesis TEXT,"
                    + "pemeriksaan_fisik TEXT,"
                    + "status_mental TEXT,"
                    + "catatan_psikiatri TEXT,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_rm_daftar FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_rm_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_rm_dokter FOREIGN KEY (id_dokter) REFERENCES dokter(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 11. diagnosis
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS diagnosis ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_rekam_medis INT NOT NULL,"
                    + "kode_icd VARCHAR(20) NOT NULL,"
                    + "nama_diagnosis VARCHAR(255) NOT NULL,"
                    + "jenis_diagnosis ENUM('UTAMA', 'SEKUNDER') DEFAULT 'UTAMA',"
                    + "deskripsi TEXT,"
                    + "CONSTRAINT fk_diag_rm FOREIGN KEY (id_rekam_medis) REFERENCES rekam_medis(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 12. observasi_harian
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS observasi_harian ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT NOT NULL,"
                    + "id_perawat INT NOT NULL,"
                    + "tanggal_observasi DATE NOT NULL,"
                    + "waktu_observasi TIME NOT NULL,"
                    + "tekanan_darah VARCHAR(20),"
                    + "denyut_nadi INT,"
                    + "suhu_tubuh DECIMAL(4,1),"
                    + "status_kondisi ENUM('TENANG', 'GELISAH', 'AGRESIF', 'KOOPERATIF', 'DEPRESIF') NOT NULL,"
                    + "status_mood VARCHAR(50),"
                    + "kualitas_tidur ENUM('NYENYAK', 'KURANG', 'SULIT_TIDUR', 'TIDAK_TIDUR') DEFAULT 'NYENYAK',"
                    + "kepatuhan_obat ENUM('PATUH', 'MENOLAK', 'PERLU_PENDAMPINGAN', 'DIBANTU') DEFAULT 'PATUH',"
                    + "nafsu_makan VARCHAR(50),"
                    + "catatan_perilaku TEXT,"
                    + "CONSTRAINT fk_obs_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_obs_perawat FOREIGN KEY (id_perawat) REFERENCES perawat(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 13. catatan_insiden
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS catatan_insiden ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT NOT NULL,"
                    + "id_pelapor INT NOT NULL,"
                    + "tanggal_insiden DATE NOT NULL,"
                    + "waktu_insiden TIME NOT NULL,"
                    + "jenis_insiden ENUM('AGRESI_VERBAL', 'AGRESI_FISIK', 'PERCOBAAN_KABUR', 'JATUH', 'PENOLAKAN_MEDIKASI', 'SELF_HARM', 'LAINNYA') NOT NULL,"
                    + "tingkat_risiko ENUM('RENDAH', 'SEDANG', 'TINGGI', 'KRITIS') NOT NULL,"
                    + "deskripsi_kejadian TEXT NOT NULL,"
                    + "tindakan_penanganan TEXT,"
                    + "status_penyelesaian ENUM('DILAPORKAN', 'DALAM_PENANGANAN', 'SELESAI', 'DIEVALUASI') DEFAULT 'DILAPORKAN',"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_ins_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_ins_pelapor FOREIGN KEY (id_pelapor) REFERENCES users(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 14. obat
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS obat ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "kode_obat VARCHAR(20) NOT NULL UNIQUE,"
                    + "nama_obat VARCHAR(100) NOT NULL,"
                    + "kategori ENUM('ANTIPSIKOTIK', 'ANTIDEPRESAN', 'ANKSIOLITIK', 'MOOD_STABILIZER', 'SEDATIF') NOT NULL,"
                    + "bentuk ENUM('TABLET', 'KAPSUL', 'SIRUP', 'INJEKSI', 'DROPS') DEFAULT 'TABLET',"
                    + "dosis VARCHAR(50),"
                    + "stok INT NOT NULL DEFAULT 0,"
                    + "satuan VARCHAR(20) NOT NULL DEFAULT 'Tablet',"
                    + "harga_satuan DECIMAL(12,2) NOT NULL DEFAULT 0.00,"
                    + "deskripsi TEXT"
                    + ") ENGINE=InnoDB;");

            // 15. resep
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS resep ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_resep VARCHAR(30) NOT NULL UNIQUE,"
                    + "id_rekam_medis INT NOT NULL,"
                    + "id_pasien INT NOT NULL,"
                    + "id_dokter INT NOT NULL,"
                    + "tanggal_resep DATE NOT NULL,"
                    + "status ENUM('MENUNGGU', 'DIPROSES', 'SELESAI', 'DIAMBIL') DEFAULT 'MENUNGGU',"
                    + "catatan TEXT,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_resep_rm FOREIGN KEY (id_rekam_medis) REFERENCES rekam_medis(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_resep_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_resep_dokter FOREIGN KEY (id_dokter) REFERENCES dokter(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 16. detail_resep
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS detail_resep ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_resep INT NOT NULL,"
                    + "id_obat INT NOT NULL,"
                    + "jumlah INT NOT NULL,"
                    + "aturan_pakai VARCHAR(100) NOT NULL,"
                    + "petunjuk_khusus VARCHAR(255),"
                    + "subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,"
                    + "CONSTRAINT fk_det_resep FOREIGN KEY (id_resep) REFERENCES resep(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_det_obat FOREIGN KEY (id_obat) REFERENCES obat(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 17. tagihan
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS tagihan ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_tagihan VARCHAR(30) NOT NULL UNIQUE,"
                    + "id_pendaftaran INT NOT NULL,"
                    + "id_pasien INT NOT NULL,"
                    + "tanggal_tagihan DATE NOT NULL,"
                    + "total_biaya_kamar DECIMAL(12,2) DEFAULT 0.00,"
                    + "total_biaya_dokter DECIMAL(12,2) DEFAULT 0.00,"
                    + "total_biaya_obat DECIMAL(12,2) DEFAULT 0.00,"
                    + "total_biaya_tindakan DECIMAL(12,2) DEFAULT 0.00,"
                    + "total_akhir DECIMAL(12,2) NOT NULL DEFAULT 0.00,"
                    + "status_pembayaran ENUM('BELUM_LUNAS', 'LUNAS', 'DICICIL') DEFAULT 'BELUM_LUNAS',"
                    + "batas_waktu DATE,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_tagihan_daftar FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_tagihan_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 18. pembayaran
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS pembayaran ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_transaksi VARCHAR(30) NOT NULL UNIQUE,"
                    + "id_tagihan INT NOT NULL,"
                    + "id_kasir INT NOT NULL,"
                    + "tanggal_bayar TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "jumlah_dibayar DECIMAL(12,2) NOT NULL,"
                    + "metode_pembayaran ENUM('TUNAI', 'TRANSFER', 'KARTU_DEBIT', 'BPJS') NOT NULL,"
                    + "kembalian DECIMAL(12,2) DEFAULT 0.00,"
                    + "referensi_pembayaran VARCHAR(100),"
                    + "catatan VARCHAR(255),"
                    + "CONSTRAINT fk_bayar_tagihan FOREIGN KEY (id_tagihan) REFERENCES tagihan(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_bayar_kasir FOREIGN KEY (id_kasir) REFERENCES users(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 19. jadwal_kunjungan_keluarga
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS jadwal_kunjungan_keluarga ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "no_kunjungan VARCHAR(30) NOT NULL UNIQUE,"
                    + "id_pasien INT NOT NULL,"
                    + "id_penanggung_jawab INT NOT NULL,"
                    + "tanggal_kunjungan DATE NOT NULL,"
                    + "sesi_kunjungan ENUM('PAGI', 'SIANG', 'SORE') NOT NULL,"
                    + "jumlah_pengunjung INT NOT NULL DEFAULT 1,"
                    + "status_kunjungan ENUM('MENUNGGU_PERSETUJUAN', 'DISETUJUI', 'DITOLAK', 'SELESAI') DEFAULT 'MENUNGGU_PERSETUJUAN',"
                    + "catatan TEXT,"
                    + "catatan_petugas TEXT,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_kunjungan_pasien FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,"
                    + "CONSTRAINT fk_kunjungan_pj FOREIGN KEY (id_penanggung_jawab) REFERENCES penanggung_jawab(id) ON DELETE CASCADE"
                    + ") ENGINE=InnoDB;");

            // 20. audit_log
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS audit_log ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_user INT NULL,"
                    + "username VARCHAR(50),"
                    + "aksi VARCHAR(50) NOT NULL,"
                    + "modul VARCHAR(50) NOT NULL,"
                    + "deskripsi TEXT,"
                    + "ip_address VARCHAR(50) DEFAULT '127.0.0.1',"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "CONSTRAINT fk_audit_user FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL"
                    + ") ENGINE=InnoDB;");
        }
    }

    private static void seedData(Connection conn) throws SQLException {
        // Check if users table already has data
        try (Statement checkStmt = conn.createStatement();
             ResultSet rs = checkStmt.executeQuery("SELECT COUNT(*) FROM users")) {
            if (rs.next() && rs.getInt(1) > 0) {
                return; // Already seeded
            }
        }

        System.out.println("[DatabaseInitializer] Menyemai data awal (seed data)...");

        // 1. Seed Users (7 roles)
        String passAdmin = PasswordUtil.hashPassword("admin123");
        String passPetugas = PasswordUtil.hashPassword("petugas123");
        String passDokter = PasswordUtil.hashPassword("dokter123");
        String passPerawat = PasswordUtil.hashPassword("perawat123");
        String passApoteker = PasswordUtil.hashPassword("apoteker123");
        String passKasir = PasswordUtil.hashPassword("kasir123");
        String passKeluarga = PasswordUtil.hashPassword("keluarga123");

        String sqlUser = "INSERT INTO users (username, password_hash, nama_lengkap, role, no_telp, email) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlUser)) {
            // ADMIN (ID 1)
            ps.setString(1, "admin");
            ps.setString(2, passAdmin);
            ps.setString(3, "Dr. Ir. Hendra Saputra, M.Kes");
            ps.setString(4, "ADMIN");
            ps.setString(5, "081234567890");
            ps.setString(6, "admin@rsj-sehatjiwa.id");
            ps.executeUpdate();

            // PETUGAS_PENDAFTARAN (ID 2)
            ps.setString(1, "petugas");
            ps.setString(2, passPetugas);
            ps.setString(3, "Siti Nurhaliza, A.Md.RMIK");
            ps.setString(4, "PETUGAS_PENDAFTARAN");
            ps.setString(5, "081234567891");
            ps.setString(6, "pendaftaran@rsj-sehatjiwa.id");
            ps.executeUpdate();

            // DOKTER (ID 3)
            ps.setString(1, "dokter");
            ps.setString(2, passDokter);
            ps.setString(3, "dr. Budi Santoso, Sp.KJ");
            ps.setString(4, "DOKTER");
            ps.setString(5, "081234567892");
            ps.setString(6, "dr.budi@rsj-sehatjiwa.id");
            ps.executeUpdate();

            // PERAWAT (ID 4)
            ps.setString(1, "perawat");
            ps.setString(2, passPerawat);
            ps.setString(3, "Ns. Ratna Dewi, S.Kep");
            ps.setString(4, "PERAWAT");
            ps.setString(5, "081234567893");
            ps.setString(6, "ns.ratna@rsj-sehatjiwa.id");
            ps.executeUpdate();

            // APOTEKER (ID 5)
            ps.setString(1, "apoteker");
            ps.setString(2, passApoteker);
            ps.setString(3, "apt. Fajar Prasetyo, S.Farm");
            ps.setString(4, "APOTEKER");
            ps.setString(5, "081234567894");
            ps.setString(6, "apotek@rsj-sehatjiwa.id");
            ps.executeUpdate();

            // KASIR (ID 6)
            ps.setString(1, "kasir");
            ps.setString(2, passKasir);
            ps.setString(3, "Dian Anggraini, S.E");
            ps.setString(4, "KASIR");
            ps.setString(5, "081234567895");
            ps.setString(6, "kasir@rsj-sehatjiwa.id");
            ps.executeUpdate();

            // KELUARGA_PASIEN (ID 7)
            ps.setString(1, "keluarga");
            ps.setString(2, passKeluarga);
            ps.setString(3, "Gunawan Wibisono (Wali Keluarga)");
            ps.setString(4, "KELUARGA_PASIEN");
            ps.setString(5, "081234567896");
            ps.setString(6, "keluarga.gunawan@gmail.com");
            ps.executeUpdate();
        }

        // 2. Seed Dokter
        String sqlDokter = "INSERT INTO dokter (id_user, nip, nama_lengkap, spesialisasi, no_str, no_telepon, email, tarif_konsultasi, status_aktif) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlDokter)) {
            ps.setInt(1, 3);
            ps.setString(2, "198005122008121001");
            ps.setString(3, "dr. Budi Santoso, Sp.KJ");
            ps.setString(4, "Spesialis Kedokteran Jiwa (Psikiater Dewasa)");
            ps.setString(5, "STR-3171-88992023");
            ps.setString(6, "081234567892");
            ps.setString(7, "dr.budi@rsj-sehatjiwa.id");
            ps.setBigDecimal(8, new java.math.BigDecimal("200000.00"));
            ps.setBoolean(9, true);
            ps.executeUpdate();

            // Dokter 2 (Kemitraan)
            ps.setNull(1, java.sql.Types.INTEGER);
            ps.setString(2, "198507202012012003");
            ps.setString(3, "dr. Amanda Putri, Sp.KJ(K)");
            ps.setString(4, "Konsultan Psikiatri Anak & Remaja");
            ps.setString(5, "STR-3171-44551022");
            ps.setString(6, "081398765432");
            ps.setString(7, "dr.amanda@rsj-sehatjiwa.id");
            ps.setBigDecimal(8, new java.math.BigDecimal("250000.00"));
            ps.setBoolean(9, true);
            ps.executeUpdate();
        }

        // 3. Seed Perawat
        String sqlPerawat = "INSERT INTO perawat (id_user, nip, nama_lengkap, no_str, no_telepon, shift_default, status_aktif) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlPerawat)) {
            ps.setInt(1, 4);
            ps.setString(2, "199203152016022002");
            ps.setString(3, "Ns. Ratna Dewi, S.Kep");
            ps.setString(4, "STR-PERAWAT-998811");
            ps.setString(5, "081234567893");
            ps.setString(6, "PAGI");
            ps.setBoolean(7, true);
            ps.executeUpdate();

            // Perawat 2
            ps.setNull(1, java.sql.Types.INTEGER);
            ps.setString(2, "199408222018031005");
            ps.setString(3, "Ns. Yoga Pratama, S.Kep");
            ps.setString(4, "STR-PERAWAT-774433");
            ps.setString(5, "085612345678");
            ps.setString(6, "SIANG");
            ps.setBoolean(7, true);
            ps.executeUpdate();
        }

        // 4. Seed Jadwal Dokter
        String sqlJadwal = "INSERT INTO jadwal_dokter (id_dokter, hari, jam_mulai, jam_selesai, kuota_pasien) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlJadwal)) {
            ps.setInt(1, 1);
            ps.setString(2, "Senin");
            ps.setTime(3, java.sql.Time.valueOf("08:00:00"));
            ps.setTime(4, java.sql.Time.valueOf("13:00:00"));
            ps.setInt(5, 20);
            ps.executeUpdate();

            ps.setInt(1, 1);
            ps.setString(2, "Rabu");
            ps.setTime(3, java.sql.Time.valueOf("08:00:00"));
            ps.setTime(4, java.sql.Time.valueOf("13:00:00"));
            ps.setInt(5, 20);
            ps.executeUpdate();

            ps.setInt(1, 1);
            ps.setString(2, "Jumat");
            ps.setTime(3, java.sql.Time.valueOf("08:00:00"));
            ps.setTime(4, java.sql.Time.valueOf("11:30:00"));
            ps.setInt(5, 15);
            ps.executeUpdate();

            ps.setInt(1, 2);
            ps.setString(2, "Selasa");
            ps.setTime(3, java.sql.Time.valueOf("09:00:00"));
            ps.setTime(4, java.sql.Time.valueOf("14:00:00"));
            ps.setInt(5, 15);
            ps.executeUpdate();

            ps.setInt(1, 2);
            ps.setString(2, "Kamis");
            ps.setTime(3, java.sql.Time.valueOf("09:00:00"));
            ps.setTime(4, java.sql.Time.valueOf("14:00:00"));
            ps.setInt(5, 15);
            ps.executeUpdate();
        }

        // 5. Seed Ruangan (3 Ruangan)
        String sqlRuangan = "INSERT INTO ruangan (kode_ruangan, nama_ruangan, kategori, kapasitas, tarif_per_hari, fasilitas) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlRuangan)) {
            ps.setString(1, "R-SAKURA");
            ps.setString(2, "Ruang Sakura (Perawatan Akut Pria)");
            ps.setString(3, "RAWAT_INAP_AKUT");
            ps.setInt(4, 4);
            ps.setBigDecimal(5, new java.math.BigDecimal("250000.00"));
            ps.setString(6, "Kamar mandi dalam khusus anti-cedera, AC sentral, Pengawasan CCTV 24 Jam, Bed pengaman");
            ps.executeUpdate();

            ps.setString(1, "R-MELATI");
            ps.setString(2, "Ruang Melati (Perawatan Akut Wanita)");
            ps.setString(3, "RAWAT_INAP_AKUT");
            ps.setInt(4, 4);
            ps.setBigDecimal(5, new java.math.BigDecimal("250000.00"));
            ps.setString(6, "Kamar mandi dalam anti-cedera, AC sentral, Pengawasan CCTV 24 Jam, Bed pengaman");
            ps.executeUpdate();

            ps.setString(1, "R-TERATAI");
            ps.setString(2, "Ruang Teratai (Rehabilitasi & Pemulihan Mandiri)");
            ps.setString(3, "REHABILITASI");
            ps.setInt(4, 4);
            ps.setBigDecimal(5, new java.math.BigDecimal("180000.00"));
            ps.setString(6, "Taman terapi terbuka, Ruang keterampilan & seni, Ruang konseling kelompok, TV bersama");
            ps.executeUpdate();
        }

        // 6. Seed Tempat Tidur
        String sqlBed = "INSERT INTO tempat_tidur (id_ruangan, nomor_bed, status, catatan) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlBed)) {
            // Sakura (ID 1): 4 beds
            ps.setInt(1, 1); ps.setString(2, "SK-01"); ps.setString(3, "TERISI"); ps.setString(4, "Dekat pos perawat"); ps.executeUpdate();
            ps.setInt(1, 1); ps.setString(2, "SK-02"); ps.setString(3, "TERSEDIA"); ps.setString(4, "Siap pakai"); ps.executeUpdate();
            ps.setInt(1, 1); ps.setString(2, "SK-03"); ps.setString(3, "TERSEDIA"); ps.setString(4, "Siap pakai"); ps.executeUpdate();
            ps.setInt(1, 1); ps.setString(2, "SK-04"); ps.setString(3, "DALAM_PERBAIKAN"); ps.setString(4, "Perbaikan hendel ranjang"); ps.executeUpdate();

            // Melati (ID 2): 4 beds
            ps.setInt(1, 2); ps.setString(2, "ML-01"); ps.setString(3, "TERISI"); ps.setString(4, "Dekat jendela terapi"); ps.executeUpdate();
            ps.setInt(1, 2); ps.setString(2, "ML-02"); ps.setString(3, "TERSEDIA"); ps.setString(4, "Siap pakai"); ps.executeUpdate();
            ps.setInt(1, 2); ps.setString(2, "ML-03"); ps.setString(3, "TERSEDIA"); ps.setString(4, "Siap pakai"); ps.executeUpdate();
            ps.setInt(1, 2); ps.setString(2, "ML-04"); ps.setString(3, "DIBERSIHKAN"); ps.setString(4, "Proses sterilisasi"); ps.executeUpdate();

            // Teratai (ID 3): 4 beds
            ps.setInt(1, 3); ps.setString(2, "TR-01"); ps.setString(3, "TERISI"); ps.setString(4, "Kamar rehabilitasi mandiri A"); ps.executeUpdate();
            ps.setInt(1, 3); ps.setString(2, "TR-02"); ps.setString(3, "TERISI"); ps.setString(4, "Kamar rehabilitasi mandiri B"); ps.executeUpdate();
            ps.setInt(1, 3); ps.setString(2, "TR-03"); ps.setString(3, "TERSEDIA"); ps.setString(4, "Siap pakai"); ps.executeUpdate();
            ps.setInt(1, 3); ps.setString(2, "TR-04"); ps.setString(3, "TERSEDIA"); ps.setString(4, "Siap pakai"); ps.executeUpdate();
        }

        // 7. Seed Penanggung Jawab
        String sqlPJ = "INSERT INTO penanggung_jawab (nama_lengkap, hubungan, no_identitas, no_telepon, alamat, pekerjaan, id_user) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlPJ)) {
            // PJ 1: Linked to user 'keluarga' (id 7)
            ps.setString(1, "Gunawan Wibisono");
            ps.setString(2, "Ayah Kandung");
            ps.setString(3, "3276011203700001");
            ps.setString(4, "081234567896");
            ps.setString(5, "Jl. Anggrek No. 14, Jakarta Selatan");
            ps.setString(6, "Wiraswasta");
            ps.setInt(7, 7);
            ps.executeUpdate();

            // PJ 2
            ps.setString(1, "Sri Wahyuni");
            ps.setString(2, "Istri");
            ps.setString(3, "3276015509750002");
            ps.setString(4, "081298765431");
            ps.setString(5, "Jl. Flamboyan Blok B3, Depok");
            ps.setString(6, "Guru");
            ps.setNull(7, java.sql.Types.INTEGER);
            ps.executeUpdate();

            // PJ 3
            ps.setString(1, "Bambang Sudibyo");
            ps.setString(2, "Kakak Kandung");
            ps.setString(3, "3174021104800004");
            ps.setString(4, "081388776655");
            ps.setString(5, "Jl. Melati Indah No. 8, Tangerang");
            ps.setString(6, "Karyawan Swasta");
            ps.setNull(7, java.sql.Types.INTEGER);
            ps.executeUpdate();
        }

        // 8. Seed 10 Dummy Pasien
        String sqlPasien = "INSERT INTO pasien (no_rekam_medis, nik, nama_lengkap, jenis_kelamin, tanggal_lahir, alamat, no_telepon, status_pernikahan, agama, golongan_darah, status_rawat, tanggal_masuk, id_penanggung_jawab, id_ruangan, id_tempat_tidur) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlPasien)) {
            // 1. Pasien 1 (Anak dari PJ Gunawan Wibisono, Inap di SK-01)
            ps.setString(1, "RM-2026-0001");
            ps.setString(2, "3276012405980003");
            ps.setString(3, "Rian Wibisono");
            ps.setString(4, "L");
            ps.setDate(5, java.sql.Date.valueOf("1998-05-24"));
            ps.setString(6, "Jl. Anggrek No. 14, Jakarta Selatan");
            ps.setString(7, "081234567896");
            ps.setString(8, "Belum Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "B");
            ps.setString(11, "RAWAT_INAP");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-15"));
            ps.setInt(13, 1);
            ps.setInt(14, 1);
            ps.setInt(15, 1); // SK-01
            ps.executeUpdate();

            // 2. Pasien 2 (Inap di ML-01)
            ps.setString(1, "RM-2026-0002");
            ps.setString(2, "3276016608950005");
            ps.setString(3, "Citra Lestari");
            ps.setString(4, "P");
            ps.setDate(5, java.sql.Date.valueOf("1995-08-26"));
            ps.setString(6, "Jl. Kemuning No. 5, Bogor");
            ps.setString(7, "081299887766");
            ps.setString(8, "Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "A");
            ps.setString(11, "RAWAT_INAP");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-18"));
            ps.setInt(13, 2);
            ps.setInt(14, 2);
            ps.setInt(15, 5); // ML-01
            ps.executeUpdate();

            // 3. Pasien 3 (Inap di TR-01)
            ps.setString(1, "RM-2026-0003");
            ps.setString(2, "3174021503920002");
            ps.setString(3, "Ahmad Fauzi");
            ps.setString(4, "L");
            ps.setDate(5, java.sql.Date.valueOf("1992-03-15"));
            ps.setString(6, "Jl. Cempaka Putih No. 12, Jakarta Pusat");
            ps.setString(7, "081377665544");
            ps.setString(8, "Belum Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "O");
            ps.setString(11, "RAWAT_INAP");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-05"));
            ps.setInt(13, 3);
            ps.setInt(14, 3);
            ps.setInt(15, 9); // TR-01
            ps.executeUpdate();

            // 4. Pasien 4 (Inap di TR-02)
            ps.setString(1, "RM-2026-0004");
            ps.setString(2, "3275014407880001");
            ps.setString(3, "Doni Prasetyo");
            ps.setString(4, "L");
            ps.setDate(5, java.sql.Date.valueOf("1988-07-04"));
            ps.setString(6, "Jl. Margonda Raya No. 45, Depok");
            ps.setString(7, "085711223344");
            ps.setString(8, "Duda/Janda");
            ps.setString(9, "Kristen");
            ps.setString(10, "AB");
            ps.setString(11, "RAWAT_INAP");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-10"));
            ps.setInt(13, 1);
            ps.setInt(14, 3);
            ps.setInt(15, 10); // TR-02
            ps.executeUpdate();

            // 5. Pasien 5 (Rawat Jalan)
            ps.setString(1, "RM-2026-0005");
            ps.setString(2, "3171015201010006");
            ps.setString(3, "Nadia Salsabila");
            ps.setString(4, "P");
            ps.setDate(5, java.sql.Date.valueOf("2001-01-12"));
            ps.setString(6, "Jl. Tebet Barat Dalam No. 19, Jakarta");
            ps.setString(7, "081900112233");
            ps.setString(8, "Belum Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "A");
            ps.setString(11, "RAWAT_JALAN");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-25"));
            ps.setInt(13, 1);
            ps.setNull(14, java.sql.Types.INTEGER);
            ps.setNull(15, java.sql.Types.INTEGER);
            ps.executeUpdate();

            // 6. Pasien 6 (Rawat Jalan)
            ps.setString(1, "RM-2026-0006");
            ps.setString(2, "3276022011900008");
            ps.setString(3, "Eko Wahyudi");
            ps.setString(4, "L");
            ps.setDate(5, java.sql.Date.valueOf("1990-11-20"));
            ps.setString(6, "Jl. Raya Sawangan No. 3, Depok");
            ps.setString(7, "081244556677");
            ps.setString(8, "Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "B");
            ps.setString(11, "RAWAT_JALAN");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-26"));
            ps.setInt(13, 2);
            ps.setNull(14, java.sql.Types.INTEGER);
            ps.setNull(15, java.sql.Types.INTEGER);
            ps.executeUpdate();

            // 7. Pasien 7 (Sudah Pulang)
            ps.setString(1, "RM-2026-0007");
            ps.setString(2, "3271010804850003");
            ps.setString(3, "Hadi Gunawan");
            ps.setString(4, "L");
            ps.setDate(5, java.sql.Date.valueOf("1985-04-08"));
            ps.setString(6, "Jl. Pajajaran No. 20, Bogor");
            ps.setString(7, "081355667788");
            ps.setString(8, "Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "O");
            ps.setString(11, "SUDAH_PULANG");
            ps.setDate(12, java.sql.Date.valueOf("2026-09-10"));
            ps.setInt(13, 3);
            ps.setNull(14, java.sql.Types.INTEGER);
            ps.setNull(15, java.sql.Types.INTEGER);
            ps.executeUpdate();

            // 8. Pasien 8 (Rawat Jalan)
            ps.setString(1, "RM-2026-0008");
            ps.setString(2, "3175024912970002");
            ps.setString(3, "Maya Indriani");
            ps.setString(4, "P");
            ps.setDate(5, java.sql.Date.valueOf("1997-12-09"));
            ps.setString(6, "Jl. Kalimalang No. 77, Jakarta Timur");
            ps.setString(7, "081722334455");
            ps.setString(8, "Belum Menikah");
            ps.setString(9, "Katolik");
            ps.setString(10, "AB");
            ps.setString(11, "RAWAT_JALAN");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-26"));
            ps.setInt(13, 1);
            ps.setNull(14, java.sql.Types.INTEGER);
            ps.setNull(15, java.sql.Types.INTEGER);
            ps.executeUpdate();

            // 9. Pasien 9 (Rawat Jalan)
            ps.setString(1, "RM-2026-0009");
            ps.setString(2, "3276013009940004");
            ps.setString(3, "Reza Firmansyah");
            ps.setString(4, "L");
            ps.setDate(5, java.sql.Date.valueOf("1994-09-30"));
            ps.setString(6, "Jl. Cinere Raya Blok H No. 4, Depok");
            ps.setString(7, "081899112244");
            ps.setString(8, "Belum Menikah");
            ps.setString(9, "Islam");
            ps.setString(10, "B");
            ps.setString(11, "RAWAT_JALAN");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-24"));
            ps.setInt(13, 2);
            ps.setNull(14, java.sql.Types.INTEGER);
            ps.setNull(15, java.sql.Types.INTEGER);
            ps.executeUpdate();

            // 10. Pasien 10 (Rawat Jalan)
            ps.setString(1, "RM-2026-0010");
            ps.setString(2, "3173016106000007");
            ps.setString(3, "Tiara Maharani");
            ps.setString(4, "P");
            ps.setDate(5, java.sql.Date.valueOf("2000-06-21"));
            ps.setString(6, "Jl. Tanjung Duren No. 15, Jakarta Barat");
            ps.setString(7, "081266778899");
            ps.setString(8, "Belum Menikah");
            ps.setString(9, "Budha");
            ps.setString(10, "O");
            ps.setString(11, "RAWAT_JALAN");
            ps.setDate(12, java.sql.Date.valueOf("2026-10-26"));
            ps.setInt(13, 3);
            ps.setNull(14, java.sql.Types.INTEGER);
            ps.setNull(15, java.sql.Types.INTEGER);
            ps.executeUpdate();
        }

        // 9. Seed 5 Obat Minimal
        String sqlObat = "INSERT INTO obat (kode_obat, nama_obat, kategori, bentuk, dosis, stok, satuan, harga_satuan, deskripsi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlObat)) {
            // Obat 1
            ps.setString(1, "OBAT-001");
            ps.setString(2, "Risperidone");
            ps.setString(3, "ANTIPSIKOTIK");
            ps.setString(4, "TABLET");
            ps.setString(5, "2 mg");
            ps.setInt(6, 350);
            ps.setString(7, "Tablet");
            ps.setBigDecimal(8, new java.math.BigDecimal("4500.00"));
            ps.setString(9, "Antipsikotik atipikal untuk penanganan skizofrenia dan episode mania bipolar.");
            ps.executeUpdate();

            // Obat 2
            ps.setString(1, "OBAT-002");
            ps.setString(2, "Haloperidol");
            ps.setString(3, "ANTIPSIKOTIK");
            ps.setString(4, "TABLET");
            ps.setString(5, "5 mg");
            ps.setInt(6, 280);
            ps.setString(7, "Tablet");
            ps.setBigDecimal(8, new java.math.BigDecimal("3000.00"));
            ps.setString(9, "Antipsikotik tipikal untuk meredakan gejala psikosis akut, halusinasi, dan agitasi.");
            ps.executeUpdate();

            // Obat 3
            ps.setString(1, "OBAT-003");
            ps.setString(2, "Sertraline HCl");
            ps.setString(3, "ANTIDEPRESAN");
            ps.setString(4, "TABLET");
            ps.setString(5, "50 mg");
            ps.setInt(6, 190);
            ps.setString(7, "Tablet");
            ps.setBigDecimal(8, new java.math.BigDecimal("8500.00"));
            ps.setString(9, "SSRI untuk gangguan depresi mayor, gangguan panik, dan PTSD.");
            ps.executeUpdate();

            // Obat 4
            ps.setString(1, "OBAT-004");
            ps.setString(2, "Diazepam");
            ps.setString(3, "ANKSIOLITIK");
            ps.setString(4, "TABLET");
            ps.setString(5, "5 mg");
            ps.setInt(6, 120);
            ps.setString(7, "Tablet");
            ps.setBigDecimal(8, new java.math.BigDecimal("3500.00"));
            ps.setString(9, "Benzodiazepin untuk mengatasi kecemasan berat, agitasi, dan insomnia jangka pendek.");
            ps.executeUpdate();

            // Obat 5
            ps.setString(1, "OBAT-005");
            ps.setString(2, "Clozapine");
            ps.setString(3, "ANTIPSIKOTIK");
            ps.setString(4, "TABLET");
            ps.setString(5, "25 mg");
            ps.setInt(6, 140);
            ps.setString(7, "Tablet");
            ps.setBigDecimal(8, new java.math.BigDecimal("9000.00"));
            ps.setString(9, "Antipsikotik lini kedua untuk skizofrenia yang resistan terhadap terapi awal.");
            ps.executeUpdate();
        }

        // 10. Seed Pendaftaran & Rekam Medis & Diagnosis & Resep & Observasi
        // Pendaftaran 1 (Rian Wibisono - Rawat Inap)
        String sqlDaftar = "INSERT INTO pendaftaran (no_pendaftaran, id_pasien, id_dokter, jenis_kunjungan, tanggal_daftar, keluhan_utama, status_pendaftaran, id_tempat_tidur, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlDaftar)) {
            ps.setString(1, "REG-20261015-001");
            ps.setInt(2, 1);
            ps.setInt(3, 1);
            ps.setString(4, "RAWAT_INAP");
            ps.setDate(5, java.sql.Date.valueOf("2026-10-15"));
            ps.setString(6, "Sering mendengar bisikan tanpa wujud, gelisah di malam hari dan sulit tidur sejak 1 minggu terakhir.");
            ps.setString(7, "SELESAI");
            ps.setInt(8, 1); // SK-01
            ps.setInt(9, 2); // Petugas
            ps.executeUpdate();

            // Pendaftaran 2 (Citra Lestari - Rawat Inap)
            ps.setString(1, "REG-20261018-002");
            ps.setInt(2, 2);
            ps.setInt(3, 1);
            ps.setString(4, "RAWAT_INAP");
            ps.setDate(5, java.sql.Date.valueOf("2026-10-18"));
            ps.setString(6, "Perubahan suasana hati yang drastis, energi berlebih selama beberapa hari lalu drop depresi berat.");
            ps.setString(7, "SELESAI");
            ps.setInt(8, 5); // ML-01
            ps.setInt(9, 2);
            ps.executeUpdate();

            // Pendaftaran 3 (Nadia Salsabila - Rawat Jalan Hari Ini)
            ps.setString(1, "REG-20261026-003");
            ps.setInt(2, 5);
            ps.setInt(3, 1);
            ps.setString(4, "RAWAT_JALAN");
            ps.setDate(5, java.sql.Date.valueOf("2026-10-26"));
            ps.setString(6, "Kontrol rutin bulanan, mengeluhkan kecemasan saat menghadapi ujian skripsi.");
            ps.setString(7, "MENUNGGU");
            ps.setNull(8, java.sql.Types.INTEGER);
            ps.setInt(9, 2);
            ps.executeUpdate();
        }

        // Rekam Medis untuk Pasien 1
        String sqlRM = "INSERT INTO rekam_medis (no_rekam_medis_visit, id_pendaftaran, id_pasien, id_dokter, tanggal_periksa, anamnesis, pemeriksaan_fisik, status_mental, catatan_psikiatri) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlRM)) {
            ps.setString(1, "RMV-20261015-001");
            ps.setInt(2, 1);
            ps.setInt(3, 1);
            ps.setInt(4, 1);
            ps.setDate(5, java.sql.Date.valueOf("2026-10-15"));
            ps.setString(6, "Pasien diantar oleh ayah kandung. Keluhan halusinasi auditorik berkomentar, curiga terhadap tetangga sekitar.");
            ps.setString(7, "TD: 120/80 mmHg, Nadi: 84 bpm, Suhu: 36.6 C, RR: 18 x/m. Status fisik dalam batas normal.");
            ps.setString(8, "Kontak mata cukup, afek tumpul/inapropriat, terdapat waham kejar dan halusinasi auditorik imperatif, tilikan derajat 2.");
            ps.setString(9, "Direncanakan rawat inap stabilisasi di Ruang Sakura. Psikofarmaka Risperidone 2x2mg dan observasi perilaku berkala.");
            ps.executeUpdate();
        }

        // Diagnosis
        String sqlDiag = "INSERT INTO diagnosis (id_rekam_medis, kode_icd, nama_diagnosis, jenis_diagnosis, deskripsi) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlDiag)) {
            ps.setInt(1, 1);
            ps.setString(2, "F20.0");
            ps.setString(3, "Skizofrenia Paranoid");
            ps.setString(4, "UTAMA");
            ps.setString(5, "Ditandai dengan waham persekutorik yang menonjol dan halusinasi auditorik.");
            ps.executeUpdate();

            ps.setInt(1, 1);
            ps.setString(2, "F51.0");
            ps.setString(3, "Insomnia Non-Organik");
            ps.setString(4, "SEKUNDER");
            ps.setString(5, "Kesulitan mengawali dan mempertahankan tidur nyenyak.");
            ps.executeUpdate();
        }

        // Resep
        String sqlResep = "INSERT INTO resep (no_resep, id_rekam_medis, id_pasien, id_dokter, tanggal_resep, status, catatan) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlResep)) {
            ps.setString(1, "RSP-20261015-001");
            ps.setInt(2, 1);
            ps.setInt(3, 1);
            ps.setInt(4, 1);
            ps.setDate(5, java.sql.Date.valueOf("2026-10-15"));
            ps.setString(6, "SELESAI");
            ps.setString(7, "Minum secara teratur tiap 12 jam, pantau tremor atau kekakuan otot.");
            ps.executeUpdate();
        }

        // Detail Resep
        String sqlDetResep = "INSERT INTO detail_resep (id_resep, id_obat, jumlah, aturan_pakai, petunjuk_khusus, subtotal) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlDetResep)) {
            ps.setInt(1, 1);
            ps.setInt(2, 1); // Risperidone
            ps.setInt(3, 30);
            ps.setString(4, "2 x 1 tablet sehari (pagi & malam)");
            ps.setString(5, "Sesudah makan");
            ps.setBigDecimal(6, new java.math.BigDecimal("135000.00"));
            ps.executeUpdate();

            ps.setInt(1, 1);
            ps.setInt(2, 4); // Diazepam
            ps.setInt(3, 10);
            ps.setString(4, "1 x 1 tablet sehari");
            ps.setString(5, "Malam sebelum tidur jika gelisah");
            ps.setBigDecimal(6, new java.math.BigDecimal("35000.00"));
            ps.executeUpdate();
        }

        // Observasi Harian Pasien 1
        String sqlObs = "INSERT INTO observasi_harian (id_pasien, id_perawat, tanggal_observasi, waktu_observasi, tekanan_darah, denyut_nadi, suhu_tubuh, status_kondisi, status_mood, kualitas_tidur, kepatuhan_obat, nafsu_makan, catatan_perilaku) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlObs)) {
            ps.setInt(1, 1);
            ps.setInt(2, 1);
            ps.setDate(3, java.sql.Date.valueOf("2026-10-25"));
            ps.setTime(4, java.sql.Time.valueOf("08:30:00"));
            ps.setString(5, "120/80");
            ps.setInt(6, 78);
            ps.setBigDecimal(7, new java.math.BigDecimal("36.5"));
            ps.setString(8, "TENANG");
            ps.setString(9, "Eutimik (Stabil)");
            ps.setString(10, "NYENYAK");
            ps.setString(11, "PATUH");
            ps.setString(12, "BAIK");
            ps.setString(13, "Pasien mampu merapikan tempat tidur sendiri, bersedia mengobrol dengan sesama pasien di ruang santai.");
            ps.executeUpdate();

            ps.setInt(1, 1);
            ps.setInt(2, 1);
            ps.setDate(3, java.sql.Date.valueOf("2026-10-26"));
            ps.setTime(4, java.sql.Time.valueOf("08:15:00"));
            ps.setString(5, "118/78");
            ps.setInt(6, 76);
            ps.setBigDecimal(7, new java.math.BigDecimal("36.6"));
            ps.setString(8, "KOOPERATIF");
            ps.setString(9, "Cerah dan Tenang");
            ps.setString(10, "NYENYAK");
            ps.setString(11, "PATUH");
            ps.setString(12, "BAIK");
            ps.setString(13, "Minum obat tepat waktu, mengikuti senam pagi bersama di aula terapi.");
            ps.executeUpdate();
        }

        // Catatan Insiden (Contoh Penolakan Medikasi Ringan)
        String sqlIns = "INSERT INTO catatan_insiden (id_pasien, id_pelapor, tanggal_insiden, waktu_insiden, jenis_insiden, tingkat_risiko, deskripsi_kejadian, tindakan_penanganan, status_penyelesaian) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlIns)) {
            ps.setInt(1, 1);
            ps.setInt(2, 4); // Perawat Ratna
            ps.setDate(3, java.sql.Date.valueOf("2026-10-16"));
            ps.setTime(4, java.sql.Time.valueOf("19:45:00"));
            ps.setString(5, "PENOLAKAN_MEDIKASI");
            ps.setString(6, "SEDANG");
            ps.setString(7, "Pasien sempat ragu dan menolak minum obat malam karena merasa obat terasa pahit dan membuatnya mengantuk.");
            ps.setString(8, "Perawat melakukan pendekatan persuasif ramah, memberikan edukasi manfaat obat dengan teh hangat, pasien akhirnya bersedia minum.");
            ps.setString(9, "SELESAI");
            ps.executeUpdate();
        }

        // Tagihan untuk Pasien 1
        String sqlTagihan = "INSERT INTO tagihan (no_tagihan, id_pendaftaran, id_pasien, tanggal_tagihan, total_biaya_kamar, total_biaya_dokter, total_biaya_obat, total_biaya_tindakan, total_akhir, status_pembayaran, batas_waktu) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlTagihan)) {
            ps.setString(1, "INV-202610-0001");
            ps.setInt(2, 1);
            ps.setInt(3, 1);
            ps.setDate(4, java.sql.Date.valueOf("2026-10-25"));
            ps.setBigDecimal(5, new java.math.BigDecimal("2500000.00")); // 10 hari x 250k
            ps.setBigDecimal(6, new java.math.BigDecimal("400000.00")); // 2x konsultasi
            ps.setBigDecimal(7, new java.math.BigDecimal("170000.00")); // obat
            ps.setBigDecimal(8, new java.math.BigDecimal("150000.00")); // asuhan keperawatan
            ps.setBigDecimal(9, new java.math.BigDecimal("3220000.00"));
            ps.setString(10, "LUNAS");
            ps.setDate(11, java.sql.Date.valueOf("2026-10-31"));
            ps.executeUpdate();
        }

        // Pembayaran untuk Tagihan 1
        String sqlBayar = "INSERT INTO pembayaran (no_transaksi, id_tagihan, id_kasir, jumlah_dibayar, metode_pembayaran, kembalian, referensi_pembayaran, catatan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlBayar)) {
            ps.setString(1, "TRX-20261025-001");
            ps.setInt(2, 1);
            ps.setInt(3, 6); // Kasir Dian
            ps.setBigDecimal(4, new java.math.BigDecimal("3220000.00"));
            ps.setString(5, "TRANSFER");
            ps.setBigDecimal(6, java.math.BigDecimal.ZERO);
            ps.setString(7, "BCA-TRF-99882211");
            ps.setString(8, "Pembayaran lunas via transfer oleh Bpk Gunawan Wibisono.");
            ps.executeUpdate();
        }

        // Jadwal Kunjungan Keluarga
        String sqlKunjungan = "INSERT INTO jadwal_kunjungan_keluarga (no_kunjungan, id_pasien, id_penanggung_jawab, tanggal_kunjungan, sesi_kunjungan, jumlah_pengunjung, status_kunjungan, catatan, catatan_petugas) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlKunjungan)) {
            ps.setString(1, "KNJ-20261027-001");
            ps.setInt(2, 1);
            ps.setInt(3, 1);
            ps.setDate(4, java.sql.Date.valueOf("2026-10-27"));
            ps.setString(5, "SIANG");
            ps.setInt(6, 2);
            ps.setString(7, "DISETUJUI");
            ps.setString(8, "Keluarga ingin membawakan pakaian ganti dan makanan kesukaan pasien.");
            ps.setString(9, "Disetujui. Harap lapor ke pos perawat Ruang Sakura terlebih dahulu.");
            ps.executeUpdate();
        }

        // Audit Log awal
        String sqlAudit = "INSERT INTO audit_log (id_user, username, aksi, modul, deskripsi) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sqlAudit)) {
            ps.setInt(1, 1);
            ps.setString(2, "admin");
            ps.setString(3, "SEED_INIT");
            ps.setString(4, "SYSTEM");
            ps.setString(5, "Inisialisasi sistem rumah sakit jiwa dan data awal berhasil dimuat.");
            ps.executeUpdate();
        }

        System.out.println("[DatabaseInitializer] Data awal (seed data) berhasil disematkan ke database.");
    }
}
