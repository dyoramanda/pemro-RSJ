package com.rsj.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DatabaseConfig {

    private static String host = "localhost";
    private static int port = 3306;
    private static String databaseName = "rsj_odgj_db";
    private static String username = "root";
    private static String password = ""; // Default XAMPP MySQL password is empty

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            try {
                Class.forName("mysql.mysql-connector-java");
            } catch (ClassNotFoundException ignored) {
            }
        }
    }

    public static String getHost() { return host; }
    public static void setHost(String host) { DatabaseConfig.host = host; }

    public static int getPort() { return port; }
    public static void setPort(int port) { DatabaseConfig.port = port; }

    public static String getDatabaseName() { return databaseName; }
    public static void setDatabaseName(String databaseName) { DatabaseConfig.databaseName = databaseName; }

    public static String getUsername() { return username; }
    public static void setUsername(String username) { DatabaseConfig.username = username; }

    public static String getPassword() { return password; }
    public static void setPassword(String password) { DatabaseConfig.password = password; }

    public static String getJdbcUrl() {
        return "jdbc:mysql://" + host + ":" + port + "/" + databaseName +
               "?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Jakarta&useSSL=false&allowPublicKeyRetrieval=true";
    }

    public static String getServerJdbcUrl() {
        return "jdbc:mysql://" + host + ":" + port +
               "?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Jakarta&useSSL=false&allowPublicKeyRetrieval=true";
    }

    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(getJdbcUrl(), username, password);
        } catch (SQLException e) {
            System.err.println("[DatabaseConfig] Gagal menghubungkan ke database " + databaseName + ": " + e.getMessage());
            throw e;
        }
    }

    public static Connection getServerConnection() throws SQLException {
        try {
            return DriverManager.getConnection(getServerJdbcUrl(), username, password);
        } catch (SQLException e) {
            System.err.println("[DatabaseConfig] Gagal menghubungkan ke MySQL Server: " + e.getMessage());
            throw e;
        }
    }

    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    public static void showConnectionErrorDialog(java.awt.Component parent, Exception e) {
        String msg = "<html><body style='width: 320px; font-family: sans-serif;'>"
                   + "<h3 style='color: #E11D48; margin-bottom: 6px;'>Koneksi Database MySQL Gagal!</h3>"
                   + "<p style='color: #334155;'>Aplikasi tidak dapat terhubung ke server MySQL pada:<br>"
                   + "<b>Host:</b> " + host + " | <b>Port:</b> " + port + "<br>"
                   + "<b>Database:</b> " + databaseName + " | <b>User:</b> " + username + "</p>"
                   + "<p style='background-color: #FEF2F2; padding: 8px; border-left: 3px solid #E11D48; color: #991B1B; font-size: 11px;'>"
                   + (e != null ? e.getMessage() : "Unknown error")
                   + "</p>"
                   + "<p style='color: #475569; font-size: 12px;'><b>Langkah Solusi:</b><br>"
                   + "1. Buka <b>XAMPP Control Panel</b> lalu klik tombol <b>Start</b> pada MySQL.<br>"
                   + "2. Pastikan port 3306 aktif dan tidak terblokir oleh firewall/layanan lain.<br>"
                   + "3. Periksa kecocokan username/password MySQL di kelas <code>DatabaseConfig.java</code>.</p>"
                   + "</body></html>";
        JOptionPane.showMessageDialog(parent, msg, "Kesalahan Koneksi Database", JOptionPane.ERROR_MESSAGE);
    }
}
