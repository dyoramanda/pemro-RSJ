package com.rsj.service;

import com.rsj.dao.JadwalKunjunganDao;
import com.rsj.dao.ObservasiHarianDao;
import com.rsj.dao.PasienDao;
import com.rsj.dao.PenanggungJawabDao;
import com.rsj.dao.TagihanDao;
import com.rsj.model.JadwalKunjungan;
import com.rsj.model.ObservasiHarian;
import com.rsj.model.Pasien;
import com.rsj.model.PenanggungJawab;
import com.rsj.model.Tagihan;
import com.rsj.util.SessionManager;
import java.util.Collections;
import java.util.List;

public class KeluargaService {

    private final PasienDao pasienDao = new PasienDao();
    private final PenanggungJawabDao penanggungJawabDao = new PenanggungJawabDao();
    private final ObservasiHarianDao observasiDao = new ObservasiHarianDao();
    private final JadwalKunjunganDao jadwalKunjunganDao = new JadwalKunjunganDao();
    private final TagihanDao tagihanDao = new TagihanDao();

    public PenanggungJawab getCurrentKeluargaPJ() {
        if (SessionManager.getCurrentUser() == null) return null;
        return penanggungJawabDao.findByUserId(SessionManager.getCurrentUser().getId());
    }

    public List<Pasien> getPasienKeluarga() {
        if (SessionManager.getCurrentUser() == null) return Collections.emptyList();
        return pasienDao.findByUserIdKeluarga(SessionManager.getCurrentUser().getId());
    }

    public List<ObservasiHarian> getPerkembanganPasien(int pasienId) {
        return observasiDao.findByPasienId(pasienId);
    }

    public List<JadwalKunjungan> getRiwayatKunjungan() {
        PenanggungJawab pj = getCurrentKeluargaPJ();
        if (pj == null) return Collections.emptyList();
        return jadwalKunjunganDao.findByPenanggungJawabId(pj.getId());
    }

    public void ajukanKunjungan(JadwalKunjungan jk) throws Exception {
        PenanggungJawab pj = getCurrentKeluargaPJ();
        if (pj == null) throw new Exception("Profil keluarga belum terhubung. Hubungi Petugas Pendaftaran.");

        jk.setIdPenanggungJawab(pj.getId());
        jk.setNoKunjungan(jadwalKunjunganDao.generateNextNoKunjungan());
        jk.setStatusKunjungan("MENUNGGU_PERSETUJUAN");

        jadwalKunjunganDao.insert(jk);
        SessionManager.logAction("BOOKING_KUNJUNGAN", "KELUARGA", "Pengajuan bezuk/kunjungan: " + jk.getNoKunjungan());
    }

    public List<Tagihan> getTagihanPasienKeluarga(int pasienId) {
        return tagihanDao.findByPasienId(pasienId);
    }
}
