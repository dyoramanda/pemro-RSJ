package com.rsj.service;

import com.rsj.dao.PembayaranDao;
import com.rsj.dao.PendaftaranDao;
import com.rsj.dao.ResepDao;
import com.rsj.dao.RuanganDao;
import com.rsj.dao.TagihanDao;
import com.rsj.model.Pembayaran;
import com.rsj.model.Pendaftaran;
import com.rsj.model.Resep;
import com.rsj.model.Ruangan;
import com.rsj.model.Tagihan;
import com.rsj.util.SessionManager;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class KasirService {

    private final TagihanDao tagihanDao = new TagihanDao();
    private final PembayaranDao pembayaranDao = new PembayaranDao();
    private final PendaftaranDao pendaftaranDao = new PendaftaranDao();
    private final ResepDao resepDao = new ResepDao();
    private final RuanganDao ruanganDao = new RuanganDao();

    public List<Tagihan> getAllTagihan() { return tagihanDao.findAll(); }
    public List<Tagihan> searchTagihan(String kw, String status) { return tagihanDao.search(kw, status); }
    public Tagihan getTagihanById(int id) { return tagihanDao.findById(id); }

    public Tagihan hitungTagihanOtomatis(int pendaftaranId) throws Exception {
        Pendaftaran pd = pendaftaranDao.findById(pendaftaranId);
        if (pd == null) throw new Exception("Pendaftaran tidak ditemukan.");

        Tagihan t = new Tagihan();
        t.setIdPendaftaran(pendaftaranId);
        t.setIdPasien(pd.getIdPasien());
        t.setTanggalTagihan(new Date(System.currentTimeMillis()));
        t.setBatasWaktu(Date.valueOf(LocalDate.now().plusDays(7)));

        // Biaya Dokter standar
        BigDecimal biayaDokter = new BigDecimal("200000.00");
        t.setTotalBiayaDokter(biayaDokter);

        // Biaya Obat dari Resep
        BigDecimal biayaObat = BigDecimal.ZERO;
        List<Resep> resepList = resepDao.findAll();
        for (Resep r : resepList) {
            if (r.getIdPasien() == pd.getIdPasien() && r.getTanggalResep().toString().equals(pd.getTanggalDaftar().toString())) {
                biayaObat = biayaObat.add(r.getTotalBiaya());
            }
        }
        t.setTotalBiayaObat(biayaObat);

        // Biaya Kamar jika Rawat Inap
        BigDecimal biayaKamar = BigDecimal.ZERO;
        if ("RAWAT_INAP".equalsIgnoreCase(pd.getJenisKunjungan()) && pd.getIdTempatTidur() != null) {
            long days = ChronoUnit.DAYS.between(pd.getTanggalDaftar().toLocalDate(), LocalDate.now());
            if (days < 1) days = 1;
            BigDecimal tarifKamar = new BigDecimal("250000.00");
            biayaKamar = tarifKamar.multiply(new BigDecimal(days));
        }
        t.setTotalBiayaKamar(biayaKamar);

        // Biaya Tindakan & Asuhan Keperawatan
        BigDecimal biayaTindakan = "RAWAT_INAP".equalsIgnoreCase(pd.getJenisKunjungan()) ? new BigDecimal("150000.00") : new BigDecimal("50000.00");
        t.setTotalBiayaTindakan(biayaTindakan);

        BigDecimal totalAkhir = biayaDokter.add(biayaObat).add(biayaKamar).add(biayaTindakan);
        t.setTotalAkhir(totalAkhir);
        t.setStatusPembayaran("BELUM_LUNAS");
        t.setNoTagihan(tagihanDao.generateNextNoTagihan());

        return t;
    }

    public void simpanTagihan(Tagihan t) throws Exception {
        if (t.getNoTagihan() == null || t.getNoTagihan().isEmpty()) {
            t.setNoTagihan(tagihanDao.generateNextNoTagihan());
        }
        tagihanDao.insert(t);
        SessionManager.logAction("BUAT_TAGIHAN", "KASIR", "Penerbitan tagihan " + t.getNoTagihan() + " senilai " + t.getTotalAkhir());
    }

    public Pembayaran prosesPembayaran(int tagihanId, BigDecimal jumlahBayar, String metode, String referensi, String catatan) throws Exception {
        Tagihan t = tagihanDao.findById(tagihanId);
        if (t == null) throw new Exception("Tagihan tidak ditemukan.");

        if (jumlahBayar == null || jumlahBayar.compareTo(BigDecimal.ZERO) <= 0) {
            throw new Exception("Jumlah pembayaran harus lebih dari 0!");
        }

        BigDecimal sisa = t.getSisaTagihan();
        BigDecimal kembalian = BigDecimal.ZERO;
        boolean isLunas = false;

        if (jumlahBayar.compareTo(sisa) >= 0) {
            kembalian = jumlahBayar.subtract(sisa);
            isLunas = true;
        }

        Pembayaran py = new Pembayaran();
        py.setNoTransaksi(pembayaranDao.generateNextNoTransaksi());
        py.setIdTagihan(tagihanId);
        py.setIdKasir(SessionManager.getCurrentUser() != null ? SessionManager.getCurrentUser().getId() : 1);
        py.setJumlahDibayar(jumlahBayar);
        py.setMetodePembayaran(metode != null ? metode : "TUNAI");
        py.setKembalian(kembalian);
        py.setReferensiPembayaran(referensi);
        py.setCatatan(catatan);

        pembayaranDao.insertAndSettleTagihan(py, isLunas);
        SessionManager.logAction("PEMBAYARAN", "KASIR", "Pembayaran tagihan " + t.getNoTagihan() + " sejumlah " + jumlahBayar + " (" + (isLunas ? "LUNAS" : "DICICIL") + ")");

        return py;
    }

    public List<Pembayaran> getRiwayatPembayaran(int tagihanId) {
        return pembayaranDao.findByTagihanId(tagihanId);
    }
}
