package com.rsj.service;

import com.rsj.dao.ObatDao;
import com.rsj.dao.ResepDao;
import com.rsj.model.DetailResep;
import com.rsj.model.Obat;
import com.rsj.model.Resep;
import com.rsj.util.SessionManager;
import java.util.List;

public class ApotekService {

    private final ObatDao obatDao = new ObatDao();
    private final ResepDao resepDao = new ResepDao();

    // Obat
    public List<Obat> getAllObat() { return obatDao.findAll(); }
    public List<Obat> searchObat(String kw, String kat) { return obatDao.search(kw, kat); }
    public Obat getObatById(int id) { return obatDao.findById(id); }

    public void saveObat(Obat o) throws Exception {
        if (o.getNamaObat() == null || o.getNamaObat().trim().isEmpty() ||
            o.getKodeObat() == null || o.getKodeObat().trim().isEmpty()) {
            throw new Exception("Kode dan Nama Obat wajib diisi!");
        }
        if (o.getId() == 0) {
            obatDao.insert(o);
            SessionManager.logAction("TAMBAH", "OBAT", "Tambah obat baru: " + o.getNamaObat() + " (" + o.getKodeObat() + ")");
        } else {
            obatDao.update(o);
            SessionManager.logAction("UBAH", "OBAT", "Update data obat: " + o.getNamaObat());
        }
    }

    public void tambahStok(int obatId, int jumlah) throws Exception {
        if (jumlah <= 0) throw new Exception("Jumlah penambahan harus lebih dari 0!");
        obatDao.updateStok(obatId, jumlah);
        SessionManager.logAction("TAMBAH_STOK", "OBAT", "Penambahan stok obat ID " + obatId + " sebanyak " + jumlah);
    }

    public void deleteObat(int id) throws Exception {
        obatDao.delete(id);
        SessionManager.logAction("HAPUS", "OBAT", "Hapus obat ID: " + id);
    }

    // Resep
    public List<Resep> getAllResep() { return resepDao.findAll(); }
    public List<Resep> searchResep(String kw, String status) { return resepDao.search(kw, status); }
    public Resep getResepById(int id) { return resepDao.findById(id); }

    public void buatResep(Resep r, List<DetailResep> details) throws Exception {
        if (details == null || details.isEmpty()) {
            throw new Exception("Resep harus memiliki minimal 1 obat!");
        }
        r.setNoResep(resepDao.generateNextNoResep());
        r.setStatus("MENUNGGU");
        resepDao.insertWithDetails(r, details);
        SessionManager.logAction("BUAT_RESEP", "APOTEK", "Dokter membuat resep " + r.getNoResep());
    }

    public void prosesResep(int resepId) throws Exception {
        resepDao.updateStatus(resepId, "DIPROSES");
        SessionManager.logAction("PROSES_RESEP", "APOTEK", "Apoteker memproses resep ID: " + resepId);
    }

    public void serahkanObat(int resepId) throws Exception {
        Resep r = resepDao.findById(resepId);
        if (r == null) throw new Exception("Resep tidak ditemukan.");

        // Decrement stock for each medicine
        for (DetailResep d : r.getDetailList()) {
            boolean success = obatDao.updateStok(d.getIdObat(), -d.getJumlah());
            if (!success) {
                throw new Exception("Gagal mengurangi stok obat: " + d.getNamaObat() + ". Stok tidak mencukupi!");
            }
        }

        resepDao.updateStatus(resepId, "SELESAI");
        SessionManager.logAction("SERAHKAN_RESEP", "APOTEK", "Apoteker menyelesaikan penyerahan obat resep " + r.getNoResep());
    }
}
