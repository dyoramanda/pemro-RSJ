package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Perawat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PerawatDao {

    public List<Perawat> findAll() {
        List<Perawat> list = new ArrayList<>();
        String sql = "SELECT * FROM perawat ORDER BY id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[PerawatDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Perawat> search(String keyword) {
        List<Perawat> list = new ArrayList<>();
        String sql = "SELECT * FROM perawat WHERE nama_lengkap LIKE ? OR nip LIKE ? ORDER BY id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[PerawatDao] search error: " + e.getMessage());
        }
        return list;
    }

    public Perawat findById(int id) {
        String sql = "SELECT * FROM perawat WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[PerawatDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public Perawat findByUserId(int userId) {
        String sql = "SELECT * FROM perawat WHERE id_user = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[PerawatDao] findByUserId error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(Perawat p) throws SQLException {
        String sql = "INSERT INTO perawat (id_user, nip, nama_lengkap, no_str, no_telepon, shift_default, status_aktif) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            if (p.getIdUser() != null) ps.setInt(1, p.getIdUser()); else ps.setNull(1, java.sql.Types.INTEGER);
            ps.setString(2, p.getNip());
            ps.setString(3, p.getNamaLengkap());
            ps.setString(4, p.getNoStr());
            ps.setString(5, p.getNoTelepon());
            ps.setString(6, p.getShiftDefault());
            ps.setBoolean(7, p.isStatusAktif());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) p.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Perawat p) throws SQLException {
        String sql = "UPDATE perawat SET nip = ?, nama_lengkap = ?, no_str = ?, no_telepon = ?, shift_default = ?, status_aktif = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNip());
            ps.setString(2, p.getNamaLengkap());
            ps.setString(3, p.getNoStr());
            ps.setString(4, p.getNoTelepon());
            ps.setString(5, p.getShiftDefault());
            ps.setBoolean(6, p.isStatusAktif());
            ps.setInt(7, p.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM perawat WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Perawat mapResultSet(ResultSet rs) throws SQLException {
        Perawat p = new Perawat();
        p.setId(rs.getInt("id"));
        p.setIdUser((Integer) rs.getObject("id_user"));
        p.setNip(rs.getString("nip"));
        p.setNamaLengkap(rs.getString("nama_lengkap"));
        p.setNoStr(rs.getString("no_str"));
        p.setNoTelepon(rs.getString("no_telepon"));
        p.setShiftDefault(rs.getString("shift_default"));
        p.setStatusAktif(rs.getBoolean("status_aktif"));
        return p;
    }
}
