package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Obat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ObatDao {

    public List<Obat> findAll() {
        List<Obat> list = new ArrayList<>();
        String sql = "SELECT * FROM obat ORDER BY nama_obat ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[ObatDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Obat> search(String keyword, String kategoriFilter) {
        List<Obat> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM obat WHERE (nama_obat LIKE ? OR kode_obat LIKE ?)");
        if (kategoriFilter != null && !kategoriFilter.isEmpty() && !kategoriFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND kategori = '").append(kategoriFilter).append("'");
        }
        sql.append(" ORDER BY nama_obat ASC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[ObatDao] search error: " + e.getMessage());
        }
        return list;
    }

    public Obat findById(int id) {
        String sql = "SELECT * FROM obat WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[ObatDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public boolean updateStok(int obatId, int delta) throws SQLException {
        String sql = "UPDATE obat SET stok = stok + ? WHERE id = ? AND (stok + ?) >= 0";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, delta);
            ps.setInt(2, obatId);
            ps.setInt(3, delta);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean insert(Obat o) throws SQLException {
        String sql = "INSERT INTO obat (kode_obat, nama_obat, kategori, bentuk, dosis, stok, satuan, harga_satuan, deskripsi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, o.getKodeObat());
            ps.setString(2, o.getNamaObat());
            ps.setString(3, o.getKategori());
            ps.setString(4, o.getBentuk());
            ps.setString(5, o.getDosis());
            ps.setInt(6, o.getStok());
            ps.setString(7, o.getSatuan());
            ps.setBigDecimal(8, o.getHargaSatuan());
            ps.setString(9, o.getDeskripsi());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) o.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Obat o) throws SQLException {
        String sql = "UPDATE obat SET kode_obat = ?, nama_obat = ?, kategori = ?, bentuk = ?, dosis = ?, stok = ?, satuan = ?, harga_satuan = ?, deskripsi = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, o.getKodeObat());
            ps.setString(2, o.getNamaObat());
            ps.setString(3, o.getKategori());
            ps.setString(4, o.getBentuk());
            ps.setString(5, o.getDosis());
            ps.setInt(6, o.getStok());
            ps.setString(7, o.getSatuan());
            ps.setBigDecimal(8, o.getHargaSatuan());
            ps.setString(9, o.getDeskripsi());
            ps.setInt(10, o.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM obat WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Obat mapResultSet(ResultSet rs) throws SQLException {
        Obat o = new Obat();
        o.setId(rs.getInt("id"));
        o.setKodeObat(rs.getString("kode_obat"));
        o.setNamaObat(rs.getString("nama_obat"));
        o.setKategori(rs.getString("kategori"));
        o.setBentuk(rs.getString("bentuk"));
        o.setDosis(rs.getString("dosis"));
        o.setStok(rs.getInt("stok"));
        o.setSatuan(rs.getString("satuan"));
        o.setHargaSatuan(rs.getBigDecimal("harga_satuan"));
        o.setDeskripsi(rs.getString("deskripsi"));
        return o;
    }
}
