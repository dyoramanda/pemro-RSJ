package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Tagihan;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TagihanDao {

    public List<Tagihan> findAll() {
        List<Tagihan> list = new ArrayList<>();
        String sql = "SELECT t.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, "
                   + "pd.jenis_kunjungan, pd.no_pendaftaran, "
                   + "COALESCE((SELECT SUM(jumlah_dibayar) FROM pembayaran WHERE id_tagihan = t.id), 0) as terbayar "
                   + "FROM tagihan t "
                   + "JOIN pasien p ON t.id_pasien = p.id "
                   + "JOIN pendaftaran pd ON t.id_pendaftaran = pd.id "
                   + "ORDER BY t.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[TagihanDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Tagihan> search(String keyword, String statusFilter) {
        List<Tagihan> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT t.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, "
              + "pd.jenis_kunjungan, pd.no_pendaftaran, "
              + "COALESCE((SELECT SUM(jumlah_dibayar) FROM pembayaran WHERE id_tagihan = t.id), 0) as terbayar "
              + "FROM tagihan t "
              + "JOIN pasien p ON t.id_pasien = p.id "
              + "JOIN pendaftaran pd ON t.id_pendaftaran = pd.id "
              + "WHERE (t.no_tagihan LIKE ? OR p.nama_lengkap LIKE ? OR p.no_rekam_medis LIKE ?)"
        );
        if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND t.status_pembayaran = '").append(statusFilter).append("'");
        }
        sql.append(" ORDER BY t.id DESC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TagihanDao] search error: " + e.getMessage());
        }
        return list;
    }

    public List<Tagihan> findByPasienId(int pasienId) {
        List<Tagihan> list = new ArrayList<>();
        String sql = "SELECT t.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, "
                   + "pd.jenis_kunjungan, pd.no_pendaftaran, "
                   + "COALESCE((SELECT SUM(jumlah_dibayar) FROM pembayaran WHERE id_tagihan = t.id), 0) as terbayar "
                   + "FROM tagihan t "
                   + "JOIN pasien p ON t.id_pasien = p.id "
                   + "JOIN pendaftaran pd ON t.id_pendaftaran = pd.id "
                   + "WHERE t.id_pasien = ? "
                   + "ORDER BY t.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pasienId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TagihanDao] findByPasienId error: " + e.getMessage());
        }
        return list;
    }

    public Tagihan findById(int id) {
        String sql = "SELECT t.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, "
                   + "pd.jenis_kunjungan, pd.no_pendaftaran, "
                   + "COALESCE((SELECT SUM(jumlah_dibayar) FROM pembayaran WHERE id_tagihan = t.id), 0) as terbayar "
                   + "FROM tagihan t "
                   + "JOIN pasien p ON t.id_pasien = p.id "
                   + "JOIN pendaftaran pd ON t.id_pendaftaran = pd.id "
                   + "WHERE t.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[TagihanDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(Tagihan t) throws SQLException {
        String sql = "INSERT INTO tagihan (no_tagihan, id_pendaftaran, id_pasien, tanggal_tagihan, total_biaya_kamar, total_biaya_dokter, total_biaya_obat, total_biaya_tindakan, total_akhir, status_pembayaran, batas_waktu) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, t.getNoTagihan());
            ps.setInt(2, t.getIdPendaftaran());
            ps.setInt(3, t.getIdPasien());
            ps.setDate(4, t.getTanggalTagihan());
            ps.setBigDecimal(5, t.getTotalBiayaKamar());
            ps.setBigDecimal(6, t.getTotalBiayaDokter());
            ps.setBigDecimal(7, t.getTotalBiayaObat());
            ps.setBigDecimal(8, t.getTotalBiayaTindakan());
            ps.setBigDecimal(9, t.getTotalAkhir());
            ps.setString(10, t.getStatusPembayaran());
            ps.setDate(11, t.getBatasWaktu());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) t.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean updateStatus(int id, String status) throws SQLException {
        String sql = "UPDATE tagihan SET status_pembayaran = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextNoTagihan() {
        String month = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMM"));
        String sql = "SELECT COUNT(*) FROM tagihan WHERE DATE_FORMAT(tanggal_tagihan, '%Y%m') = ?";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, month);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) count = rs.getInt(1) + 1;
            }
        } catch (SQLException ignored) {}
        return String.format("INV-%s-%04d", month, count);
    }

    private Tagihan mapResultSet(ResultSet rs) throws SQLException {
        Tagihan t = new Tagihan();
        t.setId(rs.getInt("id"));
        t.setNoTagihan(rs.getString("no_tagihan"));
        t.setIdPendaftaran(rs.getInt("id_pendaftaran"));
        t.setIdPasien(rs.getInt("id_pasien"));
        t.setTanggalTagihan(rs.getDate("tanggal_tagihan"));
        t.setTotalBiayaKamar(rs.getBigDecimal("total_biaya_kamar"));
        t.setTotalBiayaDokter(rs.getBigDecimal("total_biaya_dokter"));
        t.setTotalBiayaObat(rs.getBigDecimal("total_biaya_obat"));
        t.setTotalBiayaTindakan(rs.getBigDecimal("total_biaya_tindakan"));
        t.setTotalAkhir(rs.getBigDecimal("total_akhir"));
        t.setStatusPembayaran(rs.getString("status_pembayaran"));
        t.setBatasWaktu(rs.getDate("batas_waktu"));
        t.setCreatedAt(rs.getTimestamp("created_at"));

        t.setNamaPasien(rs.getString("nama_pasien"));
        t.setNoRekamMedis(rs.getString("no_rekam_medis"));
        t.setJenisKunjungan(rs.getString("jenis_kunjungan"));
        t.setNoPendaftaran(rs.getString("no_pendaftaran"));
        t.setJumlahTerbayar(rs.getBigDecimal("terbayar"));
        t.setSisaTagihan(t.getTotalAkhir().subtract(t.getJumlahTerbayar()));
        return t;
    }
}
