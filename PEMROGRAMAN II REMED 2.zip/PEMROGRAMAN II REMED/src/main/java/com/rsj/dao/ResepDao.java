package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.DetailResep;
import com.rsj.model.Resep;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ResepDao {

    public List<Resep> findAll() {
        List<Resep> list = new ArrayList<>();
        String sql = "SELECT r.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, d.nama_lengkap as nama_dokter "
                   + "FROM resep r "
                   + "JOIN pasien p ON r.id_pasien = p.id "
                   + "JOIN dokter d ON r.id_dokter = d.id "
                   + "ORDER BY r.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Resep r = mapResultSet(rs);
                loadDetails(conn, r);
                list.add(r);
            }
        } catch (SQLException e) {
            System.err.println("[ResepDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Resep> search(String keyword, String statusFilter) {
        List<Resep> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT r.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, d.nama_lengkap as nama_dokter "
              + "FROM resep r "
              + "JOIN pasien p ON r.id_pasien = p.id "
              + "JOIN dokter d ON r.id_dokter = d.id "
              + "WHERE (r.no_resep LIKE ? OR p.nama_lengkap LIKE ? OR p.no_rekam_medis LIKE ?)"
        );
        if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND r.status = '").append(statusFilter).append("'");
        }
        sql.append(" ORDER BY r.id DESC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Resep r = mapResultSet(rs);
                    loadDetails(conn, r);
                    list.add(r);
                }
            }
        } catch (SQLException e) {
            System.err.println("[ResepDao] search error: " + e.getMessage());
        }
        return list;
    }

    public Resep findById(int id) {
        String sql = "SELECT r.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, d.nama_lengkap as nama_dokter "
                   + "FROM resep r "
                   + "JOIN pasien p ON r.id_pasien = p.id "
                   + "JOIN dokter d ON r.id_dokter = d.id "
                   + "WHERE r.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Resep r = mapResultSet(rs);
                    loadDetails(conn, r);
                    return r;
                }
            }
        } catch (SQLException e) {
            System.err.println("[ResepDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public Resep findByRekamMedisId(int rmId) {
        String sql = "SELECT r.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, d.nama_lengkap as nama_dokter "
                   + "FROM resep r "
                   + "JOIN pasien p ON r.id_pasien = p.id "
                   + "JOIN dokter d ON r.id_dokter = d.id "
                   + "WHERE r.id_rekam_medis = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rmId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Resep r = mapResultSet(rs);
                    loadDetails(conn, r);
                    return r;
                }
            }
        } catch (SQLException e) {
            System.err.println("[ResepDao] findByRekamMedisId error: " + e.getMessage());
        }
        return null;
    }

    public boolean insertWithDetails(Resep r, List<DetailResep> details) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConfig.getConnection();
            conn.setAutoCommit(false);

            String sqlResep = "INSERT INTO resep (no_resep, id_rekam_medis, id_pasien, id_dokter, tanggal_resep, status, catatan) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sqlResep, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, r.getNoResep());
                ps.setInt(2, r.getIdRekamMedis());
                ps.setInt(3, r.getIdPasien());
                ps.setInt(4, r.getIdDokter());
                ps.setDate(5, r.getTanggalResep());
                ps.setString(6, r.getStatus());
                ps.setString(7, r.getCatatan());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) r.setId(keys.getInt(1));
                }
            }

            String sqlDetail = "INSERT INTO detail_resep (id_resep, id_obat, jumlah, aturan_pakai, petunjuk_khusus, subtotal) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sqlDetail)) {
                for (DetailResep d : details) {
                    ps.setInt(1, r.getId());
                    ps.setInt(2, d.getIdObat());
                    ps.setInt(3, d.getJumlah());
                    ps.setString(4, d.getAturanPakai());
                    ps.setString(5, d.getPetunjukKhusus());
                    ps.setBigDecimal(6, d.getSubtotal());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) conn.setAutoCommit(true);
        }
    }

    public boolean updateStatus(int resepId, String newStatus) throws SQLException {
        String sql = "UPDATE resep SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, resepId);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextNoResep() {
        String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String sql = "SELECT COUNT(*) FROM resep WHERE tanggal_resep = CURRENT_DATE";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt(1) + 1;
        } catch (SQLException ignored) {}
        return String.format("RSP-%s-%03d", today, count);
    }

    private void loadDetails(Connection conn, Resep r) {
        String sql = "SELECT dr.*, o.nama_obat, o.bentuk, o.dosis, o.harga_satuan "
                   + "FROM detail_resep dr "
                   + "JOIN obat o ON dr.id_obat = o.id "
                   + "WHERE dr.id_resep = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, r.getId());
            try (ResultSet rs = ps.executeQuery()) {
                BigDecimal total = BigDecimal.ZERO;
                List<DetailResep> list = new ArrayList<>();
                while (rs.next()) {
                    DetailResep d = new DetailResep();
                    d.setId(rs.getInt("id"));
                    d.setIdResep(rs.getInt("id_resep"));
                    d.setIdObat(rs.getInt("id_obat"));
                    d.setJumlah(rs.getInt("jumlah"));
                    d.setAturanPakai(rs.getString("aturan_pakai"));
                    d.setPetunjukKhusus(rs.getString("petunjuk_khusus"));
                    d.setSubtotal(rs.getBigDecimal("subtotal"));
                    d.setNamaObat(rs.getString("nama_obat"));
                    d.setBentuk(rs.getString("bentuk"));
                    d.setDosis(rs.getString("dosis"));
                    d.setHargaSatuan(rs.getBigDecimal("harga_satuan"));
                    list.add(d);
                    if (d.getSubtotal() != null) total = total.add(d.getSubtotal());
                }
                r.setDetailList(list);
                r.setTotalBiaya(total);
            }
        } catch (SQLException e) {
            System.err.println("[ResepDao] loadDetails error: " + e.getMessage());
        }
    }

    private Resep mapResultSet(ResultSet rs) throws SQLException {
        Resep r = new Resep();
        r.setId(rs.getInt("id"));
        r.setNoResep(rs.getString("no_resep"));
        r.setIdRekamMedis(rs.getInt("id_rekam_medis"));
        r.setIdPasien(rs.getInt("id_pasien"));
        r.setIdDokter(rs.getInt("id_dokter"));
        r.setTanggalResep(rs.getDate("tanggal_resep"));
        r.setStatus(rs.getString("status"));
        r.setCatatan(rs.getString("catatan"));
        r.setCreatedAt(rs.getTimestamp("created_at"));

        r.setNamaPasien(rs.getString("nama_pasien"));
        r.setNoRekamMedis(rs.getString("no_rekam_medis"));
        r.setNamaDokter(rs.getString("nama_dokter"));
        return r;
    }
}
