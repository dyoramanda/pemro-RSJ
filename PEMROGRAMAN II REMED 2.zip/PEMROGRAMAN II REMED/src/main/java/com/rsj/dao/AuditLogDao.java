package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.AuditLog;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AuditLogDao {

    public void log(Integer userId, String username, String aksi, String modul, String deskripsi) {
        String sql = "INSERT INTO audit_log (id_user, username, aksi, modul, deskripsi, ip_address) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if (userId != null) {
                ps.setInt(1, userId);
            } else {
                ps.setNull(1, java.sql.Types.INTEGER);
            }
            ps.setString(2, username);
            ps.setString(3, aksi);
            ps.setString(4, modul);
            ps.setString(5, deskripsi);
            ps.setString(6, "127.0.0.1");
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[AuditLogDao] Gagal mencatat log: " + e.getMessage());
        }
    }

    public List<AuditLog> getAll(int limit) {
        List<AuditLog> list = new ArrayList<>();
        String sql = "SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    AuditLog log = new AuditLog();
                    log.setId(rs.getInt("id"));
                    log.setIdUser((Integer) rs.getObject("id_user"));
                    log.setUsername(rs.getString("username"));
                    log.setAksi(rs.getString("aksi"));
                    log.setModul(rs.getString("modul"));
                    log.setDeskripsi(rs.getString("deskripsi"));
                    log.setIpAddress(rs.getString("ip_address"));
                    log.setCreatedAt(rs.getTimestamp("created_at"));
                    list.add(log);
                }
            }
        } catch (SQLException e) {
            System.err.println("[AuditLogDao] Error getAll: " + e.getMessage());
        }
        return list;
    }
}
