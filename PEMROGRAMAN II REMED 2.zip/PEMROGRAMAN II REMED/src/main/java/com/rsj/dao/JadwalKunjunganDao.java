package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.JadwalKunjungan;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JadwalKunjunganDao {

    public List<JadwalKunjungan> findAll() {
        List<JadwalKunjungan> list = new ArrayList<>();
        String sql = "SELECT jk.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, "
                   + "pj.nama_lengkap as nama_keluarga, pj.hubungan, pj.no_telepon as telp_keluarga "
                   + "FROM jadwal_kunjungan_keluarga jk "
                   + "JOIN pasien p ON jk.id_pasien = p.id "
                   + "JOIN penanggung_jawab pj ON jk.id_penanggung_jawab = pj.id "
                   + "ORDER BY jk.tanggal_kunjungan DESC, jk.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[JadwalKunjunganDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<JadwalKunjungan> findByPenanggungJawabId(int pjId) {
        List<JadwalKunjungan> list = new ArrayList<>();
        String sql = "SELECT jk.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, "
                   + "pj.nama_lengkap as nama_keluarga, pj.hubungan, pj.no_telepon as telp_keluarga "
                   + "FROM jadwal_kunjungan_keluarga jk "
                   + "JOIN pasien p ON jk.id_pasien = p.id "
                   + "JOIN penanggung_jawab pj ON jk.id_penanggung_jawab = pj.id "
                   + "WHERE jk.id_penanggung_jawab = ? "
                   + "ORDER BY jk.tanggal_kunjungan DESC, jk.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pjId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[JadwalKunjunganDao] findByPenanggungJawabId error: " + e.getMessage());
        }
        return list;
    }

    public boolean insert(JadwalKunjungan jk) throws SQLException {
        String sql = "INSERT INTO jadwal_kunjungan_keluarga (no_kunjungan, id_pasien, id_penanggung_jawab, tanggal_kunjungan, sesi_kunjungan, jumlah_pengunjung, status_kunjungan, catatan, catatan_petugas) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, jk.getNoKunjungan());
            ps.setInt(2, jk.getIdPasien());
            ps.setInt(3, jk.getIdPenanggungJawab());
            ps.setDate(4, jk.getTanggalKunjungan());
            ps.setString(5, jk.getSesiKunjungan());
            ps.setInt(6, jk.getJumlahPengunjung());
            ps.setString(7, jk.getStatusKunjungan());
            ps.setString(8, jk.getCatatan());
            ps.setString(9, jk.getCatatanPetugas());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) jk.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean updateStatus(int id, String status, String catatanPetugas) throws SQLException {
        String sql = "UPDATE jadwal_kunjungan_keluarga SET status_kunjungan = ?, catatan_petugas = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, catatanPetugas);
            ps.setInt(3, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM jadwal_kunjungan_keluarga WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextNoKunjungan() {
        String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String sql = "SELECT COUNT(*) FROM jadwal_kunjungan_keluarga WHERE tanggal_kunjungan = CURRENT_DATE";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt(1) + 1;
        } catch (SQLException ignored) {}
        return String.format("KNJ-%s-%03d", today, count);
    }

    private JadwalKunjungan mapResultSet(ResultSet rs) throws SQLException {
        JadwalKunjungan jk = new JadwalKunjungan();
        jk.setId(rs.getInt("id"));
        jk.setNoKunjungan(rs.getString("no_kunjungan"));
        jk.setIdPasien(rs.getInt("id_pasien"));
        jk.setIdPenanggungJawab(rs.getInt("id_penanggung_jawab"));
        jk.setTanggalKunjungan(rs.getDate("tanggal_kunjungan"));
        jk.setSesiKunjungan(rs.getString("sesi_kunjungan"));
        jk.setJumlahPengunjung(rs.getInt("jumlah_pengunjung"));
        jk.setStatusKunjungan(rs.getString("status_kunjungan"));
        jk.setCatatan(rs.getString("catatan"));
        jk.setCatatanPetugas(rs.getString("catatan_petugas"));
        jk.setCreatedAt(rs.getTimestamp("created_at"));

        jk.setNamaPasien(rs.getString("nama_pasien"));
        jk.setNoRekamMedis(rs.getString("no_rekam_medis"));
        jk.setNamaKeluarga(rs.getString("nama_keluarga"));
        jk.setHubunganKeluarga(rs.getString("hubungan"));
        jk.setNoTeleponKeluarga(rs.getString("telp_keluarga"));
        return jk;
    }
}
