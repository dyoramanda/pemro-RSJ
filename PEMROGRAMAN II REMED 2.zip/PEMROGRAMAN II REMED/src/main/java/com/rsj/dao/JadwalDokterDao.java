package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.JadwalDokter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JadwalDokterDao {

    public List<JadwalDokter> findAll() {
        List<JadwalDokter> list = new ArrayList<>();
        String sql = "SELECT j.*, d.nama_lengkap as nama_dokter, d.spesialisasi "
                   + "FROM jadwal_dokter j "
                   + "JOIN dokter d ON j.id_dokter = d.id "
                   + "ORDER BY FIELD(j.hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), j.jam_mulai ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[JadwalDokterDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<JadwalDokter> findByDokterId(int dokterId) {
        List<JadwalDokter> list = new ArrayList<>();
        String sql = "SELECT j.*, d.nama_lengkap as nama_dokter, d.spesialisasi "
                   + "FROM jadwal_dokter j "
                   + "JOIN dokter d ON j.id_dokter = d.id "
                   + "WHERE j.id_dokter = ? "
                   + "ORDER BY FIELD(j.hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), j.jam_mulai ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, dokterId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[JadwalDokterDao] findByDokterId error: " + e.getMessage());
        }
        return list;
    }

    public boolean insert(JadwalDokter j) throws SQLException {
        String sql = "INSERT INTO jadwal_dokter (id_dokter, hari, jam_mulai, jam_selesai, kuota_pasien, status_aktif) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, j.getIdDokter());
            ps.setString(2, j.getHari());
            ps.setTime(3, j.getJamMulai());
            ps.setTime(4, j.getJamSelesai());
            ps.setInt(5, j.getKuotaPasien());
            ps.setBoolean(6, j.isStatusAktif());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) j.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(JadwalDokter j) throws SQLException {
        String sql = "UPDATE jadwal_dokter SET id_dokter = ?, hari = ?, jam_mulai = ?, jam_selesai = ?, kuota_pasien = ?, status_aktif = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, j.getIdDokter());
            ps.setString(2, j.getHari());
            ps.setTime(3, j.getJamMulai());
            ps.setTime(4, j.getJamSelesai());
            ps.setInt(5, j.getKuotaPasien());
            ps.setBoolean(6, j.isStatusAktif());
            ps.setInt(7, j.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM jadwal_dokter WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private JadwalDokter mapResultSet(ResultSet rs) throws SQLException {
        JadwalDokter j = new JadwalDokter();
        j.setId(rs.getInt("id"));
        j.setIdDokter(rs.getInt("id_dokter"));
        j.setHari(rs.getString("hari"));
        j.setJamMulai(rs.getTime("jam_mulai"));
        j.setJamSelesai(rs.getTime("jam_selesai"));
        j.setKuotaPasien(rs.getInt("kuota_pasien"));
        j.setStatusAktif(rs.getBoolean("status_aktif"));
        j.setNamaDokter(rs.getString("nama_dokter"));
        j.setSpesialisasi(rs.getString("spesialisasi"));
        return j;
    }
}
