package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Pembayaran;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PembayaranDao {

    public List<Pembayaran> findAll() {
        List<Pembayaran> list = new ArrayList<>();
        String sql = "SELECT py.*, t.no_tagihan, u.nama_lengkap as nama_kasir, p.nama_lengkap as nama_pasien "
                   + "FROM pembayaran py "
                   + "JOIN tagihan t ON py.id_tagihan = t.id "
                   + "JOIN pasien p ON t.id_pasien = p.id "
                   + "JOIN users u ON py.id_kasir = u.id "
                   + "ORDER BY py.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[PembayaranDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Pembayaran> findByTagihanId(int tagihanId) {
        List<Pembayaran> list = new ArrayList<>();
        String sql = "SELECT py.*, t.no_tagihan, u.nama_lengkap as nama_kasir, p.nama_lengkap as nama_pasien "
                   + "FROM pembayaran py "
                   + "JOIN tagihan t ON py.id_tagihan = t.id "
                   + "JOIN pasien p ON t.id_pasien = p.id "
                   + "JOIN users u ON py.id_kasir = u.id "
                   + "WHERE py.id_tagihan = ? "
                   + "ORDER BY py.id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, tagihanId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[PembayaranDao] findByTagihanId error: " + e.getMessage());
        }
        return list;
    }

    public boolean insertAndSettleTagihan(Pembayaran py, boolean isLunas) throws SQLException {
        Connection conn = null;
        try {
            conn = DatabaseConfig.getConnection();
            conn.setAutoCommit(false);

            String sqlPay = "INSERT INTO pembayaran (no_transaksi, id_tagihan, id_kasir, jumlah_dibayar, metode_pembayaran, kembalian, referensi_pembayaran, catatan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sqlPay, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, py.getNoTransaksi());
                ps.setInt(2, py.getIdTagihan());
                ps.setInt(3, py.getIdKasir());
                ps.setBigDecimal(4, py.getJumlahDibayar());
                ps.setString(5, py.getMetodePembayaran());
                ps.setBigDecimal(6, py.getKembalian());
                ps.setString(7, py.getReferensiPembayaran());
                ps.setString(8, py.getCatatan());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) py.setId(keys.getInt(1));
                }
            }

            String sqlTagihan = "UPDATE tagihan SET status_pembayaran = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlTagihan)) {
                ps.setString(1, isLunas ? "LUNAS" : "DICICIL");
                ps.setInt(2, py.getIdTagihan());
                ps.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) conn.setAutoCommit(true);
        }
    }

    public String generateNextNoTransaksi() {
        String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String sql = "SELECT COUNT(*) FROM pembayaran WHERE DATE(tanggal_bayar) = CURRENT_DATE";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt(1) + 1;
        } catch (SQLException ignored) {}
        return String.format("TRX-%s-%03d", today, count);
    }

    private Pembayaran mapResultSet(ResultSet rs) throws SQLException {
        Pembayaran py = new Pembayaran();
        py.setId(rs.getInt("id"));
        py.setNoTransaksi(rs.getString("no_transaksi"));
        py.setIdTagihan(rs.getInt("id_tagihan"));
        py.setIdKasir(rs.getInt("id_kasir"));
        py.setTanggalBayar(rs.getTimestamp("tanggal_bayar"));
        py.setJumlahDibayar(rs.getBigDecimal("jumlah_dibayar"));
        py.setMetodePembayaran(rs.getString("metode_pembayaran"));
        py.setKembalian(rs.getBigDecimal("kembalian"));
        py.setReferensiPembayaran(rs.getString("referensi_pembayaran"));
        py.setCatatan(rs.getString("catatan"));

        py.setNoTagihan(rs.getString("no_tagihan"));
        py.setNamaKasir(rs.getString("nama_kasir"));
        py.setNamaPasien(rs.getString("nama_pasien"));
        return py;
    }
}
