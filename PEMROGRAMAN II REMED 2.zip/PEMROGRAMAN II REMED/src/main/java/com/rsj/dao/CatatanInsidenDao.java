package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.CatatanInsiden;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CatatanInsidenDao {

    public List<CatatanInsiden> findAll() {
        List<CatatanInsiden> list = new ArrayList<>();
        String sql = "SELECT ci.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, u.nama_lengkap as nama_pelapor "
                   + "FROM catatan_insiden ci "
                   + "JOIN pasien p ON ci.id_pasien = p.id "
                   + "JOIN users u ON ci.id_pelapor = u.id "
                   + "ORDER BY ci.tanggal_insiden DESC, ci.waktu_insiden DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[CatatanInsidenDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<CatatanInsiden> search(String keyword, String jenisFilter, String risikoFilter) {
        List<CatatanInsiden> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT ci.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, u.nama_lengkap as nama_pelapor "
              + "FROM catatan_insiden ci "
              + "JOIN pasien p ON ci.id_pasien = p.id "
              + "JOIN users u ON ci.id_pelapor = u.id "
              + "WHERE (p.nama_lengkap LIKE ? OR p.no_rekam_medis LIKE ? OR ci.deskripsi_kejadian LIKE ?)"
        );
        if (jenisFilter != null && !jenisFilter.isEmpty() && !jenisFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND ci.jenis_insiden = '").append(jenisFilter).append("'");
        }
        if (risikoFilter != null && !risikoFilter.isEmpty() && !risikoFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND ci.tingkat_risiko = '").append(risikoFilter).append("'");
        }
        sql.append(" ORDER BY ci.tanggal_insiden DESC, ci.waktu_insiden DESC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[CatatanInsidenDao] search error: " + e.getMessage());
        }
        return list;
    }

    public boolean insert(CatatanInsiden ci) throws SQLException {
        String sql = "INSERT INTO catatan_insiden (id_pasien, id_pelapor, tanggal_insiden, waktu_insiden, jenis_insiden, tingkat_risiko, deskripsi_kejadian, tindakan_penanganan, status_penyelesaian) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, ci.getIdPasien());
            ps.setInt(2, ci.getIdPelapor());
            ps.setDate(3, ci.getTanggalInsiden());
            ps.setTime(4, ci.getWaktuInsiden());
            ps.setString(5, ci.getJenisInsiden());
            ps.setString(6, ci.getTingkatRisiko());
            ps.setString(7, ci.getDeskripsiKejadian());
            ps.setString(8, ci.getTindakanPenanganan());
            ps.setString(9, ci.getStatusPenyelesaian());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) ci.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(CatatanInsiden ci) throws SQLException {
        String sql = "UPDATE catatan_insiden SET id_pasien = ?, tanggal_insiden = ?, waktu_insiden = ?, jenis_insiden = ?, tingkat_risiko = ?, deskripsi_kejadian = ?, tindakan_penanganan = ?, status_penyelesaian = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ci.getIdPasien());
            ps.setDate(2, ci.getTanggalInsiden());
            ps.setTime(3, ci.getWaktuInsiden());
            ps.setString(4, ci.getJenisInsiden());
            ps.setString(5, ci.getTingkatRisiko());
            ps.setString(6, ci.getDeskripsiKejadian());
            ps.setString(7, ci.getTindakanPenanganan());
            ps.setString(8, ci.getStatusPenyelesaian());
            ps.setInt(9, ci.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM catatan_insiden WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private CatatanInsiden mapResultSet(ResultSet rs) throws SQLException {
        CatatanInsiden ci = new CatatanInsiden();
        ci.setId(rs.getInt("id"));
        ci.setIdPasien(rs.getInt("id_pasien"));
        ci.setIdPelapor(rs.getInt("id_pelapor"));
        ci.setTanggalInsiden(rs.getDate("tanggal_insiden"));
        ci.setWaktuInsiden(rs.getTime("waktu_insiden"));
        ci.setJenisInsiden(rs.getString("jenis_insiden"));
        ci.setTingkatRisiko(rs.getString("tingkat_risiko"));
        ci.setDeskripsiKejadian(rs.getString("deskripsi_kejadian"));
        ci.setTindakanPenanganan(rs.getString("tindakan_penanganan"));
        ci.setStatusPenyelesaian(rs.getString("status_penyelesaian"));
        ci.setCreatedAt(rs.getTimestamp("created_at"));

        ci.setNamaPasien(rs.getString("nama_pasien"));
        ci.setNoRekamMedis(rs.getString("no_rekam_medis"));
        ci.setNamaPelapor(rs.getString("nama_pelapor"));
        return ci;
    }
}
