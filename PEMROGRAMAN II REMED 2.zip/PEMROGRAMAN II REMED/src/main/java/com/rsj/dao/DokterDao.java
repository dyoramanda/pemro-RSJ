package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Dokter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DokterDao {

    public List<Dokter> findAll() {
        List<Dokter> list = new ArrayList<>();
        String sql = "SELECT * FROM dokter ORDER BY id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[DokterDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Dokter> search(String keyword) {
        List<Dokter> list = new ArrayList<>();
        String sql = "SELECT * FROM dokter WHERE nama_lengkap LIKE ? OR nip LIKE ? OR spesialisasi LIKE ? ORDER BY id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[DokterDao] search error: " + e.getMessage());
        }
        return list;
    }

    public Dokter findById(int id) {
        String sql = "SELECT * FROM dokter WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[DokterDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public Dokter findByUserId(int userId) {
        String sql = "SELECT * FROM dokter WHERE id_user = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[DokterDao] findByUserId error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(Dokter d) throws SQLException {
        String sql = "INSERT INTO dokter (id_user, nip, nama_lengkap, spesialisasi, no_str, no_telepon, email, tarif_konsultasi, status_aktif) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            if (d.getIdUser() != null) ps.setInt(1, d.getIdUser()); else ps.setNull(1, java.sql.Types.INTEGER);
            ps.setString(2, d.getNip());
            ps.setString(3, d.getNamaLengkap());
            ps.setString(4, d.getSpesialisasi());
            ps.setString(5, d.getNoStr());
            ps.setString(6, d.getNoTelepon());
            ps.setString(7, d.getEmail());
            ps.setBigDecimal(8, d.getTarifKonsultasi());
            ps.setBoolean(9, d.isStatusAktif());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) d.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Dokter d) throws SQLException {
        String sql = "UPDATE dokter SET nip = ?, nama_lengkap = ?, spesialisasi = ?, no_str = ?, no_telepon = ?, email = ?, tarif_konsultasi = ?, status_aktif = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, d.getNip());
            ps.setString(2, d.getNamaLengkap());
            ps.setString(3, d.getSpesialisasi());
            ps.setString(4, d.getNoStr());
            ps.setString(5, d.getNoTelepon());
            ps.setString(6, d.getEmail());
            ps.setBigDecimal(7, d.getTarifKonsultasi());
            ps.setBoolean(8, d.isStatusAktif());
            ps.setInt(9, d.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM dokter WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Dokter mapResultSet(ResultSet rs) throws SQLException {
        Dokter d = new Dokter();
        d.setId(rs.getInt("id"));
        d.setIdUser((Integer) rs.getObject("id_user"));
        d.setNip(rs.getString("nip"));
        d.setNamaLengkap(rs.getString("nama_lengkap"));
        d.setSpesialisasi(rs.getString("spesialisasi"));
        d.setNoStr(rs.getString("no_str"));
        d.setNoTelepon(rs.getString("no_telepon"));
        d.setEmail(rs.getString("email"));
        d.setTarifKonsultasi(rs.getBigDecimal("tarif_konsultasi"));
        d.setStatusAktif(rs.getBoolean("status_aktif"));
        return d;
    }
}
