package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.TempatTidur;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TempatTidurDao {

    public List<TempatTidur> findAll() {
        List<TempatTidur> list = new ArrayList<>();
        String sql = "SELECT b.*, r.nama_ruangan, r.kode_ruangan, p.nama_lengkap as nama_pasien "
                   + "FROM tempat_tidur b "
                   + "JOIN ruangan r ON b.id_ruangan = r.id "
                   + "LEFT JOIN pasien p ON p.id_tempat_tidur = b.id "
                   + "ORDER BY r.id ASC, b.nomor_bed ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[TempatTidurDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<TempatTidur> findByRuanganId(int ruanganId) {
        List<TempatTidur> list = new ArrayList<>();
        String sql = "SELECT b.*, r.nama_ruangan, r.kode_ruangan, p.nama_lengkap as nama_pasien "
                   + "FROM tempat_tidur b "
                   + "JOIN ruangan r ON b.id_ruangan = r.id "
                   + "LEFT JOIN pasien p ON p.id_tempat_tidur = b.id "
                   + "WHERE b.id_ruangan = ? "
                   + "ORDER BY b.nomor_bed ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ruanganId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TempatTidurDao] findByRuanganId error: " + e.getMessage());
        }
        return list;
    }

    public List<TempatTidur> findAvailableBeds() {
        List<TempatTidur> list = new ArrayList<>();
        String sql = "SELECT b.*, r.nama_ruangan, r.kode_ruangan, NULL as nama_pasien "
                   + "FROM tempat_tidur b "
                   + "JOIN ruangan r ON b.id_ruangan = r.id "
                   + "WHERE b.status = 'TERSEDIA' "
                   + "ORDER BY r.nama_ruangan ASC, b.nomor_bed ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[TempatTidurDao] findAvailableBeds error: " + e.getMessage());
        }
        return list;
    }

    public boolean updateStatus(int bedId, String status) throws SQLException {
        String sql = "UPDATE tempat_tidur SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, bedId);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean insert(TempatTidur b) throws SQLException {
        String sql = "INSERT INTO tempat_tidur (id_ruangan, nomor_bed, status, catatan) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, b.getIdRuangan());
            ps.setString(2, b.getNomorBed());
            ps.setString(3, b.getStatus());
            ps.setString(4, b.getCatatan());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) b.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(TempatTidur b) throws SQLException {
        String sql = "UPDATE tempat_tidur SET id_ruangan = ?, nomor_bed = ?, status = ?, catatan = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, b.getIdRuangan());
            ps.setString(2, b.getNomorBed());
            ps.setString(3, b.getStatus());
            ps.setString(4, b.getCatatan());
            ps.setInt(5, b.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM tempat_tidur WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private TempatTidur mapResultSet(ResultSet rs) throws SQLException {
        TempatTidur b = new TempatTidur();
        b.setId(rs.getInt("id"));
        b.setIdRuangan(rs.getInt("id_ruangan"));
        b.setNomorBed(rs.getString("nomor_bed"));
        b.setStatus(rs.getString("status"));
        b.setCatatan(rs.getString("catatan"));
        b.setNamaRuangan(rs.getString("nama_ruangan"));
        b.setKodeRuangan(rs.getString("kode_ruangan"));
        b.setNamaPasien(rs.getString("nama_pasien"));
        return b;
    }
}
