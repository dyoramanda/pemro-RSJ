package com.rsj.model;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

public class CatatanInsiden {
    private int id;
    private int idPasien;
    private int idPelapor;
    private Date tanggalInsiden;
    private Time waktuInsiden;
    private String jenisInsiden; // AGRESI_VERBAL, AGRESI_FISIK, PERCOBAAN_KABUR, JATUH, PENOLAKAN_MEDIKASI, SELF_HARM, LAINNYA
    private String tingkatRisiko; // RENDAH, SEDANG, TINGGI, KRITIS
    private String deskripsiKejadian;
    private String tindakanPenanganan; // De-eskalasi verbal, pemisahan lingkungan, fiksasi fisik medis, medikasi darurat
    private String statusPenyelesaian; // DILAPORKAN, DALAM_PENANGANAN, SELESAI, DIEVALUASI
    private Timestamp createdAt;

    // Joined fields
    private String namaPasien;
    private String noRekamMedis;
    private String namaPelapor;

    public CatatanInsiden() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public int getIdPelapor() { return idPelapor; }
    public void setIdPelapor(int idPelapor) { this.idPelapor = idPelapor; }

    public Date getTanggalInsiden() { return tanggalInsiden; }
    public void setTanggalInsiden(Date tanggalInsiden) { this.tanggalInsiden = tanggalInsiden; }

    public Time getWaktuInsiden() { return waktuInsiden; }
    public void setWaktuInsiden(Time waktuInsiden) { this.waktuInsiden = waktuInsiden; }

    public String getJenisInsiden() { return jenisInsiden; }
    public void setJenisInsiden(String jenisInsiden) { this.jenisInsiden = jenisInsiden; }

    public String getTingkatRisiko() { return tingkatRisiko; }
    public void setTingkatRisiko(String tingkatRisiko) { this.tingkatRisiko = tingkatRisiko; }

    public String getDeskripsiKejadian() { return deskripsiKejadian; }
    public void setDeskripsiKejadian(String deskripsiKejadian) { this.deskripsiKejadian = deskripsiKejadian; }

    public String getTindakanPenanganan() { return tindakanPenanganan; }
    public void setTindakanPenanganan(String tindakanPenanganan) { this.tindakanPenanganan = tindakanPenanganan; }

    public String getStatusPenyelesaian() { return statusPenyelesaian; }
    public void setStatusPenyelesaian(String statusPenyelesaian) { this.statusPenyelesaian = statusPenyelesaian; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getNamaPelapor() { return namaPelapor; }
    public void setNamaPelapor(String namaPelapor) { this.namaPelapor = namaPelapor; }

    @Override
    public String toString() {
        return tanggalInsiden + " - " + jenisInsiden + " (" + tingkatRisiko + ")";
    }
}
