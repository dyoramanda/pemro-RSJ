package com.rsj.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Pembayaran {
    private int id;
    private String noTransaksi;
    private int idTagihan;
    private int idKasir;
    private Timestamp tanggalBayar;
    private BigDecimal jumlahDibayar;
    private String metodePembayaran; // TUNAI, TRANSFER, KARTU_DEBIT, BPJS
    private BigDecimal kembalian;
    private String referensiPembayaran;
    private String catatan;

    // Joined fields
    private String noTagihan;
    private String namaKasir;
    private String namaPasien;

    public Pembayaran() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoTransaksi() { return noTransaksi; }
    public void setNoTransaksi(String noTransaksi) { this.noTransaksi = noTransaksi; }

    public int getIdTagihan() { return idTagihan; }
    public void setIdTagihan(int idTagihan) { this.idTagihan = idTagihan; }

    public int getIdKasir() { return idKasir; }
    public void setIdKasir(int idKasir) { this.idKasir = idKasir; }

    public Timestamp getTanggalBayar() { return tanggalBayar; }
    public void setTanggalBayar(Timestamp tanggalBayar) { this.tanggalBayar = tanggalBayar; }

    public BigDecimal getJumlahDibayar() { return jumlahDibayar; }
    public void setJumlahDibayar(BigDecimal jumlahDibayar) { this.jumlahDibayar = jumlahDibayar; }

    public String getMetodePembayaran() { return metodePembayaran; }
    public void setMetodePembayaran(String metodePembayaran) { this.metodePembayaran = metodePembayaran; }

    public BigDecimal getKembalian() { return kembalian; }
    public void setKembalian(BigDecimal kembalian) { this.kembalian = kembalian; }

    public String getReferensiPembayaran() { return referensiPembayaran; }
    public void setReferensiPembayaran(String referensiPembayaran) { this.referensiPembayaran = referensiPembayaran; }

    public String getCatatan() { return catatan; }
    public void setCatatan(String catatan) { this.catatan = catatan; }

    public String getNoTagihan() { return noTagihan; }
    public void setNoTagihan(String noTagihan) { this.noTagihan = noTagihan; }

    public String getNamaKasir() { return namaKasir; }
    public void setNamaKasir(String namaKasir) { this.namaKasir = namaKasir; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    @Override
    public String toString() {
        return noTransaksi + " - " + noTagihan + " (" + metodePembayaran + ")";
    }
}
