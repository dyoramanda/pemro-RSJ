package com.rsj.model;

import java.math.BigDecimal;

public class Ruangan {
    private int id;
    private String kodeRuangan;
    private String namaRuangan;
    private String kategori; // RAWAT_INAP_AKUT, RAWAT_INAP_TENANG, REHABILITASI, ISOLASI, VIP
    private int kapasitas;
    private BigDecimal tarifPerHari;
    private String fasilitas;
    private boolean statusAktif;

    // Computed / joined fields
    private int jumlahBedTerisi;
    private int jumlahBedKosong;

    public Ruangan() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getKodeRuangan() { return kodeRuangan; }
    public void setKodeRuangan(String kodeRuangan) { this.kodeRuangan = kodeRuangan; }

    public String getNamaRuangan() { return namaRuangan; }
    public void setNamaRuangan(String namaRuangan) { this.namaRuangan = namaRuangan; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public int getKapasitas() { return kapasitas; }
    public void setKapasitas(int kapasitas) { this.kapasitas = kapasitas; }

    public BigDecimal getTarifPerHari() { return tarifPerHari; }
    public void setTarifPerHari(BigDecimal tarifPerHari) { this.tarifPerHari = tarifPerHari; }

    public String getFasilitas() { return fasilitas; }
    public void setFasilitas(String fasilitas) { this.fasilitas = fasilitas; }

    public boolean isStatusAktif() { return statusAktif; }
    public void setStatusAktif(boolean statusAktif) { this.statusAktif = statusAktif; }

    public int getJumlahBedTerisi() { return jumlahBedTerisi; }
    public void setJumlahBedTerisi(int jumlahBedTerisi) { this.jumlahBedTerisi = jumlahBedTerisi; }

    public int getJumlahBedKosong() { return jumlahBedKosong; }
    public void setJumlahBedKosong(int jumlahBedKosong) { this.jumlahBedKosong = jumlahBedKosong; }

    @Override
    public String toString() {
        return namaRuangan + " (" + kodeRuangan + ")";
    }
}
