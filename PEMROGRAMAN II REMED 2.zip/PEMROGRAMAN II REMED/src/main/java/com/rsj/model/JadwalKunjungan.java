package com.rsj.model;

import java.sql.Date;
import java.sql.Timestamp;

public class JadwalKunjungan {
    private int id;
    private String noKunjungan;
    private int idPasien;
    private int idPenanggungJawab;
    private Date tanggalKunjungan;
    private String sesiKunjungan; // PAGI (09:00 - 11:00), SIANG (13:00 - 15:00), SORE (16:00 - 17:30)
    private int jumlahPengunjung;
    private String statusKunjungan; // MENUNGGU_PERSETUJUAN, DISETUJUI, DITOLAK, SELESAI
    private String catatan;
    private String catatanPetugas;
    private Timestamp createdAt;

    // Joined fields
    private String namaPasien;
    private String noRekamMedis;
    private String namaKeluarga;
    private String hubunganKeluarga;
    private String noTeleponKeluarga;

    public JadwalKunjungan() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoKunjungan() { return noKunjungan; }
    public void setNoKunjungan(String noKunjungan) { this.noKunjungan = noKunjungan; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public int getIdPenanggungJawab() { return idPenanggungJawab; }
    public void setIdPenanggungJawab(int idPenanggungJawab) { this.idPenanggungJawab = idPenanggungJawab; }

    public Date getTanggalKunjungan() { return tanggalKunjungan; }
    public void setTanggalKunjungan(Date tanggalKunjungan) { this.tanggalKunjungan = tanggalKunjungan; }

    public String getSesiKunjungan() { return sesiKunjungan; }
    public void setSesiKunjungan(String sesiKunjungan) { this.sesiKunjungan = sesiKunjungan; }

    public int getJumlahPengunjung() { return jumlahPengunjung; }
    public void setJumlahPengunjung(int jumlahPengunjung) { this.jumlahPengunjung = jumlahPengunjung; }

    public String getStatusKunjungan() { return statusKunjungan; }
    public void setStatusKunjungan(String statusKunjungan) { this.statusKunjungan = statusKunjungan; }

    public String getCatatan() { return catatan; }
    public void setCatatan(String catatan) { this.catatan = catatan; }

    public String getCatatanPetugas() { return catatanPetugas; }
    public void setCatatanPetugas(String catatanPetugas) { this.catatanPetugas = catatanPetugas; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getNamaKeluarga() { return namaKeluarga; }
    public void setNamaKeluarga(String namaKeluarga) { this.namaKeluarga = namaKeluarga; }

    public String getHubunganKeluarga() { return hubunganKeluarga; }
    public void setHubunganKeluarga(String hubunganKeluarga) { this.hubunganKeluarga = hubunganKeluarga; }

    public String getNoTeleponKeluarga() { return noTeleponKeluarga; }
    public void setNoTeleponKeluarga(String noTeleponKeluarga) { this.noTeleponKeluarga = noTeleponKeluarga; }

    @Override
    public String toString() {
        return tanggalKunjungan + " (" + sesiKunjungan + ") - " + namaPasien + " [" + statusKunjungan + "]";
    }
}
