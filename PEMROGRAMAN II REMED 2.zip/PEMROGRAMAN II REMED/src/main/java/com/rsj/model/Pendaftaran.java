package com.rsj.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Pendaftaran {
    private int id;
    private String noPendaftaran;
    private int idPasien;
    private Integer idDokter;
    private String jenisKunjungan; // RAWAT_JALAN, RAWAT_INAP
    private Date tanggalDaftar;
    private String keluhanUtama;
    private String statusPendaftaran; // MENUNGGU, DIPERIKSA, SELESAI, DIBATALKAN
    private Integer idTempatTidur;
    private Integer createdBy;
    private Timestamp createdAt;

    // Joined fields
    private String noRekamMedis;
    private String namaPasien;
    private String namaDokter;
    private String nomorBed;
    private String namaRuangan;

    public Pendaftaran() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoPendaftaran() { return noPendaftaran; }
    public void setNoPendaftaran(String noPendaftaran) { this.noPendaftaran = noPendaftaran; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public Integer getIdDokter() { return idDokter; }
    public void setIdDokter(Integer idDokter) { this.idDokter = idDokter; }

    public String getJenisKunjungan() { return jenisKunjungan; }
    public void setJenisKunjungan(String jenisKunjungan) { this.jenisKunjungan = jenisKunjungan; }

    public Date getTanggalDaftar() { return tanggalDaftar; }
    public void setTanggalDaftar(Date tanggalDaftar) { this.tanggalDaftar = tanggalDaftar; }

    public String getKeluhanUtama() { return keluhanUtama; }
    public void setKeluhanUtama(String keluhanUtama) { this.keluhanUtama = keluhanUtama; }

    public String getStatusPendaftaran() { return statusPendaftaran; }
    public void setStatusPendaftaran(String statusPendaftaran) { this.statusPendaftaran = statusPendaftaran; }

    public Integer getIdTempatTidur() { return idTempatTidur; }
    public void setIdTempatTidur(Integer idTempatTidur) { this.idTempatTidur = idTempatTidur; }

    public Integer getCreatedBy() { return createdBy; }
    public void setCreatedBy(Integer createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNamaDokter() { return namaDokter; }
    public void setNamaDokter(String namaDokter) { this.namaDokter = namaDokter; }

    public String getNomorBed() { return nomorBed; }
    public void setNomorBed(String nomorBed) { this.nomorBed = nomorBed; }

    public String getNamaRuangan() { return namaRuangan; }
    public void setNamaRuangan(String namaRuangan) { this.namaRuangan = namaRuangan; }

    @Override
    public String toString() {
        return noPendaftaran + " - " + namaPasien + " (" + jenisKunjungan + ")";
    }
}
