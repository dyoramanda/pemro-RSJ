package com.rsj.model;

public class TempatTidur {
    private int id;
    private int idRuangan;
    private String nomorBed;
    private String status; // TERSEDIA, TERISI, DALAM_PERBAIKAN, DIBERSIHKAN
    private String catatan;

    // Joined fields
    private String namaRuangan;
    private String kodeRuangan;
    private String namaPasien;

    public TempatTidur() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdRuangan() { return idRuangan; }
    public void setIdRuangan(int idRuangan) { this.idRuangan = idRuangan; }

    public String getNomorBed() { return nomorBed; }
    public void setNomorBed(String nomorBed) { this.nomorBed = nomorBed; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCatatan() { return catatan; }
    public void setCatatan(String catatan) { this.catatan = catatan; }

    public String getNamaRuangan() { return namaRuangan; }
    public void setNamaRuangan(String namaRuangan) { this.namaRuangan = namaRuangan; }

    public String getKodeRuangan() { return kodeRuangan; }
    public void setKodeRuangan(String kodeRuangan) { this.kodeRuangan = kodeRuangan; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    @Override
    public String toString() {
        return nomorBed + " - " + (namaRuangan != null ? namaRuangan : "") + " [" + status + "]";
    }
}
