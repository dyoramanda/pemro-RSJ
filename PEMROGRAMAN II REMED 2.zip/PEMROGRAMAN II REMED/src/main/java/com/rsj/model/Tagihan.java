package com.rsj.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class Tagihan {
    private int id;
    private String noTagihan;
    private int idPendaftaran;
    private int idPasien;
    private Date tanggalTagihan;
    private BigDecimal totalBiayaKamar;
    private BigDecimal totalBiayaDokter;
    private BigDecimal totalBiayaObat;
    private BigDecimal totalBiayaTindakan;
    private BigDecimal totalAkhir;
    private String statusPembayaran; // BELUM_LUNAS, LUNAS, DICICIL
    private Date batasWaktu;
    private Timestamp createdAt;

    // Joined fields
    private String namaPasien;
    private String noRekamMedis;
    private String jenisKunjungan;
    private String noPendaftaran;
    private BigDecimal jumlahTerbayar = BigDecimal.ZERO;
    private BigDecimal sisaTagihan = BigDecimal.ZERO;

    public Tagihan() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoTagihan() { return noTagihan; }
    public void setNoTagihan(String noTagihan) { this.noTagihan = noTagihan; }

    public int getIdPendaftaran() { return idPendaftaran; }
    public void setIdPendaftaran(int idPendaftaran) { this.idPendaftaran = idPendaftaran; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public Date getTanggalTagihan() { return tanggalTagihan; }
    public void setTanggalTagihan(Date tanggalTagihan) { this.tanggalTagihan = tanggalTagihan; }

    public BigDecimal getTotalBiayaKamar() { return totalBiayaKamar; }
    public void setTotalBiayaKamar(BigDecimal totalBiayaKamar) { this.totalBiayaKamar = totalBiayaKamar; }

    public BigDecimal getTotalBiayaDokter() { return totalBiayaDokter; }
    public void setTotalBiayaDokter(BigDecimal totalBiayaDokter) { this.totalBiayaDokter = totalBiayaDokter; }

    public BigDecimal getTotalBiayaObat() { return totalBiayaObat; }
    public void setTotalBiayaObat(BigDecimal totalBiayaObat) { this.totalBiayaObat = totalBiayaObat; }

    public BigDecimal getTotalBiayaTindakan() { return totalBiayaTindakan; }
    public void setTotalBiayaTindakan(BigDecimal totalBiayaTindakan) { this.totalBiayaTindakan = totalBiayaTindakan; }

    public BigDecimal getTotalAkhir() { return totalAkhir; }
    public void setTotalAkhir(BigDecimal totalAkhir) { this.totalAkhir = totalAkhir; }

    public String getStatusPembayaran() { return statusPembayaran; }
    public void setStatusPembayaran(String statusPembayaran) { this.statusPembayaran = statusPembayaran; }

    public Date getBatasWaktu() { return batasWaktu; }
    public void setBatasWaktu(Date batasWaktu) { this.batasWaktu = batasWaktu; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getJenisKunjungan() { return jenisKunjungan; }
    public void setJenisKunjungan(String jenisKunjungan) { this.jenisKunjungan = jenisKunjungan; }

    public String getNoPendaftaran() { return noPendaftaran; }
    public void setNoPendaftaran(String noPendaftaran) { this.noPendaftaran = noPendaftaran; }

    public BigDecimal getJumlahTerbayar() { return jumlahTerbayar; }
    public void setJumlahTerbayar(BigDecimal jumlahTerbayar) { this.jumlahTerbayar = jumlahTerbayar; }

    public BigDecimal getSisaTagihan() { return sisaTagihan; }
    public void setSisaTagihan(BigDecimal sisaTagihan) { this.sisaTagihan = sisaTagihan; }

    @Override
    public String toString() {
        return noTagihan + " - " + namaPasien + " [" + statusPembayaran + "]";
    }
}
