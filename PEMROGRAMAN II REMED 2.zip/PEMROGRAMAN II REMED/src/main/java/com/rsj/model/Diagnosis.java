package com.rsj.model;

public class Diagnosis {
    private int id;
    private int idRekamMedis;
    private String kodeIcd; // e.g. F20.0 (Skizofrenia Paranoid), F31.0 (Gangguan Afektif Bipolar), F32 (Depresi)
    private String namaDiagnosis;
    private String jenisDiagnosis; // UTAMA, SEKUNDER
    private String deskripsi;

    public Diagnosis() {}

    public Diagnosis(int id, int idRekamMedis, String kodeIcd, String namaDiagnosis, String jenisDiagnosis, String deskripsi) {
        this.id = id;
        this.idRekamMedis = idRekamMedis;
        this.kodeIcd = kodeIcd;
        this.namaDiagnosis = namaDiagnosis;
        this.jenisDiagnosis = jenisDiagnosis;
        this.deskripsi = deskripsi;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdRekamMedis() { return idRekamMedis; }
    public void setIdRekamMedis(int idRekamMedis) { this.idRekamMedis = idRekamMedis; }

    public String getKodeIcd() { return kodeIcd; }
    public void setKodeIcd(String kodeIcd) { this.kodeIcd = kodeIcd; }

    public String getNamaDiagnosis() { return namaDiagnosis; }
    public void setNamaDiagnosis(String namaDiagnosis) { this.namaDiagnosis = namaDiagnosis; }

    public String getJenisDiagnosis() { return jenisDiagnosis; }
    public void setJenisDiagnosis(String jenisDiagnosis) { this.jenisDiagnosis = jenisDiagnosis; }

    public String getDeskripsi() { return deskripsi; }
    public void setDeskripsi(String deskripsi) { this.deskripsi = deskripsi; }

    @Override
    public String toString() {
        return "[" + kodeIcd + "] " + namaDiagnosis + " (" + jenisDiagnosis + ")";
    }
}
