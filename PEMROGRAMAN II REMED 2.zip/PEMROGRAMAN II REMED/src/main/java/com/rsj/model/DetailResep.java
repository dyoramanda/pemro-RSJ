package com.rsj.model;

import java.math.BigDecimal;

public class DetailResep {
    private int id;
    private int idResep;
    private int idObat;
    private int jumlah;
    private String aturanPakai; // e.g. 2 x 1 tablet sehari sesudah makan
    private String petunjukKhusus; // e.g. Malam sebelum tidur
    private BigDecimal subtotal;

    // Joined fields
    private String namaObat;
    private String bentuk;
    private String dosis;
    private BigDecimal hargaSatuan;

    public DetailResep() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdResep() { return idResep; }
    public void setIdResep(int idResep) { this.idResep = idResep; }

    public int getIdObat() { return idObat; }
    public void setIdObat(int idObat) { this.idObat = idObat; }

    public int getJumlah() { return jumlah; }
    public void setJumlah(int jumlah) { this.jumlah = jumlah; }

    public String getAturanPakai() { return aturanPakai; }
    public void setAturanPakai(String aturanPakai) { this.aturanPakai = aturanPakai; }

    public String getPetunjukKhusus() { return petunjukKhusus; }
    public void setPetunjukKhusus(String petunjukKhusus) { this.petunjukKhusus = petunjukKhusus; }

    public BigDecimal getSubtotal() { return subtotal; }
    public void setSubtotal(BigDecimal subtotal) { this.subtotal = subtotal; }

    public String getNamaObat() { return namaObat; }
    public void setNamaObat(String namaObat) { this.namaObat = namaObat; }

    public String getBentuk() { return bentuk; }
    public void setBentuk(String bentuk) { this.bentuk = bentuk; }

    public String getDosis() { return dosis; }
    public void setDosis(String dosis) { this.dosis = dosis; }

    public BigDecimal getHargaSatuan() { return hargaSatuan; }
    public void setHargaSatuan(BigDecimal hargaSatuan) { this.hargaSatuan = hargaSatuan; }

    @Override
    public String toString() {
        return namaObat + " (" + jumlah + ") - " + aturanPakai;
    }
}
