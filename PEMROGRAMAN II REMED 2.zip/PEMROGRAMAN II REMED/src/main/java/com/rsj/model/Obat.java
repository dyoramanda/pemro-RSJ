package com.rsj.model;

import java.math.BigDecimal;

public class Obat {
    private int id;
    private String kodeObat;
    private String namaObat;
    private String kategori; // ANTIPSIKOTIK, ANTIDEPRESAN, ANKSIOLITIK, MOOD_STABILIZER, SEDATIF
    private String bentuk; // TABLET, KAPSUL, SIRUP, INJEKSI, DROPS
    private String dosis; // e.g. 2 mg, 5 mg, 50 mg
    private int stok;
    private String satuan; // Tablet, Botol, Ampul, Strip
    private BigDecimal hargaSatuan;
    private String deskripsi;

    public Obat() {}

    public Obat(int id, String kodeObat, String namaObat, String kategori, String bentuk, String dosis, int stok, String satuan, BigDecimal hargaSatuan, String deskripsi) {
        this.id = id;
        this.kodeObat = kodeObat;
        this.namaObat = namaObat;
        this.kategori = kategori;
        this.bentuk = bentuk;
        this.dosis = dosis;
        this.stok = stok;
        this.satuan = satuan;
        this.hargaSatuan = hargaSatuan;
        this.deskripsi = deskripsi;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getKodeObat() { return kodeObat; }
    public void setKodeObat(String kodeObat) { this.kodeObat = kodeObat; }

    public String getNamaObat() { return namaObat; }
    public void setNamaObat(String namaObat) { this.namaObat = namaObat; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getBentuk() { return bentuk; }
    public void setBentuk(String bentuk) { this.bentuk = bentuk; }

    public String getDosis() { return dosis; }
    public void setDosis(String dosis) { this.dosis = dosis; }

    public int getStok() { return stok; }
    public void setStok(int stok) { this.stok = stok; }

    public String getSatuan() { return satuan; }
    public void setSatuan(String satuan) { this.satuan = satuan; }

    public BigDecimal getHargaSatuan() { return hargaSatuan; }
    public void setHargaSatuan(BigDecimal hargaSatuan) { this.hargaSatuan = hargaSatuan; }

    public String getDeskripsi() { return deskripsi; }
    public void setDeskripsi(String deskripsi) { this.deskripsi = deskripsi; }

    @Override
    public String toString() {
        return namaObat + " " + (dosis != null ? dosis : "") + " (Stok: " + stok + " " + satuan + ")";
    }
}
