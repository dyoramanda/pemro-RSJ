package com.rsj.model;

import java.sql.Time;

public class JadwalDokter {
    private int id;
    private int idDokter;
    private String hari; // Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Minggu
    private Time jamMulai;
    private Time jamSelesai;
    private int kuotaPasien;
    private boolean statusAktif;

    // Joined fields
    private String namaDokter;
    private String spesialisasi;

    public JadwalDokter() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdDokter() { return idDokter; }
    public void setIdDokter(int idDokter) { this.idDokter = idDokter; }

    public String getHari() { return hari; }
    public void setHari(String hari) { this.hari = hari; }

    public Time getJamMulai() { return jamMulai; }
    public void setJamMulai(Time jamMulai) { this.jamMulai = jamMulai; }

    public Time getJamSelesai() { return jamSelesai; }
    public void setJamSelesai(Time jamSelesai) { this.jamSelesai = jamSelesai; }

    public int getKuotaPasien() { return kuotaPasien; }
    public void setKuotaPasien(int kuotaPasien) { this.kuotaPasien = kuotaPasien; }

    public boolean isStatusAktif() { return statusAktif; }
    public void setStatusAktif(boolean statusAktif) { this.statusAktif = statusAktif; }

    public String getNamaDokter() { return namaDokter; }
    public void setNamaDokter(String namaDokter) { this.namaDokter = namaDokter; }

    public String getSpesialisasi() { return spesialisasi; }
    public void setSpesialisasi(String spesialisasi) { this.spesialisasi = spesialisasi; }

    @Override
    public String toString() {
        return hari + " (" + jamMulai + " - " + jamSelesai + ") - " + (namaDokter != null ? namaDokter : "Dokter");
    }
}
