package com.rsj.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Resep {
    private int id;
    private String noResep;
    private int idRekamMedis;
    private int idPasien;
    private int idDokter;
    private Date tanggalResep;
    private String status; // MENUNGGU, DIPROSES, SELESAI, DIAMBIL
    private String catatan;
    private Timestamp createdAt;

    // Joined fields
    private String namaPasien;
    private String noRekamMedis;
    private String namaDokter;
    private List<DetailResep> detailList = new ArrayList<>();
    private BigDecimal totalBiaya = BigDecimal.ZERO;

    public Resep() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoResep() { return noResep; }
    public void setNoResep(String noResep) { this.noResep = noResep; }

    public int getIdRekamMedis() { return idRekamMedis; }
    public void setIdRekamMedis(int idRekamMedis) { this.idRekamMedis = idRekamMedis; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public int getIdDokter() { return idDokter; }
    public void setIdDokter(int idDokter) { this.idDokter = idDokter; }

    public Date getTanggalResep() { return tanggalResep; }
    public void setTanggalResep(Date tanggalResep) { this.tanggalResep = tanggalResep; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCatatan() { return catatan; }
    public void setCatatan(String catatan) { this.catatan = catatan; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getNamaDokter() { return namaDokter; }
    public void setNamaDokter(String namaDokter) { this.namaDokter = namaDokter; }

    public List<DetailResep> getDetailList() { return detailList; }
    public void setDetailList(List<DetailResep> detailList) { this.detailList = detailList; }

    public BigDecimal getTotalBiaya() { return totalBiaya; }
    public void setTotalBiaya(BigDecimal totalBiaya) { this.totalBiaya = totalBiaya; }

    @Override
    public String toString() {
        return noResep + " - " + namaPasien + " [" + status + "]";
    }
}
