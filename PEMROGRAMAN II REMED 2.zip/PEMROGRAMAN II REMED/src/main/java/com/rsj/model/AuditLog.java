package com.rsj.model;

import java.sql.Timestamp;

public class AuditLog {
    private int id;
    private Integer idUser;
    private String username;
    private String aksi; // LOGIN, LOGOUT, TAMBAH, UBAH, HAPUS, CETAK, STATUS_CHANGE
    private String modul; // USER, PASIEN, REKAM_MEDIS, RESEP, TAGIHAN, OBSERVASI, INSIDEN, dll.
    private String deskripsi;
    private String ipAddress;
    private Timestamp createdAt;

    public AuditLog() {}

    public AuditLog(Integer idUser, String username, String aksi, String modul, String deskripsi) {
        this.idUser = idUser;
        this.username = username;
        this.aksi = aksi;
        this.modul = modul;
        this.deskripsi = deskripsi;
        this.ipAddress = "127.0.0.1";
        this.createdAt = new Timestamp(System.currentTimeMillis());
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Integer getIdUser() { return idUser; }
    public void setIdUser(Integer idUser) { this.idUser = idUser; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getAksi() { return aksi; }
    public void setAksi(String aksi) { this.aksi = aksi; }

    public String getModul() { return modul; }
    public void setModul(String modul) { this.modul = modul; }

    public String getDeskripsi() { return deskripsi; }
    public void setDeskripsi(String deskripsi) { this.deskripsi = deskripsi; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "[" + createdAt + "] " + username + " - " + aksi + " " + modul + ": " + deskripsi;
    }
}
