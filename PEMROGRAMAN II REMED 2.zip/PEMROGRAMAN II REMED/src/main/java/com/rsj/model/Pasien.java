package com.rsj.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Pasien {
    private int id;
    private String noRekamMedis;
    private String nik;
    private String namaLengkap;
    private String jenisKelamin; // L / P
    private Date tanggalLahir;
    private String alamat;
    private String noTelepon;
    private String statusPernikahan;
    private String agama;
    private String golonganDarah;
    private String statusRawat; // RAWAT_JALAN, RAWAT_INAP, SUDAH_PULANG, RUJUKAN
    private Date tanggalMasuk;
    private Date tanggalKeluar;
    private Integer idPenanggungJawab;
    private Integer idRuangan;
    private Integer idTempatTidur;
    private Timestamp createdAt;

    // Joined helper fields
    private String namaPenanggungJawab;
    private String namaRuangan;
    private String nomorBed;

    public Pasien() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getNik() { return nik; }
    public void setNik(String nik) { this.nik = nik; }

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getJenisKelamin() { return jenisKelamin; }
    public void setJenisKelamin(String jenisKelamin) { this.jenisKelamin = jenisKelamin; }

    public Date getTanggalLahir() { return tanggalLahir; }
    public void setTanggalLahir(Date tanggalLahir) { this.tanggalLahir = tanggalLahir; }

    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }

    public String getNoTelepon() { return noTelepon; }
    public void setNoTelepon(String noTelepon) { this.noTelepon = noTelepon; }

    public String getStatusPernikahan() { return statusPernikahan; }
    public void setStatusPernikahan(String statusPernikahan) { this.statusPernikahan = statusPernikahan; }

    public String getAgama() { return agama; }
    public void setAgama(String agama) { this.agama = agama; }

    public String getGolonganDarah() { return golonganDarah; }
    public void setGolonganDarah(String golonganDarah) { this.golonganDarah = golonganDarah; }

    public String getStatusRawat() { return statusRawat; }
    public void setStatusRawat(String statusRawat) { this.statusRawat = statusRawat; }

    public Date getTanggalMasuk() { return tanggalMasuk; }
    public void setTanggalMasuk(Date tanggalMasuk) { this.tanggalMasuk = tanggalMasuk; }

    public Date getTanggalKeluar() { return tanggalKeluar; }
    public void setTanggalKeluar(Date tanggalKeluar) { this.tanggalKeluar = tanggalKeluar; }

    public Integer getIdPenanggungJawab() { return idPenanggungJawab; }
    public void setIdPenanggungJawab(Integer idPenanggungJawab) { this.idPenanggungJawab = idPenanggungJawab; }

    public Integer getIdRuangan() { return idRuangan; }
    public void setIdRuangan(Integer idRuangan) { this.idRuangan = idRuangan; }

    public Integer getIdTempatTidur() { return idTempatTidur; }
    public void setIdTempatTidur(Integer idTempatTidur) { this.idTempatTidur = idTempatTidur; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNamaPenanggungJawab() { return namaPenanggungJawab; }
    public void setNamaPenanggungJawab(String namaPenanggungJawab) { this.namaPenanggungJawab = namaPenanggungJawab; }

    public String getNamaRuangan() { return namaRuangan; }
    public void setNamaRuangan(String namaRuangan) { this.namaRuangan = namaRuangan; }

    public String getNomorBed() { return nomorBed; }
    public void setNomorBed(String nomorBed) { this.nomorBed = nomorBed; }

    @Override
    public String toString() {
        return noRekamMedis + " - " + namaLengkap;
    }
}
