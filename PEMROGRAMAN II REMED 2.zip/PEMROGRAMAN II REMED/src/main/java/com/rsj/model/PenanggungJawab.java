package com.rsj.model;

import java.sql.Timestamp;

public class PenanggungJawab {
    private int id;
    private String namaLengkap;
    private String hubungan; // Orang Tua, Suami/Istri, Anak, Saudara Kandung, Wali
    private String noIdentitas; // KTP / Paspor
    private String noTelepon;
    private String alamat;
    private String pekerjaan;
    private Integer idUser; // Optional link to User account
    private Timestamp createdAt;

    // Joined helper field
    private String usernameKeluarga;

    public PenanggungJawab() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getHubungan() { return hubungan; }
    public void setHubungan(String hubungan) { this.hubungan = hubungan; }

    public String getNoIdentitas() { return noIdentitas; }
    public void setNoIdentitas(String noIdentitas) { this.noIdentitas = noIdentitas; }

    public String getNoTelepon() { return noTelepon; }
    public void setNoTelepon(String noTelepon) { this.noTelepon = noTelepon; }

    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }

    public String getPekerjaan() { return pekerjaan; }
    public void setPekerjaan(String pekerjaan) { this.pekerjaan = pekerjaan; }

    public Integer getIdUser() { return idUser; }
    public void setIdUser(Integer idUser) { this.idUser = idUser; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getUsernameKeluarga() { return usernameKeluarga; }
    public void setUsernameKeluarga(String usernameKeluarga) { this.usernameKeluarga = usernameKeluarga; }

    @Override
    public String toString() {
        return namaLengkap + " (" + hubungan + ")";
    }
}
